import { createRequire } from "node:module";
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { chmodSync, copyFileSync, existsSync, mkdirSync, readdirSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { gzipSync } from "node:zlib";
import { DatabaseSync } from "node:sqlite";
import { createHash, randomBytes, randomInt, scrypt, scryptSync, timingSafeEqual } from "node:crypto";
import { Worker, isMainThread, parentPort } from "node:worker_threads";
import { cpus } from "node:os";
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esmMin = (fn, res, err) => () => {
	if (err) throw err[0];
	try {
		return fn && (res = fn(fn = 0)), res;
	} catch (e) {
		throw err = [e], e;
	}
};
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
var __toCommonJS = (mod) => __hasOwnProp.call(mod, "module.exports") ? mod["module.exports"] : __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __require = /* #__PURE__ */ (() => createRequire(import.meta.url))();
//#endregion
//#region node_modules/ws/lib/constants.js
var require_constants = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var BINARY_TYPES = [
		"nodebuffer",
		"arraybuffer",
		"fragments"
	];
	var hasBlob = typeof Blob !== "undefined";
	if (hasBlob) BINARY_TYPES.push("blob");
	module.exports = {
		BINARY_TYPES,
		CLOSE_TIMEOUT: 3e4,
		EMPTY_BUFFER: Buffer.alloc(0),
		GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
		hasBlob,
		kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
		kListener: Symbol("kListener"),
		kStatusCode: Symbol("status-code"),
		kWebSocket: Symbol("websocket"),
		NOOP: () => {}
	};
}));
//#endregion
//#region __vite-optional-peer-dep:bufferutil:ws
var __vite_optional_peer_dep_bufferutil_ws_exports = /* @__PURE__ */ __exportAll({ default: () => __vite_optional_peer_dep_bufferutil_ws_default });
var __vite_optional_peer_dep_bufferutil_ws_default;
var init___vite_optional_peer_dep_bufferutil_ws = __esmMin((() => {
	__vite_optional_peer_dep_bufferutil_ws_default = {};
	throw new Error(`Could not resolve "bufferutil" imported by "ws". Is it installed?`);
}));
//#endregion
//#region node_modules/ws/lib/buffer-util.js
var require_buffer_util = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { EMPTY_BUFFER } = require_constants();
	var FastBuffer = Buffer[Symbol.species];
	/**
	* Merges an array of buffers into a new buffer.
	*
	* @param {Buffer[]} list The array of buffers to concat
	* @param {Number} totalLength The total length of buffers in the list
	* @return {Buffer} The resulting buffer
	* @public
	*/
	function concat(list, totalLength) {
		if (list.length === 0) return EMPTY_BUFFER;
		if (list.length === 1) return list[0];
		const target = Buffer.allocUnsafe(totalLength);
		let offset = 0;
		for (let i = 0; i < list.length; i++) {
			const buf = list[i];
			target.set(buf, offset);
			offset += buf.length;
		}
		if (offset < totalLength) return new FastBuffer(target.buffer, target.byteOffset, offset);
		return target;
	}
	/**
	* Masks a buffer using the given mask.
	*
	* @param {Buffer} source The buffer to mask
	* @param {Buffer} mask The mask to use
	* @param {Buffer} output The buffer where to store the result
	* @param {Number} offset The offset at which to start writing
	* @param {Number} length The number of bytes to mask.
	* @public
	*/
	function _mask(source, mask, output, offset, length) {
		for (let i = 0; i < length; i++) output[offset + i] = source[i] ^ mask[i & 3];
	}
	/**
	* Unmasks a buffer using the given mask.
	*
	* @param {Buffer} buffer The buffer to unmask
	* @param {Buffer} mask The mask to use
	* @public
	*/
	function _unmask(buffer, mask) {
		for (let i = 0; i < buffer.length; i++) buffer[i] ^= mask[i & 3];
	}
	/**
	* Converts a buffer to an `ArrayBuffer`.
	*
	* @param {Buffer} buf The buffer to convert
	* @return {ArrayBuffer} Converted buffer
	* @public
	*/
	function toArrayBuffer(buf) {
		if (buf.length === buf.buffer.byteLength) return buf.buffer;
		return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
	}
	/**
	* Converts `data` to a `Buffer`.
	*
	* @param {*} data The data to convert
	* @return {Buffer} The buffer
	* @throws {TypeError}
	* @public
	*/
	function toBuffer(data) {
		toBuffer.readOnly = true;
		if (Buffer.isBuffer(data)) return data;
		let buf;
		if (data instanceof ArrayBuffer) buf = new FastBuffer(data);
		else if (ArrayBuffer.isView(data)) buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
		else {
			buf = Buffer.from(data);
			toBuffer.readOnly = false;
		}
		return buf;
	}
	module.exports = {
		concat,
		mask: _mask,
		toArrayBuffer,
		toBuffer,
		unmask: _unmask
	};
	/* istanbul ignore else  */
	if (!process.env.WS_NO_BUFFER_UTIL) try {
		const bufferUtil = (init___vite_optional_peer_dep_bufferutil_ws(), __toCommonJS(__vite_optional_peer_dep_bufferutil_ws_exports));
		module.exports.mask = function(source, mask, output, offset, length) {
			if (length < 48) _mask(source, mask, output, offset, length);
			else bufferUtil.mask(source, mask, output, offset, length);
		};
		module.exports.unmask = function(buffer, mask) {
			if (buffer.length < 32) _unmask(buffer, mask);
			else bufferUtil.unmask(buffer, mask);
		};
	} catch (e) {}
}));
//#endregion
//#region node_modules/ws/lib/limiter.js
var require_limiter = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var kDone = Symbol("kDone");
	var kRun = Symbol("kRun");
	/**
	* A very simple job queue with adjustable concurrency. Adapted from
	* https://github.com/STRML/async-limiter
	*/
	var Limiter = class {
		/**
		* Creates a new `Limiter`.
		*
		* @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
		*     to run concurrently
		*/
		constructor(concurrency) {
			this[kDone] = () => {
				this.pending--;
				this[kRun]();
			};
			this.concurrency = concurrency || Infinity;
			this.jobs = [];
			this.pending = 0;
		}
		/**
		* Adds a job to the queue.
		*
		* @param {Function} job The job to run
		* @public
		*/
		add(job) {
			this.jobs.push(job);
			this[kRun]();
		}
		/**
		* Removes a job from the queue and runs it if possible.
		*
		* @private
		*/
		[kRun]() {
			if (this.pending === this.concurrency) return;
			if (this.jobs.length) {
				const job = this.jobs.shift();
				this.pending++;
				job(this[kDone]);
			}
		}
	};
	module.exports = Limiter;
}));
//#endregion
//#region node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var zlib = __require("zlib");
	var bufferUtil = require_buffer_util();
	var Limiter = require_limiter();
	var { kStatusCode } = require_constants();
	var FastBuffer = Buffer[Symbol.species];
	var TRAILER = Buffer.from([
		0,
		0,
		255,
		255
	]);
	var kPerMessageDeflate = Symbol("permessage-deflate");
	var kTotalLength = Symbol("total-length");
	var kCallback = Symbol("callback");
	var kBuffers = Symbol("buffers");
	var kError = Symbol("error");
	var zlibLimiter;
	/**
	* permessage-deflate implementation.
	*/
	var PerMessageDeflate = class {
		/**
		* Creates a PerMessageDeflate instance.
		*
		* @param {Object} [options] Configuration options
		* @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
		*     for, or request, a custom client window size
		* @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
		*     acknowledge disabling of client context takeover
		* @param {Number} [options.concurrencyLimit=10] The number of concurrent
		*     calls to zlib
		* @param {Boolean} [options.isServer=false] Create the instance in either
		*     server or client mode
		* @param {Number} [options.maxPayload=0] The maximum allowed message length
		* @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
		*     use of a custom server window size
		* @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
		*     disabling of server context takeover
		* @param {Number} [options.threshold=1024] Size (in bytes) below which
		*     messages should not be compressed if context takeover is disabled
		* @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
		*     deflate
		* @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
		*     inflate
		*/
		constructor(options) {
			this._options = options || {};
			this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
			this._maxPayload = this._options.maxPayload | 0;
			this._isServer = !!this._options.isServer;
			this._deflate = null;
			this._inflate = null;
			this.params = null;
			if (!zlibLimiter) zlibLimiter = new Limiter(this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10);
		}
		/**
		* @type {String}
		*/
		static get extensionName() {
			return "permessage-deflate";
		}
		/**
		* Create an extension negotiation offer.
		*
		* @return {Object} Extension parameters
		* @public
		*/
		offer() {
			const params = {};
			if (this._options.serverNoContextTakeover) params.server_no_context_takeover = true;
			if (this._options.clientNoContextTakeover) params.client_no_context_takeover = true;
			if (this._options.serverMaxWindowBits) params.server_max_window_bits = this._options.serverMaxWindowBits;
			if (this._options.clientMaxWindowBits) params.client_max_window_bits = this._options.clientMaxWindowBits;
			else if (this._options.clientMaxWindowBits == null) params.client_max_window_bits = true;
			return params;
		}
		/**
		* Accept an extension negotiation offer/response.
		*
		* @param {Array} configurations The extension negotiation offers/reponse
		* @return {Object} Accepted configuration
		* @public
		*/
		accept(configurations) {
			configurations = this.normalizeParams(configurations);
			this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
			return this.params;
		}
		/**
		* Releases all resources used by the extension.
		*
		* @public
		*/
		cleanup() {
			if (this._inflate) {
				this._inflate.close();
				this._inflate = null;
			}
			if (this._deflate) {
				const callback = this._deflate[kCallback];
				this._deflate.close();
				this._deflate = null;
				if (callback) callback(/* @__PURE__ */ new Error("The deflate stream was closed while data was being processed"));
			}
		}
		/**
		*  Accept an extension negotiation offer.
		*
		* @param {Array} offers The extension negotiation offers
		* @return {Object} Accepted configuration
		* @private
		*/
		acceptAsServer(offers) {
			const opts = this._options;
			const accepted = offers.find((params) => {
				if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && (typeof params.client_max_window_bits === "number" ? opts.clientMaxWindowBits > params.client_max_window_bits : !params.client_max_window_bits)) return false;
				return true;
			});
			if (!accepted) throw new Error("None of the extension offers can be accepted");
			if (opts.serverNoContextTakeover) accepted.server_no_context_takeover = true;
			if (opts.clientNoContextTakeover) accepted.client_no_context_takeover = true;
			if (typeof opts.serverMaxWindowBits === "number") accepted.server_max_window_bits = opts.serverMaxWindowBits;
			if (typeof opts.clientMaxWindowBits === "number") accepted.client_max_window_bits = opts.clientMaxWindowBits;
			else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) delete accepted.client_max_window_bits;
			return accepted;
		}
		/**
		* Accept the extension negotiation response.
		*
		* @param {Array} response The extension negotiation response
		* @return {Object} Accepted configuration
		* @private
		*/
		acceptAsClient(response) {
			const params = response[0];
			if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) throw new Error("Unexpected parameter \"client_no_context_takeover\"");
			if (!params.client_max_window_bits) {
				if (typeof this._options.clientMaxWindowBits === "number") params.client_max_window_bits = this._options.clientMaxWindowBits;
			} else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) throw new Error("Unexpected or invalid parameter \"client_max_window_bits\"");
			return params;
		}
		/**
		* Normalize parameters.
		*
		* @param {Array} configurations The extension negotiation offers/reponse
		* @return {Array} The offers/response with normalized parameters
		* @private
		*/
		normalizeParams(configurations) {
			configurations.forEach((params) => {
				Object.keys(params).forEach((key) => {
					let value = params[key];
					if (value.length > 1) throw new Error(`Parameter "${key}" must have only a single value`);
					value = value[0];
					if (key === "client_max_window_bits") {
						if (value !== true) {
							const num = +value;
							if (!Number.isInteger(num) || num < 8 || num > 15) throw new TypeError(`Invalid value for parameter "${key}": ${value}`);
							value = num;
						} else if (!this._isServer) throw new TypeError(`Invalid value for parameter "${key}": ${value}`);
					} else if (key === "server_max_window_bits") {
						const num = +value;
						if (!Number.isInteger(num) || num < 8 || num > 15) throw new TypeError(`Invalid value for parameter "${key}": ${value}`);
						value = num;
					} else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
						if (value !== true) throw new TypeError(`Invalid value for parameter "${key}": ${value}`);
					} else throw new Error(`Unknown parameter "${key}"`);
					params[key] = value;
				});
			});
			return configurations;
		}
		/**
		* Decompress data. Concurrency limited.
		*
		* @param {Buffer} data Compressed data
		* @param {Boolean} fin Specifies whether or not this is the last fragment
		* @param {Function} callback Callback
		* @public
		*/
		decompress(data, fin, callback) {
			zlibLimiter.add((done) => {
				this._decompress(data, fin, (err, result) => {
					done();
					callback(err, result);
				});
			});
		}
		/**
		* Compress data. Concurrency limited.
		*
		* @param {(Buffer|String)} data Data to compress
		* @param {Boolean} fin Specifies whether or not this is the last fragment
		* @param {Function} callback Callback
		* @public
		*/
		compress(data, fin, callback) {
			zlibLimiter.add((done) => {
				this._compress(data, fin, (err, result) => {
					done();
					callback(err, result);
				});
			});
		}
		/**
		* Decompress data.
		*
		* @param {Buffer} data Compressed data
		* @param {Boolean} fin Specifies whether or not this is the last fragment
		* @param {Function} callback Callback
		* @private
		*/
		_decompress(data, fin, callback) {
			const endpoint = this._isServer ? "client" : "server";
			if (!this._inflate) {
				const key = `${endpoint}_max_window_bits`;
				const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
				this._inflate = zlib.createInflateRaw({
					...this._options.zlibInflateOptions,
					windowBits
				});
				this._inflate[kPerMessageDeflate] = this;
				this._inflate[kTotalLength] = 0;
				this._inflate[kBuffers] = [];
				this._inflate.on("error", inflateOnError);
				this._inflate.on("data", inflateOnData);
			}
			this._inflate[kCallback] = callback;
			this._inflate.write(data);
			if (fin) this._inflate.write(TRAILER);
			this._inflate.flush(() => {
				const err = this._inflate[kError];
				if (err) {
					this._inflate.close();
					this._inflate = null;
					callback(err);
					return;
				}
				const data = bufferUtil.concat(this._inflate[kBuffers], this._inflate[kTotalLength]);
				if (this._inflate._readableState.endEmitted) {
					this._inflate.close();
					this._inflate = null;
				} else {
					this._inflate[kTotalLength] = 0;
					this._inflate[kBuffers] = [];
					if (fin && this.params[`${endpoint}_no_context_takeover`]) this._inflate.reset();
				}
				callback(null, data);
			});
		}
		/**
		* Compress data.
		*
		* @param {(Buffer|String)} data Data to compress
		* @param {Boolean} fin Specifies whether or not this is the last fragment
		* @param {Function} callback Callback
		* @private
		*/
		_compress(data, fin, callback) {
			const endpoint = this._isServer ? "server" : "client";
			if (!this._deflate) {
				const key = `${endpoint}_max_window_bits`;
				const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
				this._deflate = zlib.createDeflateRaw({
					...this._options.zlibDeflateOptions,
					windowBits
				});
				this._deflate[kTotalLength] = 0;
				this._deflate[kBuffers] = [];
				this._deflate.on("data", deflateOnData);
			}
			this._deflate[kCallback] = callback;
			this._deflate.write(data);
			this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
				if (!this._deflate) return;
				let data = bufferUtil.concat(this._deflate[kBuffers], this._deflate[kTotalLength]);
				if (fin) data = new FastBuffer(data.buffer, data.byteOffset, data.length - 4);
				this._deflate[kCallback] = null;
				this._deflate[kTotalLength] = 0;
				this._deflate[kBuffers] = [];
				if (fin && this.params[`${endpoint}_no_context_takeover`]) this._deflate.reset();
				callback(null, data);
			});
		}
	};
	module.exports = PerMessageDeflate;
	/**
	* The listener of the `zlib.DeflateRaw` stream `'data'` event.
	*
	* @param {Buffer} chunk A chunk of data
	* @private
	*/
	function deflateOnData(chunk) {
		this[kBuffers].push(chunk);
		this[kTotalLength] += chunk.length;
	}
	/**
	* The listener of the `zlib.InflateRaw` stream `'data'` event.
	*
	* @param {Buffer} chunk A chunk of data
	* @private
	*/
	function inflateOnData(chunk) {
		this[kTotalLength] += chunk.length;
		if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
			this[kBuffers].push(chunk);
			return;
		}
		this[kError] = /* @__PURE__ */ new RangeError("Max payload size exceeded");
		this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
		this[kError][kStatusCode] = 1009;
		this.removeListener("data", inflateOnData);
		this.reset();
	}
	/**
	* The listener of the `zlib.InflateRaw` stream `'error'` event.
	*
	* @param {Error} err The emitted error
	* @private
	*/
	function inflateOnError(err) {
		this[kPerMessageDeflate]._inflate = null;
		if (this[kError]) {
			this[kCallback](this[kError]);
			return;
		}
		err[kStatusCode] = 1007;
		this[kCallback](err);
	}
}));
//#endregion
//#region __vite-optional-peer-dep:utf-8-validate:ws
var __vite_optional_peer_dep_utf_8_validate_ws_exports = /* @__PURE__ */ __exportAll({ default: () => __vite_optional_peer_dep_utf_8_validate_ws_default });
var __vite_optional_peer_dep_utf_8_validate_ws_default;
var init___vite_optional_peer_dep_utf_8_validate_ws = __esmMin((() => {
	__vite_optional_peer_dep_utf_8_validate_ws_default = {};
	throw new Error(`Could not resolve "utf-8-validate" imported by "ws". Is it installed?`);
}));
//#endregion
//#region node_modules/ws/lib/validation.js
var require_validation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { isUtf8 } = __require("buffer");
	var { hasBlob } = require_constants();
	var tokenChars = [
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		0,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		1,
		1,
		0,
		1,
		1,
		0,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		1,
		0,
		1,
		0,
		1,
		0
	];
	/**
	* Checks if a status code is allowed in a close frame.
	*
	* @param {Number} code The status code
	* @return {Boolean} `true` if the status code is valid, else `false`
	* @public
	*/
	function isValidStatusCode(code) {
		return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
	}
	/**
	* Checks if a given buffer contains only correct UTF-8.
	* Ported from https://www.cl.cam.ac.uk/%7Emgk25/ucs/utf8_check.c by
	* Markus Kuhn.
	*
	* @param {Buffer} buf The buffer to check
	* @return {Boolean} `true` if `buf` contains only correct UTF-8, else `false`
	* @public
	*/
	function _isValidUTF8(buf) {
		const len = buf.length;
		let i = 0;
		while (i < len) if ((buf[i] & 128) === 0) i++;
		else if ((buf[i] & 224) === 192) {
			if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) return false;
			i += 2;
		} else if ((buf[i] & 240) === 224) {
			if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || buf[i] === 237 && (buf[i + 1] & 224) === 160) return false;
			i += 3;
		} else if ((buf[i] & 248) === 240) {
			if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) return false;
			i += 4;
		} else return false;
		return true;
	}
	/**
	* Determines whether a value is a `Blob`.
	*
	* @param {*} value The value to be tested
	* @return {Boolean} `true` if `value` is a `Blob`, else `false`
	* @private
	*/
	function isBlob(value) {
		return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
	}
	module.exports = {
		isBlob,
		isValidStatusCode,
		isValidUTF8: _isValidUTF8,
		tokenChars
	};
	if (isUtf8) module.exports.isValidUTF8 = function(buf) {
		return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
	};
	else if (!process.env.WS_NO_UTF_8_VALIDATE) try {
		const isValidUTF8 = (init___vite_optional_peer_dep_utf_8_validate_ws(), __toCommonJS(__vite_optional_peer_dep_utf_8_validate_ws_exports));
		module.exports.isValidUTF8 = function(buf) {
			return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
		};
	} catch (e) {}
}));
//#endregion
//#region node_modules/ws/lib/receiver.js
var require_receiver = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Writable } = __require("stream");
	var PerMessageDeflate = require_permessage_deflate();
	var { BINARY_TYPES, EMPTY_BUFFER, kStatusCode, kWebSocket } = require_constants();
	var { concat, toArrayBuffer, unmask } = require_buffer_util();
	var { isValidStatusCode, isValidUTF8 } = require_validation();
	var FastBuffer = Buffer[Symbol.species];
	var GET_INFO = 0;
	var GET_PAYLOAD_LENGTH_16 = 1;
	var GET_PAYLOAD_LENGTH_64 = 2;
	var GET_MASK = 3;
	var GET_DATA = 4;
	var INFLATING = 5;
	var DEFER_EVENT = 6;
	/**
	* HyBi Receiver implementation.
	*
	* @extends Writable
	*/
	var Receiver = class extends Writable {
		/**
		* Creates a Receiver instance.
		*
		* @param {Object} [options] Options object
		* @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
		*     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
		*     multiple times in the same tick
		* @param {String} [options.binaryType=nodebuffer] The type for binary data
		* @param {Object} [options.extensions] An object containing the negotiated
		*     extensions
		* @param {Boolean} [options.isServer=false] Specifies whether to operate in
		*     client or server mode
		* @param {Number} [options.maxBufferedChunks=0] The maximum number of
		*     buffered data chunks
		* @param {Number} [options.maxFragments=0] The maximum number of message
		*     fragments
		* @param {Number} [options.maxPayload=0] The maximum allowed message length
		* @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
		*     not to skip UTF-8 validation for text and close messages
		*/
		constructor(options = {}) {
			super();
			this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
			this._binaryType = options.binaryType || BINARY_TYPES[0];
			this._extensions = options.extensions || {};
			this._isServer = !!options.isServer;
			this._maxBufferedChunks = options.maxBufferedChunks | 0;
			this._maxFragments = options.maxFragments | 0;
			this._maxPayload = options.maxPayload | 0;
			this._skipUTF8Validation = !!options.skipUTF8Validation;
			this[kWebSocket] = void 0;
			this._bufferedBytes = 0;
			this._buffers = [];
			this._compressed = false;
			this._payloadLength = 0;
			this._mask = void 0;
			this._fragmented = 0;
			this._masked = false;
			this._fin = false;
			this._opcode = 0;
			this._totalPayloadLength = 0;
			this._messageLength = 0;
			this._numFragments = 0;
			this._fragments = [];
			this._errored = false;
			this._loop = false;
			this._state = GET_INFO;
		}
		/**
		* Implements `Writable.prototype._write()`.
		*
		* @param {Buffer} chunk The chunk of data to write
		* @param {String} encoding The character encoding of `chunk`
		* @param {Function} cb Callback
		* @private
		*/
		_write(chunk, encoding, cb) {
			if (this._opcode === 8 && this._state == GET_INFO) return cb();
			if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
				cb(this.createError(RangeError, "Too many buffered chunks", false, 1008, "WS_ERR_TOO_MANY_BUFFERED_PARTS"));
				return;
			}
			this._bufferedBytes += chunk.length;
			this._buffers.push(chunk);
			this.startLoop(cb);
		}
		/**
		* Consumes `n` bytes from the buffered data.
		*
		* @param {Number} n The number of bytes to consume
		* @return {Buffer} The consumed bytes
		* @private
		*/
		consume(n) {
			this._bufferedBytes -= n;
			if (n === this._buffers[0].length) return this._buffers.shift();
			if (n < this._buffers[0].length) {
				const buf = this._buffers[0];
				this._buffers[0] = new FastBuffer(buf.buffer, buf.byteOffset + n, buf.length - n);
				return new FastBuffer(buf.buffer, buf.byteOffset, n);
			}
			const dst = Buffer.allocUnsafe(n);
			do {
				const buf = this._buffers[0];
				const offset = dst.length - n;
				if (n >= buf.length) dst.set(this._buffers.shift(), offset);
				else {
					dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
					this._buffers[0] = new FastBuffer(buf.buffer, buf.byteOffset + n, buf.length - n);
				}
				n -= buf.length;
			} while (n > 0);
			return dst;
		}
		/**
		* Starts the parsing loop.
		*
		* @param {Function} cb Callback
		* @private
		*/
		startLoop(cb) {
			this._loop = true;
			do
				switch (this._state) {
					case GET_INFO:
						this.getInfo(cb);
						break;
					case GET_PAYLOAD_LENGTH_16:
						this.getPayloadLength16(cb);
						break;
					case GET_PAYLOAD_LENGTH_64:
						this.getPayloadLength64(cb);
						break;
					case GET_MASK:
						this.getMask();
						break;
					case GET_DATA:
						this.getData(cb);
						break;
					case INFLATING:
					case DEFER_EVENT:
						this._loop = false;
						return;
				}
			while (this._loop);
			if (!this._errored) cb();
		}
		/**
		* Reads the first two bytes of a frame.
		*
		* @param {Function} cb Callback
		* @private
		*/
		getInfo(cb) {
			if (this._bufferedBytes < 2) {
				this._loop = false;
				return;
			}
			const buf = this.consume(2);
			if ((buf[0] & 48) !== 0) {
				cb(this.createError(RangeError, "RSV2 and RSV3 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_2_3"));
				return;
			}
			const compressed = (buf[0] & 64) === 64;
			if (compressed && !this._extensions[PerMessageDeflate.extensionName]) {
				cb(this.createError(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1"));
				return;
			}
			this._fin = (buf[0] & 128) === 128;
			this._opcode = buf[0] & 15;
			this._payloadLength = buf[1] & 127;
			if (this._opcode === 0) {
				if (compressed) {
					cb(this.createError(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1"));
					return;
				}
				if (!this._fragmented) {
					cb(this.createError(RangeError, "invalid opcode 0", true, 1002, "WS_ERR_INVALID_OPCODE"));
					return;
				}
				this._opcode = this._fragmented;
			} else if (this._opcode === 1 || this._opcode === 2) {
				if (this._fragmented) {
					cb(this.createError(RangeError, `invalid opcode ${this._opcode}`, true, 1002, "WS_ERR_INVALID_OPCODE"));
					return;
				}
				this._compressed = compressed;
			} else if (this._opcode > 7 && this._opcode < 11) {
				if (!this._fin) {
					cb(this.createError(RangeError, "FIN must be set", true, 1002, "WS_ERR_EXPECTED_FIN"));
					return;
				}
				if (compressed) {
					cb(this.createError(RangeError, "RSV1 must be clear", true, 1002, "WS_ERR_UNEXPECTED_RSV_1"));
					return;
				}
				if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
					cb(this.createError(RangeError, `invalid payload length ${this._payloadLength}`, true, 1002, "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"));
					return;
				}
			} else {
				cb(this.createError(RangeError, `invalid opcode ${this._opcode}`, true, 1002, "WS_ERR_INVALID_OPCODE"));
				return;
			}
			if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
			this._masked = (buf[1] & 128) === 128;
			if (this._isServer) {
				if (!this._masked) {
					cb(this.createError(RangeError, "MASK must be set", true, 1002, "WS_ERR_EXPECTED_MASK"));
					return;
				}
			} else if (this._masked) {
				cb(this.createError(RangeError, "MASK must be clear", true, 1002, "WS_ERR_UNEXPECTED_MASK"));
				return;
			}
			if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
			else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
			else this.haveLength(cb);
		}
		/**
		* Gets extended payload length (7+16).
		*
		* @param {Function} cb Callback
		* @private
		*/
		getPayloadLength16(cb) {
			if (this._bufferedBytes < 2) {
				this._loop = false;
				return;
			}
			this._payloadLength = this.consume(2).readUInt16BE(0);
			this.haveLength(cb);
		}
		/**
		* Gets extended payload length (7+64).
		*
		* @param {Function} cb Callback
		* @private
		*/
		getPayloadLength64(cb) {
			if (this._bufferedBytes < 8) {
				this._loop = false;
				return;
			}
			const buf = this.consume(8);
			const num = buf.readUInt32BE(0);
			if (num > Math.pow(2, 21) - 1) {
				cb(this.createError(RangeError, "Unsupported WebSocket frame: payload length > 2^53 - 1", false, 1009, "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"));
				return;
			}
			this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
			this.haveLength(cb);
		}
		/**
		* Payload length has been read.
		*
		* @param {Function} cb Callback
		* @private
		*/
		haveLength(cb) {
			if (this._payloadLength && this._opcode < 8) {
				this._totalPayloadLength += this._payloadLength;
				if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
					cb(this.createError(RangeError, "Max payload size exceeded", false, 1009, "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"));
					return;
				}
			}
			if (this._masked) this._state = GET_MASK;
			else this._state = GET_DATA;
		}
		/**
		* Reads mask bytes.
		*
		* @private
		*/
		getMask() {
			if (this._bufferedBytes < 4) {
				this._loop = false;
				return;
			}
			this._mask = this.consume(4);
			this._state = GET_DATA;
		}
		/**
		* Reads data bytes.
		*
		* @param {Function} cb Callback
		* @private
		*/
		getData(cb) {
			let data = EMPTY_BUFFER;
			if (this._payloadLength) {
				if (this._bufferedBytes < this._payloadLength) {
					this._loop = false;
					return;
				}
				data = this.consume(this._payloadLength);
				if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) unmask(data, this._mask);
			}
			if (this._opcode > 7) {
				this.controlMessage(data, cb);
				return;
			}
			if (this._maxFragments > 0 && ++this._numFragments > this._maxFragments) {
				cb(this.createError(RangeError, "Too many message fragments", false, 1008, "WS_ERR_TOO_MANY_BUFFERED_PARTS"));
				return;
			}
			if (this._compressed) {
				this._state = INFLATING;
				this.decompress(data, cb);
				return;
			}
			if (data.length) {
				this._messageLength = this._totalPayloadLength;
				this._fragments.push(data);
			}
			this.dataMessage(cb);
		}
		/**
		* Decompresses data.
		*
		* @param {Buffer} data Compressed data
		* @param {Function} cb Callback
		* @private
		*/
		decompress(data, cb) {
			this._extensions[PerMessageDeflate.extensionName].decompress(data, this._fin, (err, buf) => {
				if (err) return cb(err);
				if (buf.length) {
					this._messageLength += buf.length;
					if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
						cb(this.createError(RangeError, "Max payload size exceeded", false, 1009, "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"));
						return;
					}
					this._fragments.push(buf);
				}
				this.dataMessage(cb);
				if (this._state === GET_INFO) this.startLoop(cb);
			});
		}
		/**
		* Handles a data message.
		*
		* @param {Function} cb Callback
		* @private
		*/
		dataMessage(cb) {
			if (!this._fin) {
				this._state = GET_INFO;
				return;
			}
			const messageLength = this._messageLength;
			const fragments = this._fragments;
			this._totalPayloadLength = 0;
			this._messageLength = 0;
			this._fragmented = 0;
			this._numFragments = 0;
			this._fragments = [];
			if (this._opcode === 2) {
				let data;
				if (this._binaryType === "nodebuffer") data = concat(fragments, messageLength);
				else if (this._binaryType === "arraybuffer") data = toArrayBuffer(concat(fragments, messageLength));
				else if (this._binaryType === "blob") data = new Blob(fragments);
				else data = fragments;
				if (this._allowSynchronousEvents) {
					this.emit("message", data, true);
					this._state = GET_INFO;
				} else {
					this._state = DEFER_EVENT;
					setImmediate(() => {
						this.emit("message", data, true);
						this._state = GET_INFO;
						this.startLoop(cb);
					});
				}
			} else {
				const buf = concat(fragments, messageLength);
				if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
					cb(this.createError(Error, "invalid UTF-8 sequence", true, 1007, "WS_ERR_INVALID_UTF8"));
					return;
				}
				if (this._state === INFLATING || this._allowSynchronousEvents) {
					this.emit("message", buf, false);
					this._state = GET_INFO;
				} else {
					this._state = DEFER_EVENT;
					setImmediate(() => {
						this.emit("message", buf, false);
						this._state = GET_INFO;
						this.startLoop(cb);
					});
				}
			}
		}
		/**
		* Handles a control message.
		*
		* @param {Buffer} data Data to handle
		* @return {(Error|RangeError|undefined)} A possible error
		* @private
		*/
		controlMessage(data, cb) {
			if (this._opcode === 8) {
				if (data.length === 0) {
					this._loop = false;
					this.emit("conclude", 1005, EMPTY_BUFFER);
					this.end();
				} else {
					const code = data.readUInt16BE(0);
					if (!isValidStatusCode(code)) {
						cb(this.createError(RangeError, `invalid status code ${code}`, true, 1002, "WS_ERR_INVALID_CLOSE_CODE"));
						return;
					}
					const buf = new FastBuffer(data.buffer, data.byteOffset + 2, data.length - 2);
					if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
						cb(this.createError(Error, "invalid UTF-8 sequence", true, 1007, "WS_ERR_INVALID_UTF8"));
						return;
					}
					this._loop = false;
					this.emit("conclude", code, buf);
					this.end();
				}
				this._state = GET_INFO;
				return;
			}
			if (this._allowSynchronousEvents) {
				this.emit(this._opcode === 9 ? "ping" : "pong", data);
				this._state = GET_INFO;
			} else {
				this._state = DEFER_EVENT;
				setImmediate(() => {
					this.emit(this._opcode === 9 ? "ping" : "pong", data);
					this._state = GET_INFO;
					this.startLoop(cb);
				});
			}
		}
		/**
		* Builds an error object.
		*
		* @param {function(new:Error|RangeError)} ErrorCtor The error constructor
		* @param {String} message The error message
		* @param {Boolean} prefix Specifies whether or not to add a default prefix to
		*     `message`
		* @param {Number} statusCode The status code
		* @param {String} errorCode The exposed error code
		* @return {(Error|RangeError)} The error
		* @private
		*/
		createError(ErrorCtor, message, prefix, statusCode, errorCode) {
			this._loop = false;
			this._errored = true;
			const err = new ErrorCtor(prefix ? `Invalid WebSocket frame: ${message}` : message);
			Error.captureStackTrace(err, this.createError);
			err.code = errorCode;
			err[kStatusCode] = statusCode;
			return err;
		}
	};
	module.exports = Receiver;
}));
//#endregion
//#region node_modules/ws/lib/sender.js
var require_sender = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { Duplex: Duplex$3 } = __require("stream");
	var { randomFillSync } = __require("crypto");
	var { types: { isUint8Array } } = __require("util");
	var PerMessageDeflate = require_permessage_deflate();
	var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
	var { isBlob, isValidStatusCode } = require_validation();
	var { mask: applyMask, toBuffer } = require_buffer_util();
	var kByteLength = Symbol("kByteLength");
	var maskBuffer = Buffer.alloc(4);
	var RANDOM_POOL_SIZE = 8192;
	var randomPool;
	var randomPoolPointer = RANDOM_POOL_SIZE;
	var DEFAULT = 0;
	var DEFLATING = 1;
	var GET_BLOB_DATA = 2;
	module.exports = class Sender {
		/**
		* Creates a Sender instance.
		*
		* @param {Duplex} socket The connection socket
		* @param {Object} [extensions] An object containing the negotiated extensions
		* @param {Function} [generateMask] The function used to generate the masking
		*     key
		*/
		constructor(socket, extensions, generateMask) {
			this._extensions = extensions || {};
			if (generateMask) {
				this._generateMask = generateMask;
				this._maskBuffer = Buffer.alloc(4);
			}
			this._socket = socket;
			this._firstFragment = true;
			this._compress = false;
			this._bufferedBytes = 0;
			this._queue = [];
			this._state = DEFAULT;
			this.onerror = NOOP;
			this[kWebSocket] = void 0;
		}
		/**
		* Frames a piece of data according to the HyBi WebSocket protocol.
		*
		* @param {(Buffer|String)} data The data to frame
		* @param {Object} options Options object
		* @param {Boolean} [options.fin=false] Specifies whether or not to set the
		*     FIN bit
		* @param {Function} [options.generateMask] The function used to generate the
		*     masking key
		* @param {Boolean} [options.mask=false] Specifies whether or not to mask
		*     `data`
		* @param {Buffer} [options.maskBuffer] The buffer used to store the masking
		*     key
		* @param {Number} options.opcode The opcode
		* @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
		*     modified
		* @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
		*     RSV1 bit
		* @return {(Buffer|String)[]} The framed data
		* @public
		*/
		static frame(data, options) {
			let mask;
			let merge = false;
			let offset = 2;
			let skipMasking = false;
			if (options.mask) {
				mask = options.maskBuffer || maskBuffer;
				if (options.generateMask) options.generateMask(mask);
				else {
					if (randomPoolPointer === RANDOM_POOL_SIZE) {
						/* istanbul ignore else  */
						if (randomPool === void 0) randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
						randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
						randomPoolPointer = 0;
					}
					mask[0] = randomPool[randomPoolPointer++];
					mask[1] = randomPool[randomPoolPointer++];
					mask[2] = randomPool[randomPoolPointer++];
					mask[3] = randomPool[randomPoolPointer++];
				}
				skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
				offset = 6;
			}
			let dataLength;
			if (typeof data === "string") {
				if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) dataLength = options[kByteLength];
				else {
					data = Buffer.from(data);
					dataLength = data.length;
				}
			} else {
				dataLength = data.length;
				merge = options.mask && options.readOnly && !skipMasking;
			}
			let payloadLength = dataLength;
			if (dataLength >= 65536) {
				offset += 8;
				payloadLength = 127;
			} else if (dataLength > 125) {
				offset += 2;
				payloadLength = 126;
			}
			const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
			target[0] = options.fin ? options.opcode | 128 : options.opcode;
			if (options.rsv1) target[0] |= 64;
			target[1] = payloadLength;
			if (payloadLength === 126) target.writeUInt16BE(dataLength, 2);
			else if (payloadLength === 127) {
				target[2] = target[3] = 0;
				target.writeUIntBE(dataLength, 4, 6);
			}
			if (!options.mask) return [target, data];
			target[1] |= 128;
			target[offset - 4] = mask[0];
			target[offset - 3] = mask[1];
			target[offset - 2] = mask[2];
			target[offset - 1] = mask[3];
			if (skipMasking) return [target, data];
			if (merge) {
				applyMask(data, mask, target, offset, dataLength);
				return [target];
			}
			applyMask(data, mask, data, 0, dataLength);
			return [target, data];
		}
		/**
		* Sends a close message to the other peer.
		*
		* @param {Number} [code] The status code component of the body
		* @param {(String|Buffer)} [data] The message component of the body
		* @param {Boolean} [mask=false] Specifies whether or not to mask the message
		* @param {Function} [cb] Callback
		* @public
		*/
		close(code, data, mask, cb) {
			let buf;
			if (code === void 0) buf = EMPTY_BUFFER;
			else if (typeof code !== "number" || !isValidStatusCode(code)) throw new TypeError("First argument must be a valid error code number");
			else if (data === void 0 || !data.length) {
				buf = Buffer.allocUnsafe(2);
				buf.writeUInt16BE(code, 0);
			} else {
				const length = Buffer.byteLength(data);
				if (length > 123) throw new RangeError("The message must not be greater than 123 bytes");
				buf = Buffer.allocUnsafe(2 + length);
				buf.writeUInt16BE(code, 0);
				if (typeof data === "string") buf.write(data, 2);
				else if (isUint8Array(data)) buf.set(data, 2);
				else throw new TypeError("Second argument must be a string or a Uint8Array");
			}
			const options = {
				[kByteLength]: buf.length,
				fin: true,
				generateMask: this._generateMask,
				mask,
				maskBuffer: this._maskBuffer,
				opcode: 8,
				readOnly: false,
				rsv1: false
			};
			if (this._state !== DEFAULT) this.enqueue([
				this.dispatch,
				buf,
				false,
				options,
				cb
			]);
			else this.sendFrame(Sender.frame(buf, options), cb);
		}
		/**
		* Sends a ping message to the other peer.
		*
		* @param {*} data The message to send
		* @param {Boolean} [mask=false] Specifies whether or not to mask `data`
		* @param {Function} [cb] Callback
		* @public
		*/
		ping(data, mask, cb) {
			let byteLength;
			let readOnly;
			if (typeof data === "string") {
				byteLength = Buffer.byteLength(data);
				readOnly = false;
			} else if (isBlob(data)) {
				byteLength = data.size;
				readOnly = false;
			} else {
				data = toBuffer(data);
				byteLength = data.length;
				readOnly = toBuffer.readOnly;
			}
			if (byteLength > 125) throw new RangeError("The data size must not be greater than 125 bytes");
			const options = {
				[kByteLength]: byteLength,
				fin: true,
				generateMask: this._generateMask,
				mask,
				maskBuffer: this._maskBuffer,
				opcode: 9,
				readOnly,
				rsv1: false
			};
			if (isBlob(data)) {
				if (this._state !== DEFAULT) this.enqueue([
					this.getBlobData,
					data,
					false,
					options,
					cb
				]);
				else this.getBlobData(data, false, options, cb);
			} else if (this._state !== DEFAULT) this.enqueue([
				this.dispatch,
				data,
				false,
				options,
				cb
			]);
			else this.sendFrame(Sender.frame(data, options), cb);
		}
		/**
		* Sends a pong message to the other peer.
		*
		* @param {*} data The message to send
		* @param {Boolean} [mask=false] Specifies whether or not to mask `data`
		* @param {Function} [cb] Callback
		* @public
		*/
		pong(data, mask, cb) {
			let byteLength;
			let readOnly;
			if (typeof data === "string") {
				byteLength = Buffer.byteLength(data);
				readOnly = false;
			} else if (isBlob(data)) {
				byteLength = data.size;
				readOnly = false;
			} else {
				data = toBuffer(data);
				byteLength = data.length;
				readOnly = toBuffer.readOnly;
			}
			if (byteLength > 125) throw new RangeError("The data size must not be greater than 125 bytes");
			const options = {
				[kByteLength]: byteLength,
				fin: true,
				generateMask: this._generateMask,
				mask,
				maskBuffer: this._maskBuffer,
				opcode: 10,
				readOnly,
				rsv1: false
			};
			if (isBlob(data)) {
				if (this._state !== DEFAULT) this.enqueue([
					this.getBlobData,
					data,
					false,
					options,
					cb
				]);
				else this.getBlobData(data, false, options, cb);
			} else if (this._state !== DEFAULT) this.enqueue([
				this.dispatch,
				data,
				false,
				options,
				cb
			]);
			else this.sendFrame(Sender.frame(data, options), cb);
		}
		/**
		* Sends a data message to the other peer.
		*
		* @param {*} data The message to send
		* @param {Object} options Options object
		* @param {Boolean} [options.binary=false] Specifies whether `data` is binary
		*     or text
		* @param {Boolean} [options.compress=false] Specifies whether or not to
		*     compress `data`
		* @param {Boolean} [options.fin=false] Specifies whether the fragment is the
		*     last one
		* @param {Boolean} [options.mask=false] Specifies whether or not to mask
		*     `data`
		* @param {Function} [cb] Callback
		* @public
		*/
		send(data, options, cb) {
			const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
			let opcode = options.binary ? 2 : 1;
			let rsv1 = options.compress;
			let byteLength;
			let readOnly;
			if (typeof data === "string") {
				byteLength = Buffer.byteLength(data);
				readOnly = false;
			} else if (isBlob(data)) {
				byteLength = data.size;
				readOnly = false;
			} else {
				data = toBuffer(data);
				byteLength = data.length;
				readOnly = toBuffer.readOnly;
			}
			if (this._firstFragment) {
				this._firstFragment = false;
				if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) rsv1 = byteLength >= perMessageDeflate._threshold;
				this._compress = rsv1;
			} else {
				rsv1 = false;
				opcode = 0;
			}
			if (options.fin) this._firstFragment = true;
			const opts = {
				[kByteLength]: byteLength,
				fin: options.fin,
				generateMask: this._generateMask,
				mask: options.mask,
				maskBuffer: this._maskBuffer,
				opcode,
				readOnly,
				rsv1
			};
			if (isBlob(data)) {
				if (this._state !== DEFAULT) this.enqueue([
					this.getBlobData,
					data,
					this._compress,
					opts,
					cb
				]);
				else this.getBlobData(data, this._compress, opts, cb);
			} else if (this._state !== DEFAULT) this.enqueue([
				this.dispatch,
				data,
				this._compress,
				opts,
				cb
			]);
			else this.dispatch(data, this._compress, opts, cb);
		}
		/**
		* Gets the contents of a blob as binary data.
		*
		* @param {Blob} blob The blob
		* @param {Boolean} [compress=false] Specifies whether or not to compress
		*     the data
		* @param {Object} options Options object
		* @param {Boolean} [options.fin=false] Specifies whether or not to set the
		*     FIN bit
		* @param {Function} [options.generateMask] The function used to generate the
		*     masking key
		* @param {Boolean} [options.mask=false] Specifies whether or not to mask
		*     `data`
		* @param {Buffer} [options.maskBuffer] The buffer used to store the masking
		*     key
		* @param {Number} options.opcode The opcode
		* @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
		*     modified
		* @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
		*     RSV1 bit
		* @param {Function} [cb] Callback
		* @private
		*/
		getBlobData(blob, compress, options, cb) {
			this._bufferedBytes += options[kByteLength];
			this._state = GET_BLOB_DATA;
			blob.arrayBuffer().then((arrayBuffer) => {
				if (this._socket.destroyed) {
					const err = /* @__PURE__ */ new Error("The socket was closed while the blob was being read");
					process.nextTick(callCallbacks, this, err, cb);
					return;
				}
				this._bufferedBytes -= options[kByteLength];
				const data = toBuffer(arrayBuffer);
				if (!compress) {
					this._state = DEFAULT;
					this.sendFrame(Sender.frame(data, options), cb);
					this.dequeue();
				} else this.dispatch(data, compress, options, cb);
			}).catch((err) => {
				process.nextTick(onError, this, err, cb);
			});
		}
		/**
		* Dispatches a message.
		*
		* @param {(Buffer|String)} data The message to send
		* @param {Boolean} [compress=false] Specifies whether or not to compress
		*     `data`
		* @param {Object} options Options object
		* @param {Boolean} [options.fin=false] Specifies whether or not to set the
		*     FIN bit
		* @param {Function} [options.generateMask] The function used to generate the
		*     masking key
		* @param {Boolean} [options.mask=false] Specifies whether or not to mask
		*     `data`
		* @param {Buffer} [options.maskBuffer] The buffer used to store the masking
		*     key
		* @param {Number} options.opcode The opcode
		* @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
		*     modified
		* @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
		*     RSV1 bit
		* @param {Function} [cb] Callback
		* @private
		*/
		dispatch(data, compress, options, cb) {
			if (!compress) {
				this.sendFrame(Sender.frame(data, options), cb);
				return;
			}
			const perMessageDeflate = this._extensions[PerMessageDeflate.extensionName];
			this._bufferedBytes += options[kByteLength];
			this._state = DEFLATING;
			perMessageDeflate.compress(data, options.fin, (_, buf) => {
				if (this._socket.destroyed) {
					const err = /* @__PURE__ */ new Error("The socket was closed while data was being compressed");
					callCallbacks(this, err, cb);
					return;
				}
				this._bufferedBytes -= options[kByteLength];
				this._state = DEFAULT;
				options.readOnly = false;
				this.sendFrame(Sender.frame(buf, options), cb);
				this.dequeue();
			});
		}
		/**
		* Executes queued send operations.
		*
		* @private
		*/
		dequeue() {
			while (this._state === DEFAULT && this._queue.length) {
				const params = this._queue.shift();
				this._bufferedBytes -= params[3][kByteLength];
				Reflect.apply(params[0], this, params.slice(1));
			}
		}
		/**
		* Enqueues a send operation.
		*
		* @param {Array} params Send operation parameters.
		* @private
		*/
		enqueue(params) {
			this._bufferedBytes += params[3][kByteLength];
			this._queue.push(params);
		}
		/**
		* Sends a frame.
		*
		* @param {(Buffer | String)[]} list The frame to send
		* @param {Function} [cb] Callback
		* @private
		*/
		sendFrame(list, cb) {
			if (list.length === 2) {
				this._socket.cork();
				this._socket.write(list[0]);
				this._socket.write(list[1], cb);
				this._socket.uncork();
			} else this._socket.write(list[0], cb);
		}
	};
	/**
	* Calls queued callbacks with an error.
	*
	* @param {Sender} sender The `Sender` instance
	* @param {Error} err The error to call the callbacks with
	* @param {Function} [cb] The first callback
	* @private
	*/
	function callCallbacks(sender, err, cb) {
		if (typeof cb === "function") cb(err);
		for (let i = 0; i < sender._queue.length; i++) {
			const params = sender._queue[i];
			const callback = params[params.length - 1];
			if (typeof callback === "function") callback(err);
		}
	}
	/**
	* Handles a `Sender` error.
	*
	* @param {Sender} sender The `Sender` instance
	* @param {Error} err The error
	* @param {Function} [cb] The first pending callback
	* @private
	*/
	function onError(sender, err, cb) {
		callCallbacks(sender, err, cb);
		sender.onerror(err);
	}
}));
//#endregion
//#region node_modules/ws/lib/event-target.js
var require_event_target = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { kForOnEventAttribute, kListener } = require_constants();
	var kCode = Symbol("kCode");
	var kData = Symbol("kData");
	var kError = Symbol("kError");
	var kMessage = Symbol("kMessage");
	var kReason = Symbol("kReason");
	var kTarget = Symbol("kTarget");
	var kType = Symbol("kType");
	var kWasClean = Symbol("kWasClean");
	/**
	* Class representing an event.
	*/
	var Event = class {
		/**
		* Create a new `Event`.
		*
		* @param {String} type The name of the event
		* @throws {TypeError} If the `type` argument is not specified
		*/
		constructor(type) {
			this[kTarget] = null;
			this[kType] = type;
		}
		/**
		* @type {*}
		*/
		get target() {
			return this[kTarget];
		}
		/**
		* @type {String}
		*/
		get type() {
			return this[kType];
		}
	};
	Object.defineProperty(Event.prototype, "target", { enumerable: true });
	Object.defineProperty(Event.prototype, "type", { enumerable: true });
	/**
	* Class representing a close event.
	*
	* @extends Event
	*/
	var CloseEvent = class extends Event {
		/**
		* Create a new `CloseEvent`.
		*
		* @param {String} type The name of the event
		* @param {Object} [options] A dictionary object that allows for setting
		*     attributes via object members of the same name
		* @param {Number} [options.code=0] The status code explaining why the
		*     connection was closed
		* @param {String} [options.reason=''] A human-readable string explaining why
		*     the connection was closed
		* @param {Boolean} [options.wasClean=false] Indicates whether or not the
		*     connection was cleanly closed
		*/
		constructor(type, options = {}) {
			super(type);
			this[kCode] = options.code === void 0 ? 0 : options.code;
			this[kReason] = options.reason === void 0 ? "" : options.reason;
			this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
		}
		/**
		* @type {Number}
		*/
		get code() {
			return this[kCode];
		}
		/**
		* @type {String}
		*/
		get reason() {
			return this[kReason];
		}
		/**
		* @type {Boolean}
		*/
		get wasClean() {
			return this[kWasClean];
		}
	};
	Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
	Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
	Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
	/**
	* Class representing an error event.
	*
	* @extends Event
	*/
	var ErrorEvent = class extends Event {
		/**
		* Create a new `ErrorEvent`.
		*
		* @param {String} type The name of the event
		* @param {Object} [options] A dictionary object that allows for setting
		*     attributes via object members of the same name
		* @param {*} [options.error=null] The error that generated this event
		* @param {String} [options.message=''] The error message
		*/
		constructor(type, options = {}) {
			super(type);
			this[kError] = options.error === void 0 ? null : options.error;
			this[kMessage] = options.message === void 0 ? "" : options.message;
		}
		/**
		* @type {*}
		*/
		get error() {
			return this[kError];
		}
		/**
		* @type {String}
		*/
		get message() {
			return this[kMessage];
		}
	};
	Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
	Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
	/**
	* Class representing a message event.
	*
	* @extends Event
	*/
	var MessageEvent = class extends Event {
		/**
		* Create a new `MessageEvent`.
		*
		* @param {String} type The name of the event
		* @param {Object} [options] A dictionary object that allows for setting
		*     attributes via object members of the same name
		* @param {*} [options.data=null] The message content
		*/
		constructor(type, options = {}) {
			super(type);
			this[kData] = options.data === void 0 ? null : options.data;
		}
		/**
		* @type {*}
		*/
		get data() {
			return this[kData];
		}
	};
	Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
	module.exports = {
		CloseEvent,
		ErrorEvent,
		Event,
		EventTarget: {
			/**
			* Register an event listener.
			*
			* @param {String} type A string representing the event type to listen for
			* @param {(Function|Object)} handler The listener to add
			* @param {Object} [options] An options object specifies characteristics about
			*     the event listener
			* @param {Boolean} [options.once=false] A `Boolean` indicating that the
			*     listener should be invoked at most once after being added. If `true`,
			*     the listener would be automatically removed when invoked.
			* @public
			*/
			addEventListener(type, handler, options = {}) {
				for (const listener of this.listeners(type)) if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) return;
				let wrapper;
				if (type === "message") wrapper = function onMessage(data, isBinary) {
					const event = new MessageEvent("message", { data: isBinary ? data : data.toString() });
					event[kTarget] = this;
					callListener(handler, this, event);
				};
				else if (type === "close") wrapper = function onClose(code, message) {
					const event = new CloseEvent("close", {
						code,
						reason: message.toString(),
						wasClean: this._closeFrameReceived && this._closeFrameSent
					});
					event[kTarget] = this;
					callListener(handler, this, event);
				};
				else if (type === "error") wrapper = function onError(error) {
					const event = new ErrorEvent("error", {
						error,
						message: error.message
					});
					event[kTarget] = this;
					callListener(handler, this, event);
				};
				else if (type === "open") wrapper = function onOpen() {
					const event = new Event("open");
					event[kTarget] = this;
					callListener(handler, this, event);
				};
				else return;
				wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
				wrapper[kListener] = handler;
				if (options.once) this.once(type, wrapper);
				else this.on(type, wrapper);
			},
			/**
			* Remove an event listener.
			*
			* @param {String} type A string representing the event type to remove
			* @param {(Function|Object)} handler The listener to remove
			* @public
			*/
			removeEventListener(type, handler) {
				for (const listener of this.listeners(type)) if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
					this.removeListener(type, listener);
					break;
				}
			}
		},
		MessageEvent
	};
	/**
	* Call an event listener
	*
	* @param {(Function|Object)} listener The listener to call
	* @param {*} thisArg The value to use as `this`` when calling the listener
	* @param {Event} event The event to pass to the listener
	* @private
	*/
	function callListener(listener, thisArg, event) {
		if (typeof listener === "object" && listener.handleEvent) listener.handleEvent.call(listener, event);
		else listener.call(thisArg, event);
	}
}));
//#endregion
//#region node_modules/ws/lib/extension.js
var require_extension = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { tokenChars } = require_validation();
	/**
	* Adds an offer to the map of extension offers or a parameter to the map of
	* parameters.
	*
	* @param {Object} dest The map of extension offers or parameters
	* @param {String} name The extension or parameter name
	* @param {(Object|Boolean|String)} elem The extension parameters or the
	*     parameter value
	* @private
	*/
	function push(dest, name, elem) {
		if (dest[name] === void 0) dest[name] = [elem];
		else dest[name].push(elem);
	}
	/**
	* Parses the `Sec-WebSocket-Extensions` header into an object.
	*
	* @param {String} header The field value of the header
	* @return {Object} The parsed object
	* @public
	*/
	function parse(header) {
		const offers = Object.create(null);
		let params = Object.create(null);
		let mustUnescape = false;
		let isEscaping = false;
		let inQuotes = false;
		let extensionName;
		let paramName;
		let start = -1;
		let code = -1;
		let end = -1;
		let i = 0;
		for (; i < header.length; i++) {
			code = header.charCodeAt(i);
			if (extensionName === void 0) {
				if (end === -1 && tokenChars[code] === 1) {
					if (start === -1) start = i;
				} else if (i !== 0 && (code === 32 || code === 9)) {
					if (end === -1 && start !== -1) end = i;
				} else if (code === 59 || code === 44) {
					if (start === -1) throw new SyntaxError(`Unexpected character at index ${i}`);
					if (end === -1) end = i;
					const name = header.slice(start, end);
					if (code === 44) {
						push(offers, name, params);
						params = Object.create(null);
					} else extensionName = name;
					start = end = -1;
				} else throw new SyntaxError(`Unexpected character at index ${i}`);
			} else if (paramName === void 0) {
				if (end === -1 && tokenChars[code] === 1) {
					if (start === -1) start = i;
				} else if (code === 32 || code === 9) {
					if (end === -1 && start !== -1) end = i;
				} else if (code === 59 || code === 44) {
					if (start === -1) throw new SyntaxError(`Unexpected character at index ${i}`);
					if (end === -1) end = i;
					push(params, header.slice(start, end), true);
					if (code === 44) {
						push(offers, extensionName, params);
						params = Object.create(null);
						extensionName = void 0;
					}
					start = end = -1;
				} else if (code === 61 && start !== -1 && end === -1) {
					paramName = header.slice(start, i);
					start = end = -1;
				} else throw new SyntaxError(`Unexpected character at index ${i}`);
			} else if (isEscaping) {
				if (tokenChars[code] !== 1) throw new SyntaxError(`Unexpected character at index ${i}`);
				if (start === -1) start = i;
				else if (!mustUnescape) mustUnescape = true;
				isEscaping = false;
			} else if (inQuotes) {
				if (tokenChars[code] === 1) {
					if (start === -1) start = i;
				} else if (code === 34 && start !== -1) {
					inQuotes = false;
					end = i;
				} else if (code === 92) isEscaping = true;
				else throw new SyntaxError(`Unexpected character at index ${i}`);
			} else if (code === 34 && header.charCodeAt(i - 1) === 61) inQuotes = true;
			else if (end === -1 && tokenChars[code] === 1) {
				if (start === -1) start = i;
			} else if (start !== -1 && (code === 32 || code === 9)) {
				if (end === -1) end = i;
			} else if (code === 59 || code === 44) {
				if (start === -1) throw new SyntaxError(`Unexpected character at index ${i}`);
				if (end === -1) end = i;
				let value = header.slice(start, end);
				if (mustUnescape) {
					value = value.replace(/\\/g, "");
					mustUnescape = false;
				}
				push(params, paramName, value);
				if (code === 44) {
					push(offers, extensionName, params);
					params = Object.create(null);
					extensionName = void 0;
				}
				paramName = void 0;
				start = end = -1;
			} else throw new SyntaxError(`Unexpected character at index ${i}`);
		}
		if (start === -1 || inQuotes || code === 32 || code === 9) throw new SyntaxError("Unexpected end of input");
		if (end === -1) end = i;
		const token = header.slice(start, end);
		if (extensionName === void 0) push(offers, token, params);
		else {
			if (paramName === void 0) push(params, token, true);
			else if (mustUnescape) push(params, paramName, token.replace(/\\/g, ""));
			else push(params, paramName, token);
			push(offers, extensionName, params);
		}
		return offers;
	}
	/**
	* Builds the `Sec-WebSocket-Extensions` header field value.
	*
	* @param {Object} extensions The map of extensions and parameters to format
	* @return {String} A string representing the given object
	* @public
	*/
	function format(extensions) {
		return Object.keys(extensions).map((extension) => {
			let configurations = extensions[extension];
			if (!Array.isArray(configurations)) configurations = [configurations];
			return configurations.map((params) => {
				return [extension].concat(Object.keys(params).map((k) => {
					let values = params[k];
					if (!Array.isArray(values)) values = [values];
					return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
				})).join("; ");
			}).join(", ");
		}).join(", ");
	}
	module.exports = {
		format,
		parse
	};
}));
//#endregion
//#region node_modules/ws/lib/websocket.js
var require_websocket = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var EventEmitter$1 = __require("events");
	var https = __require("https");
	var http$1 = __require("http");
	var net = __require("net");
	var tls = __require("tls");
	var { randomBytes: randomBytes$1, createHash: createHash$2 } = __require("crypto");
	var { Duplex: Duplex$2, Readable } = __require("stream");
	var { URL: URL$1 } = __require("url");
	var PerMessageDeflate = require_permessage_deflate();
	var Receiver = require_receiver();
	var Sender = require_sender();
	var { isBlob } = require_validation();
	var { BINARY_TYPES, CLOSE_TIMEOUT, EMPTY_BUFFER, GUID, kForOnEventAttribute, kListener, kStatusCode, kWebSocket, NOOP } = require_constants();
	var { EventTarget: { addEventListener, removeEventListener } } = require_event_target();
	var { format, parse } = require_extension();
	var { toBuffer } = require_buffer_util();
	var kAborted = Symbol("kAborted");
	var protocolVersions = [8, 13];
	var readyStates = [
		"CONNECTING",
		"OPEN",
		"CLOSING",
		"CLOSED"
	];
	var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
	/**
	* Class representing a WebSocket.
	*
	* @extends EventEmitter
	*/
	var WebSocket = class WebSocket extends EventEmitter$1 {
		/**
		* Create a new `WebSocket`.
		*
		* @param {(String|URL)} address The URL to which to connect
		* @param {(String|String[])} [protocols] The subprotocols
		* @param {Object} [options] Connection options
		*/
		constructor(address, protocols, options) {
			super();
			this._binaryType = BINARY_TYPES[0];
			this._closeCode = 1006;
			this._closeFrameReceived = false;
			this._closeFrameSent = false;
			this._closeMessage = EMPTY_BUFFER;
			this._closeTimer = null;
			this._errorEmitted = false;
			this._extensions = {};
			this._paused = false;
			this._protocol = "";
			this._readyState = WebSocket.CONNECTING;
			this._receiver = null;
			this._sender = null;
			this._socket = null;
			if (address !== null) {
				this._bufferedAmount = 0;
				this._isServer = false;
				this._redirects = 0;
				if (protocols === void 0) {
					if (!options || options.protocols === void 0) protocols = [];
					else if (Array.isArray(options.protocols)) protocols = options.protocols;
					else protocols = [options.protocols];
				} else if (!Array.isArray(protocols)) {
					if (typeof protocols === "object" && protocols !== null) {
						options = protocols;
						if (options.protocols === void 0) protocols = [];
						else if (Array.isArray(options.protocols)) protocols = options.protocols;
						else protocols = [options.protocols];
					} else protocols = [protocols];
				}
				initAsClient(this, address, protocols, options);
			} else {
				this._autoPong = options.autoPong;
				this._closeTimeout = options.closeTimeout;
				this._isServer = true;
			}
		}
		/**
		* For historical reasons, the custom "nodebuffer" type is used by the default
		* instead of "blob".
		*
		* @type {String}
		*/
		get binaryType() {
			return this._binaryType;
		}
		set binaryType(type) {
			if (!BINARY_TYPES.includes(type)) return;
			this._binaryType = type;
			if (this._receiver) this._receiver._binaryType = type;
		}
		/**
		* @type {Number}
		*/
		get bufferedAmount() {
			if (!this._socket) return this._bufferedAmount;
			return this._socket._writableState.length + this._sender._bufferedBytes;
		}
		/**
		* @type {String}
		*/
		get extensions() {
			return Object.keys(this._extensions).join();
		}
		/**
		* @type {Boolean}
		*/
		get isPaused() {
			return this._paused;
		}
		/**
		* @type {Function}
		*/
		/* istanbul ignore next */
		get onclose() {
			return null;
		}
		/**
		* @type {Function}
		*/
		/* istanbul ignore next */
		get onerror() {
			return null;
		}
		/**
		* @type {Function}
		*/
		/* istanbul ignore next */
		get onopen() {
			return null;
		}
		/**
		* @type {Function}
		*/
		/* istanbul ignore next */
		get onmessage() {
			return null;
		}
		/**
		* @type {String}
		*/
		get protocol() {
			return this._protocol;
		}
		/**
		* @type {Number}
		*/
		get readyState() {
			return this._readyState;
		}
		/**
		* @type {String}
		*/
		get url() {
			return this._url;
		}
		/**
		* Set up the socket and the internal resources.
		*
		* @param {Duplex} socket The network socket between the server and client
		* @param {Buffer} head The first packet of the upgraded stream
		* @param {Object} options Options object
		* @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
		*     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
		*     multiple times in the same tick
		* @param {Function} [options.generateMask] The function used to generate the
		*     masking key
		* @param {Number} [options.maxBufferedChunks=0] The maximum number of
		*     buffered data chunks
		* @param {Number} [options.maxFragments=0] The maximum number of message
		*     fragments
		* @param {Number} [options.maxPayload=0] The maximum allowed message size
		* @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
		*     not to skip UTF-8 validation for text and close messages
		* @private
		*/
		setSocket(socket, head, options) {
			const receiver = new Receiver({
				allowSynchronousEvents: options.allowSynchronousEvents,
				binaryType: this.binaryType,
				extensions: this._extensions,
				isServer: this._isServer,
				maxBufferedChunks: options.maxBufferedChunks,
				maxFragments: options.maxFragments,
				maxPayload: options.maxPayload,
				skipUTF8Validation: options.skipUTF8Validation
			});
			const sender = new Sender(socket, this._extensions, options.generateMask);
			this._receiver = receiver;
			this._sender = sender;
			this._socket = socket;
			receiver[kWebSocket] = this;
			sender[kWebSocket] = this;
			socket[kWebSocket] = this;
			receiver.on("conclude", receiverOnConclude);
			receiver.on("drain", receiverOnDrain);
			receiver.on("error", receiverOnError);
			receiver.on("message", receiverOnMessage);
			receiver.on("ping", receiverOnPing);
			receiver.on("pong", receiverOnPong);
			sender.onerror = senderOnError;
			if (socket.setTimeout) socket.setTimeout(0);
			if (socket.setNoDelay) socket.setNoDelay();
			if (head.length > 0) socket.unshift(head);
			socket.on("close", socketOnClose);
			socket.on("data", socketOnData);
			socket.on("end", socketOnEnd);
			socket.on("error", socketOnError);
			this._readyState = WebSocket.OPEN;
			this.emit("open");
		}
		/**
		* Emit the `'close'` event.
		*
		* @private
		*/
		emitClose() {
			if (!this._socket) {
				this._readyState = WebSocket.CLOSED;
				this.emit("close", this._closeCode, this._closeMessage);
				return;
			}
			if (this._extensions[PerMessageDeflate.extensionName]) this._extensions[PerMessageDeflate.extensionName].cleanup();
			this._receiver.removeAllListeners();
			this._readyState = WebSocket.CLOSED;
			this.emit("close", this._closeCode, this._closeMessage);
		}
		/**
		* Start a closing handshake.
		*
		*          +----------+   +-----------+   +----------+
		*     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
		*    |     +----------+   +-----------+   +----------+     |
		*          +----------+   +-----------+         |
		* CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
		*          +----------+   +-----------+   |
		*    |           |                        |   +---+        |
		*                +------------------------+-->|fin| - - - -
		*    |         +---+                      |   +---+
		*     - - - - -|fin|<---------------------+
		*              +---+
		*
		* @param {Number} [code] Status code explaining why the connection is closing
		* @param {(String|Buffer)} [data] The reason why the connection is
		*     closing
		* @public
		*/
		close(code, data) {
			if (this.readyState === WebSocket.CLOSED) return;
			if (this.readyState === WebSocket.CONNECTING) {
				abortHandshake(this, this._req, "WebSocket was closed before the connection was established");
				return;
			}
			if (this.readyState === WebSocket.CLOSING) {
				if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) this._socket.end();
				return;
			}
			this._sender.close(code, data, !this._isServer, (err) => {
				if (err) return;
				this._closeFrameSent = true;
				if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) this._socket.end();
			});
			this._readyState = WebSocket.CLOSING;
			setCloseTimer(this);
		}
		/**
		* Pause the socket.
		*
		* @public
		*/
		pause() {
			if (this.readyState === WebSocket.CONNECTING || this.readyState === WebSocket.CLOSED) return;
			this._paused = true;
			this._socket.pause();
		}
		/**
		* Send a ping.
		*
		* @param {*} [data] The data to send
		* @param {Boolean} [mask] Indicates whether or not to mask `data`
		* @param {Function} [cb] Callback which is executed when the ping is sent
		* @public
		*/
		ping(data, mask, cb) {
			if (this.readyState === WebSocket.CONNECTING) throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
			if (typeof data === "function") {
				cb = data;
				data = mask = void 0;
			} else if (typeof mask === "function") {
				cb = mask;
				mask = void 0;
			}
			if (typeof data === "number") data = data.toString();
			if (this.readyState !== WebSocket.OPEN) {
				sendAfterClose(this, data, cb);
				return;
			}
			if (mask === void 0) mask = !this._isServer;
			this._sender.ping(data || EMPTY_BUFFER, mask, cb);
		}
		/**
		* Send a pong.
		*
		* @param {*} [data] The data to send
		* @param {Boolean} [mask] Indicates whether or not to mask `data`
		* @param {Function} [cb] Callback which is executed when the pong is sent
		* @public
		*/
		pong(data, mask, cb) {
			if (this.readyState === WebSocket.CONNECTING) throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
			if (typeof data === "function") {
				cb = data;
				data = mask = void 0;
			} else if (typeof mask === "function") {
				cb = mask;
				mask = void 0;
			}
			if (typeof data === "number") data = data.toString();
			if (this.readyState !== WebSocket.OPEN) {
				sendAfterClose(this, data, cb);
				return;
			}
			if (mask === void 0) mask = !this._isServer;
			this._sender.pong(data || EMPTY_BUFFER, mask, cb);
		}
		/**
		* Resume the socket.
		*
		* @public
		*/
		resume() {
			if (this.readyState === WebSocket.CONNECTING || this.readyState === WebSocket.CLOSED) return;
			this._paused = false;
			if (!this._receiver._writableState.needDrain) this._socket.resume();
		}
		/**
		* Send a data message.
		*
		* @param {*} data The message to send
		* @param {Object} [options] Options object
		* @param {Boolean} [options.binary] Specifies whether `data` is binary or
		*     text
		* @param {Boolean} [options.compress] Specifies whether or not to compress
		*     `data`
		* @param {Boolean} [options.fin=true] Specifies whether the fragment is the
		*     last one
		* @param {Boolean} [options.mask] Specifies whether or not to mask `data`
		* @param {Function} [cb] Callback which is executed when data is written out
		* @public
		*/
		send(data, options, cb) {
			if (this.readyState === WebSocket.CONNECTING) throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
			if (typeof options === "function") {
				cb = options;
				options = {};
			}
			if (typeof data === "number") data = data.toString();
			if (this.readyState !== WebSocket.OPEN) {
				sendAfterClose(this, data, cb);
				return;
			}
			const opts = {
				binary: typeof data !== "string",
				mask: !this._isServer,
				compress: true,
				fin: true,
				...options
			};
			if (!this._extensions[PerMessageDeflate.extensionName]) opts.compress = false;
			this._sender.send(data || EMPTY_BUFFER, opts, cb);
		}
		/**
		* Forcibly close the connection.
		*
		* @public
		*/
		terminate() {
			if (this.readyState === WebSocket.CLOSED) return;
			if (this.readyState === WebSocket.CONNECTING) {
				abortHandshake(this, this._req, "WebSocket was closed before the connection was established");
				return;
			}
			if (this._socket) {
				this._readyState = WebSocket.CLOSING;
				this._socket.destroy();
			}
		}
	};
	/**
	* @constant {Number} CONNECTING
	* @memberof WebSocket
	*/
	Object.defineProperty(WebSocket, "CONNECTING", {
		enumerable: true,
		value: readyStates.indexOf("CONNECTING")
	});
	/**
	* @constant {Number} CONNECTING
	* @memberof WebSocket.prototype
	*/
	Object.defineProperty(WebSocket.prototype, "CONNECTING", {
		enumerable: true,
		value: readyStates.indexOf("CONNECTING")
	});
	/**
	* @constant {Number} OPEN
	* @memberof WebSocket
	*/
	Object.defineProperty(WebSocket, "OPEN", {
		enumerable: true,
		value: readyStates.indexOf("OPEN")
	});
	/**
	* @constant {Number} OPEN
	* @memberof WebSocket.prototype
	*/
	Object.defineProperty(WebSocket.prototype, "OPEN", {
		enumerable: true,
		value: readyStates.indexOf("OPEN")
	});
	/**
	* @constant {Number} CLOSING
	* @memberof WebSocket
	*/
	Object.defineProperty(WebSocket, "CLOSING", {
		enumerable: true,
		value: readyStates.indexOf("CLOSING")
	});
	/**
	* @constant {Number} CLOSING
	* @memberof WebSocket.prototype
	*/
	Object.defineProperty(WebSocket.prototype, "CLOSING", {
		enumerable: true,
		value: readyStates.indexOf("CLOSING")
	});
	/**
	* @constant {Number} CLOSED
	* @memberof WebSocket
	*/
	Object.defineProperty(WebSocket, "CLOSED", {
		enumerable: true,
		value: readyStates.indexOf("CLOSED")
	});
	/**
	* @constant {Number} CLOSED
	* @memberof WebSocket.prototype
	*/
	Object.defineProperty(WebSocket.prototype, "CLOSED", {
		enumerable: true,
		value: readyStates.indexOf("CLOSED")
	});
	[
		"binaryType",
		"bufferedAmount",
		"extensions",
		"isPaused",
		"protocol",
		"readyState",
		"url"
	].forEach((property) => {
		Object.defineProperty(WebSocket.prototype, property, { enumerable: true });
	});
	[
		"open",
		"error",
		"close",
		"message"
	].forEach((method) => {
		Object.defineProperty(WebSocket.prototype, `on${method}`, {
			enumerable: true,
			get() {
				for (const listener of this.listeners(method)) if (listener[kForOnEventAttribute]) return listener[kListener];
				return null;
			},
			set(handler) {
				for (const listener of this.listeners(method)) if (listener[kForOnEventAttribute]) {
					this.removeListener(method, listener);
					break;
				}
				if (typeof handler !== "function") return;
				this.addEventListener(method, handler, { [kForOnEventAttribute]: true });
			}
		});
	});
	WebSocket.prototype.addEventListener = addEventListener;
	WebSocket.prototype.removeEventListener = removeEventListener;
	module.exports = WebSocket;
	/**
	* Initialize a WebSocket client.
	*
	* @param {WebSocket} websocket The client to initialize
	* @param {(String|URL)} address The URL to which to connect
	* @param {Array} protocols The subprotocols
	* @param {Object} [options] Connection options
	* @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether any
	*     of the `'message'`, `'ping'`, and `'pong'` events can be emitted multiple
	*     times in the same tick
	* @param {Boolean} [options.autoPong=true] Specifies whether or not to
	*     automatically send a pong in response to a ping
	* @param {Number} [options.closeTimeout=30000] Duration in milliseconds to wait
	*     for the closing handshake to finish after `websocket.close()` is called
	* @param {Function} [options.finishRequest] A function which can be used to
	*     customize the headers of each http request before it is sent
	* @param {Boolean} [options.followRedirects=false] Whether or not to follow
	*     redirects
	* @param {Function} [options.generateMask] The function used to generate the
	*     masking key
	* @param {Number} [options.handshakeTimeout] Timeout in milliseconds for the
	*     handshake request
	* @param {Number} [options.maxBufferedChunks=262144] The maximum number of
	*     buffered data chunks
	* @param {Number} [options.maxFragments=16384] The maximum number of message
	*     fragments
	* @param {Number} [options.maxPayload=104857600] The maximum allowed message
	*     size
	* @param {Number} [options.maxRedirects=10] The maximum number of redirects
	*     allowed
	* @param {String} [options.origin] Value of the `Origin` or
	*     `Sec-WebSocket-Origin` header
	* @param {(Boolean|Object)} [options.perMessageDeflate=true] Enable/disable
	*     permessage-deflate
	* @param {Number} [options.protocolVersion=13] Value of the
	*     `Sec-WebSocket-Version` header
	* @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
	*     not to skip UTF-8 validation for text and close messages
	* @private
	*/
	function initAsClient(websocket, address, protocols, options) {
		const opts = {
			allowSynchronousEvents: true,
			autoPong: true,
			closeTimeout: CLOSE_TIMEOUT,
			protocolVersion: protocolVersions[1],
			maxBufferedChunks: 262144,
			maxFragments: 16384,
			maxPayload: 104857600,
			skipUTF8Validation: false,
			perMessageDeflate: true,
			followRedirects: false,
			maxRedirects: 10,
			...options,
			socketPath: void 0,
			hostname: void 0,
			protocol: void 0,
			protocols: void 0,
			timeout: void 0,
			method: "GET",
			host: void 0,
			path: void 0,
			port: void 0
		};
		websocket._autoPong = opts.autoPong;
		websocket._closeTimeout = opts.closeTimeout;
		if (!protocolVersions.includes(opts.protocolVersion)) throw new RangeError(`Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`);
		let parsedUrl;
		if (address instanceof URL$1) parsedUrl = address;
		else try {
			parsedUrl = new URL$1(address);
		} catch {
			throw new SyntaxError(`Invalid URL: ${address}`);
		}
		if (parsedUrl.protocol === "http:") parsedUrl.protocol = "ws:";
		else if (parsedUrl.protocol === "https:") parsedUrl.protocol = "wss:";
		websocket._url = parsedUrl.href;
		const isSecure = parsedUrl.protocol === "wss:";
		const isIpcUrl = parsedUrl.protocol === "ws+unix:";
		let invalidUrlMessage;
		if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) invalidUrlMessage = "The URL's protocol must be one of \"ws:\", \"wss:\", \"http:\", \"https:\", or \"ws+unix:\"";
		else if (isIpcUrl && !parsedUrl.pathname) invalidUrlMessage = "The URL's pathname is empty";
		else if (parsedUrl.hash) invalidUrlMessage = "The URL contains a fragment identifier";
		if (invalidUrlMessage) {
			const err = new SyntaxError(invalidUrlMessage);
			if (websocket._redirects === 0) throw err;
			else {
				emitErrorAndClose(websocket, err);
				return;
			}
		}
		const defaultPort = isSecure ? 443 : 80;
		const key = randomBytes$1(16).toString("base64");
		const request = isSecure ? https.request : http$1.request;
		const protocolSet = /* @__PURE__ */ new Set();
		let perMessageDeflate;
		opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
		opts.defaultPort = opts.defaultPort || defaultPort;
		opts.port = parsedUrl.port || defaultPort;
		opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
		opts.headers = {
			...opts.headers,
			"Sec-WebSocket-Version": opts.protocolVersion,
			"Sec-WebSocket-Key": key,
			Connection: "Upgrade",
			Upgrade: "websocket"
		};
		opts.path = parsedUrl.pathname + parsedUrl.search;
		opts.timeout = opts.handshakeTimeout;
		if (opts.perMessageDeflate) {
			perMessageDeflate = new PerMessageDeflate({
				...opts.perMessageDeflate,
				isServer: false,
				maxPayload: opts.maxPayload
			});
			opts.headers["Sec-WebSocket-Extensions"] = format({ [PerMessageDeflate.extensionName]: perMessageDeflate.offer() });
		}
		if (protocols.length) {
			for (const protocol of protocols) {
				if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) throw new SyntaxError("An invalid or duplicated subprotocol was specified");
				protocolSet.add(protocol);
			}
			opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
		}
		if (opts.origin) {
			if (opts.protocolVersion < 13) opts.headers["Sec-WebSocket-Origin"] = opts.origin;
			else opts.headers.Origin = opts.origin;
		}
		if (parsedUrl.username || parsedUrl.password) opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
		if (isIpcUrl) {
			const parts = opts.path.split(":");
			opts.socketPath = parts[0];
			opts.path = parts[1];
		}
		let req;
		if (opts.followRedirects) {
			if (websocket._redirects === 0) {
				websocket._originalIpc = isIpcUrl;
				websocket._originalSecure = isSecure;
				websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
				const headers = options && options.headers;
				options = {
					...options,
					headers: {}
				};
				if (headers) for (const [key, value] of Object.entries(headers)) options.headers[key.toLowerCase()] = value;
			} else if (websocket.listenerCount("redirect") === 0) {
				const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
				if (!isSameHost || websocket._originalSecure && !isSecure) {
					delete opts.headers.authorization;
					delete opts.headers.cookie;
					if (!isSameHost) delete opts.headers.host;
					opts.auth = void 0;
				}
			}
			if (opts.auth && !options.headers.authorization) options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
			req = websocket._req = request(opts);
			if (websocket._redirects) websocket.emit("redirect", websocket.url, req);
		} else req = websocket._req = request(opts);
		if (opts.timeout) req.on("timeout", () => {
			abortHandshake(websocket, req, "Opening handshake has timed out");
		});
		req.on("error", (err) => {
			if (req === null || req[kAborted]) return;
			req = websocket._req = null;
			emitErrorAndClose(websocket, err);
		});
		req.on("response", (res) => {
			const location = res.headers.location;
			const statusCode = res.statusCode;
			if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
				if (++websocket._redirects > opts.maxRedirects) {
					abortHandshake(websocket, req, "Maximum redirects exceeded");
					return;
				}
				req.abort();
				let addr;
				try {
					addr = new URL$1(location, address);
				} catch (e) {
					emitErrorAndClose(websocket, /* @__PURE__ */ new SyntaxError(`Invalid URL: ${location}`));
					return;
				}
				initAsClient(websocket, addr, protocols, options);
			} else if (!websocket.emit("unexpected-response", req, res)) abortHandshake(websocket, req, `Unexpected server response: ${res.statusCode}`);
		});
		req.on("upgrade", (res, socket, head) => {
			websocket.emit("upgrade", res);
			if (websocket.readyState !== WebSocket.CONNECTING) return;
			req = websocket._req = null;
			const upgrade = res.headers.upgrade;
			if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
				abortHandshake(websocket, socket, "Invalid Upgrade header");
				return;
			}
			const digest = createHash$2("sha1").update(key + GUID).digest("base64");
			if (res.headers["sec-websocket-accept"] !== digest) {
				abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
				return;
			}
			const serverProt = res.headers["sec-websocket-protocol"];
			let protError;
			if (serverProt !== void 0) {
				if (!protocolSet.size) protError = "Server sent a subprotocol but none was requested";
				else if (!protocolSet.has(serverProt)) protError = "Server sent an invalid subprotocol";
			} else if (protocolSet.size) protError = "Server sent no subprotocol";
			if (protError) {
				abortHandshake(websocket, socket, protError);
				return;
			}
			if (serverProt) websocket._protocol = serverProt;
			const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
			if (secWebSocketExtensions !== void 0) {
				if (!perMessageDeflate) {
					abortHandshake(websocket, socket, "Server sent a Sec-WebSocket-Extensions header but no extension was requested");
					return;
				}
				let extensions;
				try {
					extensions = parse(secWebSocketExtensions);
				} catch (err) {
					abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Extensions header");
					return;
				}
				const extensionNames = Object.keys(extensions);
				if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate.extensionName) {
					abortHandshake(websocket, socket, "Server indicated an extension that was not requested");
					return;
				}
				try {
					perMessageDeflate.accept(extensions[PerMessageDeflate.extensionName]);
				} catch (err) {
					abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Extensions header");
					return;
				}
				websocket._extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
			}
			websocket.setSocket(socket, head, {
				allowSynchronousEvents: opts.allowSynchronousEvents,
				generateMask: opts.generateMask,
				maxBufferedChunks: opts.maxBufferedChunks,
				maxFragments: opts.maxFragments,
				maxPayload: opts.maxPayload,
				skipUTF8Validation: opts.skipUTF8Validation
			});
		});
		if (opts.finishRequest) opts.finishRequest(req, websocket);
		else req.end();
	}
	/**
	* Emit the `'error'` and `'close'` events.
	*
	* @param {WebSocket} websocket The WebSocket instance
	* @param {Error} The error to emit
	* @private
	*/
	function emitErrorAndClose(websocket, err) {
		websocket._readyState = WebSocket.CLOSING;
		websocket._errorEmitted = true;
		websocket.emit("error", err);
		websocket.emitClose();
	}
	/**
	* Create a `net.Socket` and initiate a connection.
	*
	* @param {Object} options Connection options
	* @return {net.Socket} The newly created socket used to start the connection
	* @private
	*/
	function netConnect(options) {
		options.path = options.socketPath;
		return net.connect(options);
	}
	/**
	* Create a `tls.TLSSocket` and initiate a connection.
	*
	* @param {Object} options Connection options
	* @return {tls.TLSSocket} The newly created socket used to start the connection
	* @private
	*/
	function tlsConnect(options) {
		options.path = void 0;
		if (!options.servername && options.servername !== "") options.servername = net.isIP(options.host) ? "" : options.host;
		return tls.connect(options);
	}
	/**
	* Abort the handshake and emit an error.
	*
	* @param {WebSocket} websocket The WebSocket instance
	* @param {(http.ClientRequest|net.Socket|tls.Socket)} stream The request to
	*     abort or the socket to destroy
	* @param {String} message The error message
	* @private
	*/
	function abortHandshake(websocket, stream, message) {
		websocket._readyState = WebSocket.CLOSING;
		const err = new Error(message);
		Error.captureStackTrace(err, abortHandshake);
		if (stream.setHeader) {
			stream[kAborted] = true;
			stream.abort();
			if (stream.socket && !stream.socket.destroyed) stream.socket.destroy();
			process.nextTick(emitErrorAndClose, websocket, err);
		} else {
			stream.destroy(err);
			stream.once("error", websocket.emit.bind(websocket, "error"));
			stream.once("close", websocket.emitClose.bind(websocket));
		}
	}
	/**
	* Handle cases where the `ping()`, `pong()`, or `send()` methods are called
	* when the `readyState` attribute is `CLOSING` or `CLOSED`.
	*
	* @param {WebSocket} websocket The WebSocket instance
	* @param {*} [data] The data to send
	* @param {Function} [cb] Callback
	* @private
	*/
	function sendAfterClose(websocket, data, cb) {
		if (data) {
			const length = isBlob(data) ? data.size : toBuffer(data).length;
			if (websocket._socket) websocket._sender._bufferedBytes += length;
			else websocket._bufferedAmount += length;
		}
		if (cb) {
			const err = /* @__PURE__ */ new Error(`WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`);
			process.nextTick(cb, err);
		}
	}
	/**
	* The listener of the `Receiver` `'conclude'` event.
	*
	* @param {Number} code The status code
	* @param {Buffer} reason The reason for closing
	* @private
	*/
	function receiverOnConclude(code, reason) {
		const websocket = this[kWebSocket];
		websocket._closeFrameReceived = true;
		websocket._closeMessage = reason;
		websocket._closeCode = code;
		if (websocket._socket[kWebSocket] === void 0) return;
		websocket._socket.removeListener("data", socketOnData);
		process.nextTick(resume, websocket._socket);
		if (code === 1005) websocket.close();
		else websocket.close(code, reason);
	}
	/**
	* The listener of the `Receiver` `'drain'` event.
	*
	* @private
	*/
	function receiverOnDrain() {
		const websocket = this[kWebSocket];
		if (!websocket.isPaused) websocket._socket.resume();
	}
	/**
	* The listener of the `Receiver` `'error'` event.
	*
	* @param {(RangeError|Error)} err The emitted error
	* @private
	*/
	function receiverOnError(err) {
		const websocket = this[kWebSocket];
		if (websocket._socket[kWebSocket] !== void 0) {
			websocket._socket.removeListener("data", socketOnData);
			process.nextTick(resume, websocket._socket);
			websocket.close(err[kStatusCode]);
		}
		if (!websocket._errorEmitted) {
			websocket._errorEmitted = true;
			websocket.emit("error", err);
		}
	}
	/**
	* The listener of the `Receiver` `'finish'` event.
	*
	* @private
	*/
	function receiverOnFinish() {
		this[kWebSocket].emitClose();
	}
	/**
	* The listener of the `Receiver` `'message'` event.
	*
	* @param {Buffer|ArrayBuffer|Buffer[])} data The message
	* @param {Boolean} isBinary Specifies whether the message is binary or not
	* @private
	*/
	function receiverOnMessage(data, isBinary) {
		this[kWebSocket].emit("message", data, isBinary);
	}
	/**
	* The listener of the `Receiver` `'ping'` event.
	*
	* @param {Buffer} data The data included in the ping frame
	* @private
	*/
	function receiverOnPing(data) {
		const websocket = this[kWebSocket];
		if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
		websocket.emit("ping", data);
	}
	/**
	* The listener of the `Receiver` `'pong'` event.
	*
	* @param {Buffer} data The data included in the pong frame
	* @private
	*/
	function receiverOnPong(data) {
		this[kWebSocket].emit("pong", data);
	}
	/**
	* Resume a readable stream
	*
	* @param {Readable} stream The readable stream
	* @private
	*/
	function resume(stream) {
		stream.resume();
	}
	/**
	* The `Sender` error event handler.
	*
	* @param {Error} The error
	* @private
	*/
	function senderOnError(err) {
		const websocket = this[kWebSocket];
		if (websocket.readyState === WebSocket.CLOSED) return;
		if (websocket.readyState === WebSocket.OPEN) {
			websocket._readyState = WebSocket.CLOSING;
			setCloseTimer(websocket);
		}
		this._socket.end();
		if (!websocket._errorEmitted) {
			websocket._errorEmitted = true;
			websocket.emit("error", err);
		}
	}
	/**
	* Set a timer to destroy the underlying raw socket of a WebSocket.
	*
	* @param {WebSocket} websocket The WebSocket instance
	* @private
	*/
	function setCloseTimer(websocket) {
		websocket._closeTimer = setTimeout(websocket._socket.destroy.bind(websocket._socket), websocket._closeTimeout);
	}
	/**
	* The listener of the socket `'close'` event.
	*
	* @private
	*/
	function socketOnClose() {
		const websocket = this[kWebSocket];
		this.removeListener("close", socketOnClose);
		this.removeListener("data", socketOnData);
		this.removeListener("end", socketOnEnd);
		websocket._readyState = WebSocket.CLOSING;
		if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
			const chunk = this.read(this._readableState.length);
			websocket._receiver.write(chunk);
		}
		websocket._receiver.end();
		this[kWebSocket] = void 0;
		clearTimeout(websocket._closeTimer);
		if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) websocket.emitClose();
		else {
			websocket._receiver.on("error", receiverOnFinish);
			websocket._receiver.on("finish", receiverOnFinish);
		}
	}
	/**
	* The listener of the socket `'data'` event.
	*
	* @param {Buffer} chunk A chunk of data
	* @private
	*/
	function socketOnData(chunk) {
		if (!this[kWebSocket]._receiver.write(chunk)) this.pause();
	}
	/**
	* The listener of the socket `'end'` event.
	*
	* @private
	*/
	function socketOnEnd() {
		const websocket = this[kWebSocket];
		websocket._readyState = WebSocket.CLOSING;
		websocket._receiver.end();
		this.end();
	}
	/**
	* The listener of the socket `'error'` event.
	*
	* @private
	*/
	function socketOnError() {
		const websocket = this[kWebSocket];
		this.removeListener("error", socketOnError);
		this.on("error", NOOP);
		if (websocket) {
			websocket._readyState = WebSocket.CLOSING;
			this.destroy();
		}
	}
}));
//#endregion
//#region node_modules/ws/lib/stream.js
var require_stream = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	require_websocket();
	var { Duplex: Duplex$1 } = __require("stream");
	/**
	* Emits the `'close'` event on a stream.
	*
	* @param {Duplex} stream The stream.
	* @private
	*/
	function emitClose(stream) {
		stream.emit("close");
	}
	/**
	* The listener of the `'end'` event.
	*
	* @private
	*/
	function duplexOnEnd() {
		if (!this.destroyed && this._writableState.finished) this.destroy();
	}
	/**
	* The listener of the `'error'` event.
	*
	* @param {Error} err The error
	* @private
	*/
	function duplexOnError(err) {
		this.removeListener("error", duplexOnError);
		this.destroy();
		if (this.listenerCount("error") === 0) this.emit("error", err);
	}
	/**
	* Wraps a `WebSocket` in a duplex stream.
	*
	* @param {WebSocket} ws The `WebSocket` to wrap
	* @param {Object} [options] The options for the `Duplex` constructor
	* @return {Duplex} The duplex stream
	* @public
	*/
	function createWebSocketStream(ws, options) {
		let terminateOnDestroy = true;
		const duplex = new Duplex$1({
			...options,
			autoDestroy: false,
			emitClose: false,
			objectMode: false,
			writableObjectMode: false
		});
		ws.on("message", function message(msg, isBinary) {
			const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
			if (!duplex.push(data)) ws.pause();
		});
		ws.once("error", function error(err) {
			if (duplex.destroyed) return;
			terminateOnDestroy = false;
			duplex.destroy(err);
		});
		ws.once("close", function close() {
			if (duplex.destroyed) return;
			duplex.push(null);
		});
		duplex._destroy = function(err, callback) {
			if (ws.readyState === ws.CLOSED) {
				callback(err);
				process.nextTick(emitClose, duplex);
				return;
			}
			let called = false;
			ws.once("error", function error(err) {
				called = true;
				callback(err);
			});
			ws.once("close", function close() {
				if (!called) callback(err);
				process.nextTick(emitClose, duplex);
			});
			if (terminateOnDestroy) ws.terminate();
		};
		duplex._final = function(callback) {
			if (ws.readyState === ws.CONNECTING) {
				ws.once("open", function open() {
					duplex._final(callback);
				});
				return;
			}
			if (ws._socket === null) return;
			if (ws._socket._writableState.finished) {
				callback();
				if (duplex._readableState.endEmitted) duplex.destroy();
			} else {
				ws._socket.once("finish", function finish() {
					callback();
				});
				ws.close();
			}
		};
		duplex._read = function() {
			if (ws.isPaused) ws.resume();
		};
		duplex._write = function(chunk, encoding, callback) {
			if (ws.readyState === ws.CONNECTING) {
				ws.once("open", function open() {
					duplex._write(chunk, encoding, callback);
				});
				return;
			}
			ws.send(chunk, callback);
		};
		duplex.on("end", duplexOnEnd);
		duplex.on("error", duplexOnError);
		return duplex;
	}
	module.exports = createWebSocketStream;
}));
//#endregion
//#region node_modules/ws/lib/subprotocol.js
var require_subprotocol = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { tokenChars } = require_validation();
	/**
	* Parses the `Sec-WebSocket-Protocol` header into a set of subprotocol names.
	*
	* @param {String} header The field value of the header
	* @return {Set} The subprotocol names
	* @public
	*/
	function parse(header) {
		const protocols = /* @__PURE__ */ new Set();
		let start = -1;
		let end = -1;
		let i = 0;
		for (; i < header.length; i++) {
			const code = header.charCodeAt(i);
			if (end === -1 && tokenChars[code] === 1) {
				if (start === -1) start = i;
			} else if (i !== 0 && (code === 32 || code === 9)) {
				if (end === -1 && start !== -1) end = i;
			} else if (code === 44) {
				if (start === -1) throw new SyntaxError(`Unexpected character at index ${i}`);
				if (end === -1) end = i;
				const protocol = header.slice(start, end);
				if (protocols.has(protocol)) throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
				protocols.add(protocol);
				start = end = -1;
			} else throw new SyntaxError(`Unexpected character at index ${i}`);
		}
		if (start === -1 || end !== -1) throw new SyntaxError("Unexpected end of input");
		const protocol = header.slice(start, i);
		if (protocols.has(protocol)) throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
		protocols.add(protocol);
		return protocols;
	}
	module.exports = { parse };
}));
//#endregion
//#region node_modules/ws/lib/websocket-server.js
var require_websocket_server = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var EventEmitter = __require("events");
	var http = __require("http");
	var { Duplex } = __require("stream");
	var { createHash: createHash$1 } = __require("crypto");
	var extension = require_extension();
	var PerMessageDeflate = require_permessage_deflate();
	var subprotocol = require_subprotocol();
	var WebSocket = require_websocket();
	var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
	var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
	var RUNNING = 0;
	var CLOSING = 1;
	var CLOSED = 2;
	/**
	* Class representing a WebSocket server.
	*
	* @extends EventEmitter
	*/
	var WebSocketServer = class extends EventEmitter {
		/**
		* Create a `WebSocketServer` instance.
		*
		* @param {Object} options Configuration options
		* @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
		*     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
		*     multiple times in the same tick
		* @param {Boolean} [options.autoPong=true] Specifies whether or not to
		*     automatically send a pong in response to a ping
		* @param {Number} [options.backlog=511] The maximum length of the queue of
		*     pending connections
		* @param {Boolean} [options.clientTracking=true] Specifies whether or not to
		*     track clients
		* @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
		*     wait for the closing handshake to finish after `websocket.close()` is
		*     called
		* @param {Function} [options.handleProtocols] A hook to handle protocols
		* @param {String} [options.host] The hostname where to bind the server
		* @param {Number} [options.maxBufferedChunks=262144] The maximum number of
		*     buffered data chunks
		* @param {Number} [options.maxFragments=16384] The maximum number of message
		*     fragments
		* @param {Number} [options.maxPayload=104857600] The maximum allowed message
		*     size
		* @param {Boolean} [options.noServer=false] Enable no server mode
		* @param {String} [options.path] Accept only connections matching this path
		* @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
		*     permessage-deflate
		* @param {Number} [options.port] The port where to bind the server
		* @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
		*     server to use
		* @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
		*     not to skip UTF-8 validation for text and close messages
		* @param {Function} [options.verifyClient] A hook to reject connections
		* @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
		*     class to use. It must be the `WebSocket` class or class that extends it
		* @param {Function} [callback] A listener for the `listening` event
		*/
		constructor(options, callback) {
			super();
			options = {
				allowSynchronousEvents: true,
				autoPong: true,
				maxBufferedChunks: 262144,
				maxFragments: 16384,
				maxPayload: 104857600,
				skipUTF8Validation: false,
				perMessageDeflate: false,
				handleProtocols: null,
				clientTracking: true,
				closeTimeout: CLOSE_TIMEOUT,
				verifyClient: null,
				noServer: false,
				backlog: null,
				server: null,
				host: null,
				path: null,
				port: null,
				WebSocket,
				...options
			};
			if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) throw new TypeError("One and only one of the \"port\", \"server\", or \"noServer\" options must be specified");
			if (options.port != null) {
				this._server = http.createServer((req, res) => {
					const body = http.STATUS_CODES[426];
					res.writeHead(426, {
						"Content-Length": body.length,
						"Content-Type": "text/plain"
					});
					res.end(body);
				});
				this._server.listen(options.port, options.host, options.backlog, callback);
			} else if (options.server) this._server = options.server;
			if (this._server) {
				const emitConnection = this.emit.bind(this, "connection");
				this._removeListeners = addListeners(this._server, {
					listening: this.emit.bind(this, "listening"),
					error: this.emit.bind(this, "error"),
					upgrade: (req, socket, head) => {
						this.handleUpgrade(req, socket, head, emitConnection);
					}
				});
			}
			if (options.perMessageDeflate === true) options.perMessageDeflate = {};
			if (options.clientTracking) {
				this.clients = /* @__PURE__ */ new Set();
				this._shouldEmitClose = false;
			}
			this.options = options;
			this._state = RUNNING;
		}
		/**
		* Returns the bound address, the address family name, and port of the server
		* as reported by the operating system if listening on an IP socket.
		* If the server is listening on a pipe or UNIX domain socket, the name is
		* returned as a string.
		*
		* @return {(Object|String|null)} The address of the server
		* @public
		*/
		address() {
			if (this.options.noServer) throw new Error("The server is operating in \"noServer\" mode");
			if (!this._server) return null;
			return this._server.address();
		}
		/**
		* Stop the server from accepting new connections and emit the `'close'` event
		* when all existing connections are closed.
		*
		* @param {Function} [cb] A one-time listener for the `'close'` event
		* @public
		*/
		close(cb) {
			if (this._state === CLOSED) {
				if (cb) this.once("close", () => {
					cb(/* @__PURE__ */ new Error("The server is not running"));
				});
				process.nextTick(emitClose, this);
				return;
			}
			if (cb) this.once("close", cb);
			if (this._state === CLOSING) return;
			this._state = CLOSING;
			if (this.options.noServer || this.options.server) {
				if (this._server) {
					this._removeListeners();
					this._removeListeners = this._server = null;
				}
				if (this.clients) {
					if (!this.clients.size) process.nextTick(emitClose, this);
					else this._shouldEmitClose = true;
				} else process.nextTick(emitClose, this);
			} else {
				const server = this._server;
				this._removeListeners();
				this._removeListeners = this._server = null;
				server.close(() => {
					emitClose(this);
				});
			}
		}
		/**
		* See if a given request should be handled by this server instance.
		*
		* @param {http.IncomingMessage} req Request object to inspect
		* @return {Boolean} `true` if the request is valid, else `false`
		* @public
		*/
		shouldHandle(req) {
			if (this.options.path) {
				const index = req.url.indexOf("?");
				if ((index !== -1 ? req.url.slice(0, index) : req.url) !== this.options.path) return false;
			}
			return true;
		}
		/**
		* Handle a HTTP Upgrade request.
		*
		* @param {http.IncomingMessage} req The request object
		* @param {Duplex} socket The network socket between the server and client
		* @param {Buffer} head The first packet of the upgraded stream
		* @param {Function} cb Callback
		* @public
		*/
		handleUpgrade(req, socket, head, cb) {
			socket.on("error", socketOnError);
			const key = req.headers["sec-websocket-key"];
			const upgrade = req.headers.upgrade;
			const version = +req.headers["sec-websocket-version"];
			if (req.method !== "GET") {
				abortHandshakeOrEmitwsClientError(this, req, socket, 405, "Invalid HTTP method");
				return;
			}
			if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
				abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Invalid Upgrade header");
				return;
			}
			if (key === void 0 || !keyRegex.test(key)) {
				abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Missing or invalid Sec-WebSocket-Key header");
				return;
			}
			if (version !== 13 && version !== 8) {
				abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Missing or invalid Sec-WebSocket-Version header", { "Sec-WebSocket-Version": "13, 8" });
				return;
			}
			if (!this.shouldHandle(req)) {
				abortHandshake(socket, 400);
				return;
			}
			const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
			let protocols = /* @__PURE__ */ new Set();
			if (secWebSocketProtocol !== void 0) try {
				protocols = subprotocol.parse(secWebSocketProtocol);
			} catch (err) {
				abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Invalid Sec-WebSocket-Protocol header");
				return;
			}
			const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
			const extensions = {};
			if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
				const perMessageDeflate = new PerMessageDeflate({
					...this.options.perMessageDeflate,
					isServer: true,
					maxPayload: this.options.maxPayload
				});
				try {
					const offers = extension.parse(secWebSocketExtensions);
					if (offers[PerMessageDeflate.extensionName]) {
						perMessageDeflate.accept(offers[PerMessageDeflate.extensionName]);
						extensions[PerMessageDeflate.extensionName] = perMessageDeflate;
					}
				} catch (err) {
					abortHandshakeOrEmitwsClientError(this, req, socket, 400, "Invalid or unacceptable Sec-WebSocket-Extensions header");
					return;
				}
			}
			if (this.options.verifyClient) {
				const info = {
					origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
					secure: !!(req.socket.authorized || req.socket.encrypted),
					req
				};
				if (this.options.verifyClient.length === 2) {
					this.options.verifyClient(info, (verified, code, message, headers) => {
						if (!verified) return abortHandshake(socket, code || 401, message, headers);
						this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
					});
					return;
				}
				if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
			}
			this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
		}
		/**
		* Upgrade the connection to WebSocket.
		*
		* @param {Object} extensions The accepted extensions
		* @param {String} key The value of the `Sec-WebSocket-Key` header
		* @param {Set} protocols The subprotocols
		* @param {http.IncomingMessage} req The request object
		* @param {Duplex} socket The network socket between the server and client
		* @param {Buffer} head The first packet of the upgraded stream
		* @param {Function} cb Callback
		* @throws {Error} If called more than once with the same socket
		* @private
		*/
		completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
			if (!socket.readable || !socket.writable) return socket.destroy();
			if (socket[kWebSocket]) throw new Error("server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration");
			if (this._state > RUNNING) return abortHandshake(socket, 503);
			const headers = [
				"HTTP/1.1 101 Switching Protocols",
				"Upgrade: websocket",
				"Connection: Upgrade",
				`Sec-WebSocket-Accept: ${createHash$1("sha1").update(key + GUID).digest("base64")}`
			];
			const ws = new this.options.WebSocket(null, void 0, this.options);
			if (protocols.size) {
				const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
				if (protocol) {
					headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
					ws._protocol = protocol;
				}
			}
			if (extensions[PerMessageDeflate.extensionName]) {
				const params = extensions[PerMessageDeflate.extensionName].params;
				const value = extension.format({ [PerMessageDeflate.extensionName]: [params] });
				headers.push(`Sec-WebSocket-Extensions: ${value}`);
				ws._extensions = extensions;
			}
			this.emit("headers", headers, req);
			socket.write(headers.concat("\r\n").join("\r\n"));
			socket.removeListener("error", socketOnError);
			ws.setSocket(socket, head, {
				allowSynchronousEvents: this.options.allowSynchronousEvents,
				maxBufferedChunks: this.options.maxBufferedChunks,
				maxFragments: this.options.maxFragments,
				maxPayload: this.options.maxPayload,
				skipUTF8Validation: this.options.skipUTF8Validation
			});
			if (this.clients) {
				this.clients.add(ws);
				ws.on("close", () => {
					this.clients.delete(ws);
					if (this._shouldEmitClose && !this.clients.size) process.nextTick(emitClose, this);
				});
			}
			cb(ws, req);
		}
	};
	module.exports = WebSocketServer;
	/**
	* Add event listeners on an `EventEmitter` using a map of <event, listener>
	* pairs.
	*
	* @param {EventEmitter} server The event emitter
	* @param {Object.<String, Function>} map The listeners to add
	* @return {Function} A function that will remove the added listeners when
	*     called
	* @private
	*/
	function addListeners(server, map) {
		for (const event of Object.keys(map)) server.on(event, map[event]);
		return function removeListeners() {
			for (const event of Object.keys(map)) server.removeListener(event, map[event]);
		};
	}
	/**
	* Emit a `'close'` event on an `EventEmitter`.
	*
	* @param {EventEmitter} server The event emitter
	* @private
	*/
	function emitClose(server) {
		server._state = CLOSED;
		server.emit("close");
	}
	/**
	* Handle socket errors.
	*
	* @private
	*/
	function socketOnError() {
		this.destroy();
	}
	/**
	* Close the connection when preconditions are not fulfilled.
	*
	* @param {Duplex} socket The socket of the upgrade request
	* @param {Number} code The HTTP response status code
	* @param {String} [message] The HTTP response body
	* @param {Object} [headers] Additional HTTP response headers
	* @private
	*/
	function abortHandshake(socket, code, message, headers) {
		message = message || http.STATUS_CODES[code];
		headers = {
			Connection: "close",
			"Content-Type": "text/html",
			"Content-Length": Buffer.byteLength(message),
			...headers
		};
		socket.once("finish", socket.destroy);
		socket.end(`HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r\n` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message);
	}
	/**
	* Emit a `'wsClientError'` event on a `WebSocketServer` if there is at least
	* one listener for it, otherwise call `abortHandshake()`.
	*
	* @param {WebSocketServer} server The WebSocket server
	* @param {http.IncomingMessage} req The request object
	* @param {Duplex} socket The socket of the upgrade request
	* @param {Number} code The HTTP response status code
	* @param {String} message The HTTP response body
	* @param {Object} [headers] The HTTP response headers
	* @private
	*/
	function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
		if (server.listenerCount("wsClientError")) {
			const err = new Error(message);
			Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
			server.emit("wsClientError", err, socket, req);
		} else abortHandshake(socket, code, message, headers);
	}
}));
require_stream();
require_extension();
require_permessage_deflate();
require_receiver();
require_sender();
require_subprotocol();
require_websocket();
var import_websocket_server = /* @__PURE__ */ __toESM(require_websocket_server(), 1);
//#endregion
//#region server/db.ts
var DB = class DB {
	dir;
	db;
	constructor(dir) {
		this.dir = dir;
		if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
		this.db = new DatabaseSync(join(dir, "world.db"));
		this.db.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA synchronous = NORMAL;
      CREATE TABLE IF NOT EXISTS users (name TEXT PRIMARY KEY, salt TEXT, hash TEXT, token TEXT, rec TEXT, created INTEGER, last INTEGER, banned INTEGER DEFAULT 0, gm INTEGER DEFAULT 0);
      CREATE INDEX IF NOT EXISTS users_token ON users(token);
      CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT, at INTEGER);
      CREATE TABLE IF NOT EXISTS chat (id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER, ch TEXT, who TEXT, text TEXT);
      CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER, who TEXT, what TEXT);
    `);
	}
	static hashPass(pass, salt) {
		return scryptSync(pass, salt, 32).toString("hex");
	}
	/** 异步版（libuv 线程池），不阻塞世界主循环 */
	static hashPassAsync(pass, salt) {
		return new Promise((res, rej) => scrypt(pass, salt, 32, (e, k) => e ? rej(e) : res(k.toString("hex"))));
	}
	user(name) {
		return this.db.prepare("SELECT * FROM users WHERE name = ?").get(name);
	}
	userByToken(token) {
		return this.db.prepare("SELECT * FROM users WHERE token = ?").get(token);
	}
	async register(name, pass, rec) {
		const salt = randomBytes(12).toString("hex");
		const token = randomBytes(24).toString("hex");
		const hash = await DB.hashPassAsync(pass, salt);
		this.db.prepare("INSERT INTO users (name, salt, hash, token, rec, created, last, banned, gm) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0)").run(name, salt, hash, token, JSON.stringify(rec), Date.now(), Date.now());
		return token;
	}
	async checkPass(u, pass) {
		const a = Buffer.from(await DB.hashPassAsync(pass, u.salt), "hex"), b = Buffer.from(u.hash, "hex");
		return a.length === b.length && timingSafeEqual(a, b);
	}
	newToken(name) {
		const t = randomBytes(24).toString("hex");
		this.db.prepare("UPDATE users SET token = ?, last = ? WHERE name = ?").run(t, Date.now(), name);
		return t;
	}
	saveRec(name, rec) {
		this.db.prepare("UPDATE users SET rec = ?, last = ? WHERE name = ?").run(JSON.stringify(rec), Date.now(), name);
	}
	/** 旧版“第一个注册的自动成为 GM”留下的权限：在没有天命之主时一律收回 */
	migrateGm() {
		if (this.db.prepare("SELECT COUNT(*) AS n FROM users WHERE gm >= 2").get().n === 0) {
			const r = this.db.prepare("UPDATE users SET gm = 0 WHERE gm = 1").run();
			if (Number(r.changes)) console.log(`[gm] 收回了 ${r.changes} 个旧版自动 GM 权限（请用天命令牌认领）`);
		}
	}
	setFlag(name, col, v) {
		this.db.prepare(`UPDATE users SET ${col} = ? WHERE name = ?`).run(v, name);
	}
	setPass(name, pass) {
		const salt = randomBytes(12).toString("hex");
		this.db.prepare("UPDATE users SET salt = ?, hash = ?, token = NULL WHERE name = ?").run(salt, DB.hashPass(pass, salt), name);
	}
	allUsers() {
		return this.db.prepare("SELECT name, last, banned, gm, rec FROM users ORDER BY last DESC").all();
	}
	get(k) {
		const r = this.db.prepare("SELECT v FROM kv WHERE k = ?").get(k);
		return r ? r.v : null;
	}
	set(k, v) {
		this.db.prepare("INSERT INTO kv (k, v, at) VALUES (?, ?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v, at = excluded.at").run(k, v, Date.now());
	}
	del(k) {
		this.db.prepare("DELETE FROM kv WHERE k = ?").run(k);
	}
	chat(ch, who, text) {
		this.db.prepare("INSERT INTO chat (at, ch, who, text) VALUES (?, ?, ?, ?)").run(Date.now(), ch, who, text);
	}
	recentChat(n = 40) {
		return this.db.prepare("SELECT at, ch, who, text FROM chat WHERE ch = 'all' ORDER BY id DESC LIMIT ?").all(n).reverse();
	}
	audit(who, what) {
		this.db.prepare("INSERT INTO audit (at, who, what) VALUES (?, ?, ?)").run(Date.now(), who, what);
	}
	recentAudit(n = 60) {
		return this.db.prepare("SELECT at, who, what FROM audit ORDER BY id DESC LIMIT ?").all(n);
	}
	/** 每天一份世界备份（防止误操作） */
	backup() {
		try {
			const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
			const f = join(this.dir, `backup-${day}.db`);
			if (!existsSync(f)) {
				this.db.exec("PRAGMA wal_checkpoint(FULL)");
				copyFileSync(join(this.dir, "world.db"), f);
			}
			const olds = readdirSync(this.dir).filter((n) => /^backup-\d{4}-\d{2}-\d{2}\.db$/.test(n)).sort().reverse().slice(7);
			for (const n of olds) unlinkSync(join(this.dir, n));
		} catch (e) {
			console.error("[db] backup failed", e);
		}
	}
	close() {
		try {
			this.db.close();
		} catch {}
	}
};
//#endregion
//#region server/gmkey.ts
var ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function gen() {
	let k = "";
	for (let i = 0; i < 16; i++) {
		if (i && i % 4 === 0) k += "-";
		k += ALPHA[randomInt(32)];
	}
	return k;
}
var norm = (k) => String(k ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
var h = (k) => createHash("sha256").update(norm(k)).digest();
var GmKey = class {
	db;
	dir;
	key = "";
	fromEnv = false;
	constructor(db, dir) {
		this.db = db;
		this.dir = dir;
		const env = process.env.GM_KEY?.trim();
		if (env && norm(env).length >= 8) {
			this.key = env;
			this.fromEnv = true;
		} else {
			this.key = db.get("gm_key") ?? "";
			if (!this.key) {
				this.key = gen();
				db.set("gm_key", this.key);
			}
		}
		this.writeFile();
		console.log(`[gm] 天命令牌：${this.key}${this.fromEnv ? "（来自环境变量 GM_KEY）" : ""}`);
		console.log(`[gm] 已写入 ${join(dir, "GM_KEY.txt")}。进游戏后在聊天框输入「/天命 ${this.key}」即可成为上帝（只有你自己看得到这条指令）。`);
	}
	writeFile() {
		const f = join(this.dir, "GM_KEY.txt");
		try {
			writeFileSync(f, `《铁血大明》天命令牌（GM 上帝凭证）\n\n${this.key}\n\n用法：进入游戏世界后，在聊天框输入\n/天命 ${this.key}\n这条指令不会发给任何人。认领成功后右上角出现“⚙ 天意”按钮。\n\n令牌泄露了？认领后在“天意 → 管理”里点“换新令牌”（或 GM 指令 newkey），旧令牌立即作废。\n${this.fromEnv ? "\n（当前令牌来自环境变量 GM_KEY，换新令牌只在本次运行有效；要永久更换请改环境变量。）\n" : ""}`);
			try {
				chmodSync(f, 384);
			} catch {}
		} catch (e) {
			console.error("[gm] 写 GM_KEY.txt 失败", e);
		}
	}
	check(k) {
		const a = h(k), b = h(this.key);
		return norm(k).length >= 8 && timingSafeEqual(a, b);
	}
	renew() {
		this.key = gen();
		if (!this.fromEnv) this.db.set("gm_key", this.key);
		this.writeFile();
		console.log(`[gm] 天命令牌已更换：${this.key}`);
		return this.key;
	}
};
/** 认领限流：每个 IP / 账号每小时最多 5 次失败 */
var fails = /* @__PURE__ */ new Map();
function claimBlocked(...keys) {
	const now = Date.now();
	return keys.some((k) => (fails.get(k) ?? []).filter((t) => now - t < 36e5).length >= 5);
}
function claimFailed(...keys) {
	const now = Date.now();
	for (const k of keys) fails.set(k, [...(fails.get(k) ?? []).filter((t) => now - t < 36e5), now]);
}
//#endregion
//#region src/net/protocol.ts
/** 玩家可选的五国 */
var NATIONS = [
	"ming",
	"jin",
	"chuang",
	"xi",
	"mon"
];
/** 玩家可上传的私有字段 */
var PRIVATE_KEYS = [
	"hero",
	"troops",
	"prisoners",
	"gold",
	"goods",
	"renown",
	"honor",
	"morale",
	"companions",
	"quests",
	"stats",
	"playerRel",
	"cannons"
];
var RANK_NAMES = [
	"白身",
	"把总",
	"千总",
	"守备",
	"游击",
	"参将",
	"副将",
	"总兵",
	"提督"
];
var RANK_RENOWN = [
	0,
	100,
	250,
	500,
	900,
	1500,
	2400,
	3600,
	5500
];
function rankOf(renown) {
	let r = 0;
	for (let i = 0; i < RANK_RENOWN.length; i++) if (renown >= RANK_RENOWN[i]) r = i;
	return r;
}
/** 可由 GM 调整（ServerCfg.newbieHours） */
var NEWBIE = { ms: 72e5 };
var newbieLeft = (rec, now = Date.now()) => !rec || rec.pvpOptIn ? 0 : Math.max(0, rec.created + NEWBIE.ms - now);
//#endregion
//#region src/data/world.ts
var FACTIONS = [
	{
		id: "ming",
		name: "大明",
		color: 12597547,
		css: "#c0392b",
		culture: "ming",
		ruler: "朱由检",
		rulerTitle: "崇祯皇帝",
		capital: "beijing",
		desc: "国祚二百六十余年，内有流寇，外有强敌，正值风雨飘摇之际。"
	},
	{
		id: "jin",
		name: "后金",
		color: 3108277,
		css: "#2f6db5",
		culture: "jin",
		ruler: "皇太极",
		rulerTitle: "天聪汗",
		capital: "shengjing",
		desc: "起于白山黑水，八旗劲旅屡破明军，虎视关内。"
	},
	{
		id: "chuang",
		name: "闯军",
		color: 14191132,
		css: "#d88a1c",
		culture: "chuang",
		ruler: "李自成",
		rulerTitle: "闯王",
		capital: "luoyang",
		desc: "“迎闯王，不纳粮”，饥民云集，声势日盛。"
	},
	{
		id: "xi",
		name: "西营",
		color: 8212387,
		css: "#7d4fa3",
		culture: "xi",
		ruler: "张献忠",
		rulerTitle: "八大王",
		capital: "chengdu",
		desc: "张献忠所部，转战湖广，据蜀地以图天下。"
	},
	{
		id: "mon",
		name: "察哈尔",
		color: 3054698,
		css: "#2e9c6a",
		culture: "mon",
		ruler: "林丹汗",
		rulerTitle: "蒙古大汗",
		capital: "guihua",
		desc: "黄金家族正统，欲重振蒙古，却夹在明金之间。"
	},
	{
		id: "player",
		name: "义军",
		color: 13938487,
		css: "#d4af37",
		culture: "ming",
		ruler: "",
		rulerTitle: "",
		capital: "",
		desc: "你自己的势力。"
	}
];
var FACTION = {};
for (const f of FACTIONS) FACTION[f.id] = f;
FACTION["bandit"] = {
	id: "bandit",
	name: "盗匪",
	color: 4473924,
	css: "#555",
	culture: "bandit",
	ruler: "",
	rulerTitle: "",
	capital: "",
	desc: ""
};
FACTION["none"] = {
	id: "none",
	name: "无",
	color: 8947848,
	css: "#888",
	culture: "civ",
	ruler: "",
	rulerTitle: "",
	capital: "",
	desc: ""
};
var MAJOR_FACTIONS = [
	"ming",
	"jin",
	"chuang",
	"xi",
	"mon"
];
var INITIAL_WARS = [
	["ming", "jin"],
	["ming", "chuang"],
	["ming", "xi"],
	["jin", "mon"],
	["chuang", "mon"]
];
var TOWN_DEFS = [
	{
		id: "beijing",
		name: "北京",
		kind: "town",
		faction: "ming",
		lon: 116.4,
		lat: 39.9,
		produce: ["iron", "wine"],
		demand: [
			"silk",
			"porcelain",
			"tea",
			"grain"
		]
	},
	{
		id: "jinan",
		name: "济南",
		kind: "town",
		faction: "ming",
		lon: 117,
		lat: 36.65,
		produce: ["salt", "grain"],
		demand: ["iron", "silk"]
	},
	{
		id: "kaifeng",
		name: "开封",
		kind: "town",
		faction: "ming",
		lon: 114.3,
		lat: 34.8,
		produce: ["grain", "cloth"],
		demand: ["salt", "tea"]
	},
	{
		id: "taiyuan",
		name: "太原",
		kind: "town",
		faction: "ming",
		lon: 112.55,
		lat: 37.87,
		produce: ["iron", "wine"],
		demand: [
			"cloth",
			"grain",
			"tea"
		]
	},
	{
		id: "nanjing",
		name: "南京",
		kind: "town",
		faction: "ming",
		lon: 118.8,
		lat: 32.06,
		produce: ["cloth", "silk"],
		demand: [
			"iron",
			"fur",
			"herb"
		]
	},
	{
		id: "suzhou",
		name: "苏州",
		kind: "town",
		faction: "ming",
		lon: 120.6,
		lat: 31.3,
		produce: ["silk", "cloth"],
		demand: [
			"grain",
			"fur",
			"ginseng"
		]
	},
	{
		id: "hangzhou",
		name: "杭州",
		kind: "town",
		faction: "ming",
		lon: 120.15,
		lat: 30.27,
		produce: ["silk", "tea"],
		demand: [
			"iron",
			"salt",
			"ginseng"
		]
	},
	{
		id: "fuzhou",
		name: "福州",
		kind: "town",
		faction: "ming",
		lon: 119.3,
		lat: 26.08,
		produce: ["tea", "porcelain"],
		demand: [
			"iron",
			"grain",
			"cloth"
		]
	},
	{
		id: "guangzhou",
		name: "广州",
		kind: "town",
		faction: "ming",
		lon: 113.26,
		lat: 23.13,
		produce: ["herb", "cloth"],
		demand: [
			"silk",
			"porcelain",
			"tea"
		]
	},
	{
		id: "wuchang",
		name: "武昌",
		kind: "town",
		faction: "ming",
		lon: 114.3,
		lat: 30.55,
		produce: ["grain", "meat"],
		demand: ["salt", "iron"]
	},
	{
		id: "changsha",
		name: "长沙",
		kind: "town",
		faction: "ming",
		lon: 112.94,
		lat: 28.23,
		produce: ["grain", "herb"],
		demand: ["salt", "cloth"]
	},
	{
		id: "nanchang",
		name: "南昌",
		kind: "town",
		faction: "ming",
		lon: 115.86,
		lat: 28.68,
		produce: ["porcelain", "grain"],
		demand: ["salt", "fur"]
	},
	{
		id: "xian",
		name: "西安",
		kind: "town",
		faction: "ming",
		lon: 108.94,
		lat: 34.34,
		produce: ["meat", "fur"],
		demand: [
			"tea",
			"silk",
			"salt"
		]
	},
	{
		id: "lanzhou",
		name: "兰州",
		kind: "town",
		faction: "ming",
		lon: 103.8,
		lat: 36.06,
		produce: ["meat", "fur"],
		demand: [
			"tea",
			"cloth",
			"porcelain"
		]
	},
	{
		id: "guilin",
		name: "桂林",
		kind: "town",
		faction: "ming",
		lon: 110.3,
		lat: 25.27,
		produce: ["herb", "wine"],
		demand: ["salt", "iron"]
	},
	{
		id: "kunming",
		name: "昆明",
		kind: "town",
		faction: "ming",
		lon: 102.7,
		lat: 25.04,
		produce: ["tea", "herb"],
		demand: [
			"cloth",
			"salt",
			"silk"
		]
	},
	{
		id: "shengjing",
		name: "盛京",
		kind: "town",
		faction: "jin",
		lon: 123.43,
		lat: 41.8,
		produce: ["fur", "ginseng"],
		demand: [
			"cloth",
			"salt",
			"tea",
			"iron"
		]
	},
	{
		id: "liaoyang",
		name: "辽阳",
		kind: "town",
		faction: "jin",
		lon: 123.17,
		lat: 41.27,
		produce: ["grain", "iron"],
		demand: ["silk", "wine"]
	},
	{
		id: "guihua",
		name: "归化城",
		kind: "town",
		faction: "mon",
		lon: 111.65,
		lat: 40.82,
		produce: ["meat", "fur"],
		demand: [
			"tea",
			"cloth",
			"iron",
			"grain"
		]
	},
	{
		id: "luoyang",
		name: "洛阳",
		kind: "town",
		faction: "chuang",
		lon: 112.45,
		lat: 34.62,
		produce: ["grain", "wine"],
		demand: ["iron", "salt"]
	},
	{
		id: "xiangyang",
		name: "襄阳",
		kind: "town",
		faction: "chuang",
		lon: 112.14,
		lat: 32.04,
		produce: ["grain", "cloth"],
		demand: ["iron", "herb"]
	},
	{
		id: "chengdu",
		name: "成都",
		kind: "town",
		faction: "xi",
		lon: 104.06,
		lat: 30.67,
		produce: [
			"silk",
			"tea",
			"herb"
		],
		demand: ["iron", "fur"]
	},
	{
		id: "chongqing",
		name: "重庆",
		kind: "town",
		faction: "xi",
		lon: 106.55,
		lat: 29.56,
		produce: ["salt", "herb"],
		demand: ["cloth", "iron"]
	},
	{
		id: "shanhai",
		name: "山海关",
		kind: "castle",
		faction: "ming",
		lon: 119.75,
		lat: 40
	},
	{
		id: "ningyuan",
		name: "宁远",
		kind: "castle",
		faction: "ming",
		lon: 120.85,
		lat: 40.6
	},
	{
		id: "jinzhou",
		name: "锦州",
		kind: "castle",
		faction: "ming",
		lon: 121.13,
		lat: 41.1
	},
	{
		id: "datong",
		name: "大同",
		kind: "castle",
		faction: "ming",
		lon: 113.3,
		lat: 40.08
	},
	{
		id: "xuanfu",
		name: "宣府",
		kind: "castle",
		faction: "ming",
		lon: 115.03,
		lat: 40.6
	},
	{
		id: "tianjin",
		name: "天津卫",
		kind: "castle",
		faction: "ming",
		lon: 117.2,
		lat: 39.13
	},
	{
		id: "tongguan",
		name: "潼关",
		kind: "castle",
		faction: "ming",
		lon: 110.25,
		lat: 34.55
	},
	{
		id: "yulin",
		name: "榆林",
		kind: "castle",
		faction: "ming",
		lon: 109.73,
		lat: 38.28
	},
	{
		id: "dengzhou",
		name: "登州",
		kind: "castle",
		faction: "ming",
		lon: 120.75,
		lat: 37.8
	},
	{
		id: "hanzhong",
		name: "汉中",
		kind: "castle",
		faction: "ming",
		lon: 107.03,
		lat: 33.07
	},
	{
		id: "ganzhou",
		name: "赣州",
		kind: "castle",
		faction: "ming",
		lon: 114.93,
		lat: 25.85
	},
	{
		id: "xuzhou",
		name: "徐州",
		kind: "castle",
		faction: "ming",
		lon: 117.18,
		lat: 34.26
	},
	{
		id: "fushun",
		name: "抚顺",
		kind: "castle",
		faction: "jin",
		lon: 123.9,
		lat: 41.88
	},
	{
		id: "hetuala",
		name: "赫图阿拉",
		kind: "castle",
		faction: "jin",
		lon: 124.85,
		lat: 41.6
	},
	{
		id: "lushun",
		name: "旅顺",
		kind: "castle",
		faction: "jin",
		lon: 121.25,
		lat: 38.9
	},
	{
		id: "dalinghe",
		name: "大凌河",
		kind: "castle",
		faction: "jin",
		lon: 121.5,
		lat: 41.6
	},
	{
		id: "chahan",
		name: "察罕浩特",
		kind: "castle",
		faction: "mon",
		lon: 118.3,
		lat: 43.6
	},
	{
		id: "duolun",
		name: "多伦",
		kind: "castle",
		faction: "mon",
		lon: 116.47,
		lat: 42.2
	},
	{
		id: "ordos",
		name: "鄂尔多斯",
		kind: "castle",
		faction: "mon",
		lon: 109,
		lat: 39.75
	},
	{
		id: "nanyang",
		name: "南阳",
		kind: "castle",
		faction: "chuang",
		lon: 112.53,
		lat: 33
	},
	{
		id: "shangluo",
		name: "商洛",
		kind: "castle",
		faction: "chuang",
		lon: 109.94,
		lat: 33.87
	},
	{
		id: "ruzhou",
		name: "汝州",
		kind: "castle",
		faction: "chuang",
		lon: 112.84,
		lat: 34.17
	},
	{
		id: "kuizhou",
		name: "夔州",
		kind: "castle",
		faction: "xi",
		lon: 109.5,
		lat: 31
	},
	{
		id: "jianmen",
		name: "剑门关",
		kind: "castle",
		faction: "xi",
		lon: 105.55,
		lat: 32.2
	},
	{
		id: "luzhou",
		name: "泸州",
		kind: "castle",
		faction: "xi",
		lon: 105.44,
		lat: 28.87
	},
	{
		id: "yehe",
		name: "叶赫",
		kind: "castle",
		faction: "jin",
		lon: 124.9,
		lat: 43.2
	},
	{
		id: "kaiyuan",
		name: "开原",
		kind: "castle",
		faction: "jin",
		lon: 124,
		lat: 42.55
	},
	{
		id: "wula",
		name: "乌拉",
		kind: "castle",
		faction: "jin",
		lon: 126.5,
		lat: 44
	},
	{
		id: "huifa",
		name: "辉发",
		kind: "castle",
		faction: "jin",
		lon: 126.2,
		lat: 42.6
	},
	{
		id: "fenghuang",
		name: "凤凰城",
		kind: "castle",
		faction: "jin",
		lon: 124.1,
		lat: 40.45
	},
	{
		id: "horqin",
		name: "科尔沁",
		kind: "castle",
		faction: "jin",
		lon: 122.4,
		lat: 44.3
	},
	{
		id: "harqin",
		name: "喀喇沁",
		kind: "castle",
		faction: "mon",
		lon: 118.9,
		lat: 41.9
	},
	{
		id: "ujimqin",
		name: "乌珠穆沁",
		kind: "castle",
		faction: "mon",
		lon: 117,
		lat: 45
	},
	{
		id: "sunid",
		name: "苏尼特",
		kind: "castle",
		faction: "mon",
		lon: 113,
		lat: 43.8
	},
	{
		id: "alashan",
		name: "阿拉善",
		kind: "castle",
		faction: "mon",
		lon: 105.7,
		lat: 38.9
	},
	{
		id: "heicheng",
		name: "黑城",
		kind: "castle",
		faction: "mon",
		lon: 101.1,
		lat: 41.8
	}
];
/** 蒙古包营地：只出骑兵的游牧部落（kind 为 village，camp = true） */
var CAMP_DEFS = [
	{
		id: "c_baarin",
		name: "巴林部",
		faction: "mon",
		lon: 119.5,
		lat: 44.4
	},
	{
		id: "c_ongniud",
		name: "翁牛特部",
		faction: "mon",
		lon: 119.9,
		lat: 42.9
	},
	{
		id: "c_aohan",
		name: "敖汉部",
		faction: "jin",
		lon: 120.6,
		lat: 42.3
	},
	{
		id: "c_naiman",
		name: "奈曼部",
		faction: "jin",
		lon: 121,
		lat: 43.1
	},
	{
		id: "c_jarud",
		name: "扎鲁特部",
		faction: "jin",
		lon: 120.8,
		lat: 44.8
	},
	{
		id: "c_hexigten",
		name: "克什克腾部",
		faction: "mon",
		lon: 117.5,
		lat: 43.3
	},
	{
		id: "c_abag",
		name: "阿巴噶部",
		faction: "mon",
		lon: 115,
		lat: 44.4
	},
	{
		id: "c_dorben",
		name: "四子部",
		faction: "mon",
		lon: 111.5,
		lat: 42
	},
	{
		id: "c_urad",
		name: "乌拉特部",
		faction: "mon",
		lon: 108.8,
		lat: 41.4
	},
	{
		id: "c_otog",
		name: "鄂托克部",
		faction: "mon",
		lon: 107.5,
		lat: 39.3
	},
	{
		id: "c_khalkha",
		name: "喀尔喀部",
		faction: "mon",
		lon: 112,
		lat: 45.1
	}
];
/** 营地招募的兵种：牧民；与营地关系好时可招察哈尔骑手 */
var CAMP_RECRUIT = "mon_recruit";
var CAMP_RECRUIT_GOOD = "mon_rider";
/** 关外村庄名（按文化） */
var JIN_VILLAGE_NAMES = [
	"萨尔浒",
	"界凡寨",
	"董鄂屯",
	"苏完寨",
	"哲陈屯",
	"浑河屯",
	"铁岭堡",
	"懿路屯",
	"蒲河屯",
	"清河堡",
	"碱场堡",
	"汪清屯",
	"长白屯",
	"佛阿拉",
	"宁古屯",
	"珲春屯"
];
var MON_VILLAGE_NAMES = [
	"美岱召",
	"大板升",
	"善岱板升",
	"五当召",
	"席力图召",
	"达拉特",
	"准格尔",
	"乌兰察布",
	"锡林郭勒",
	"多伦淖尔",
	"达里诺尔",
	"白塔子"
];
var VILLAGE_NAMES = [
	"张家庄",
	"李家集",
	"王家屯",
	"柳树营",
	"石桥镇",
	"杏花村",
	"黄土坡",
	"青山堡",
	"马家湾",
	"白沙铺",
	"河口镇",
	"枣林庄",
	"刘家寨",
	"赵家沟",
	"陈家岭",
	"孙家店",
	"周家渡",
	"吴家坊",
	"郑家楼",
	"桃花坞",
	"梨园村",
	"槐树屯",
	"杨柳青",
	"麦香村",
	"高粱坡",
	"芦苇荡",
	"野狐岭",
	"卧牛山",
	"龙泉驿",
	"凤凰台",
	"鹰嘴崖",
	"虎跳峡",
	"金沙滩",
	"银杏村",
	"碧水湾",
	"红石岗",
	"黑松林",
	"青石镇",
	"古井村",
	"瓦窑堡",
	"铁匠铺",
	"磨坊村",
	"盐井镇",
	"茶山村",
	"桑园镇",
	"稻香村",
	"竹溪村",
	"松江屯",
	"鹿角湾",
	"牛家口",
	"羊角屯",
	"驼铃驿",
	"狼牙寨",
	"马场屯",
	"鱼米乡",
	"莲花池",
	"双桥镇",
	"三河口",
	"四方店",
	"五里铺",
	"六合屯",
	"七星岗",
	"八里桥",
	"九龙集",
	"十里堡",
	"东关村",
	"西沟村",
	"南屯",
	"北营",
	"上河村"
];
/** 城镇额外特产/紧缺（按地域，在开局时各抽 1~2 种追加） */
var REGION_GOODS = {
	south: {
		produce: [
			"sugar",
			"fish",
			"ricewine",
			"lacquer",
			"spice",
			"paper",
			"books",
			"pottery",
			"tobacco",
			"pearl"
		],
		demand: [
			"horse_t",
			"leather",
			"copper",
			"antler",
			"flour"
		]
	},
	north: {
		produce: [
			"flour",
			"timber",
			"copper",
			"saltpeter",
			"pottery",
			"books",
			"hemp",
			"leather"
		],
		demand: [
			"sugar",
			"spice",
			"lacquer",
			"fish",
			"pearl",
			"horse_t"
		]
	},
	west: {
		produce: [
			"jade",
			"leather",
			"horse_t",
			"fruit",
			"saltpeter"
		],
		demand: [
			"paper",
			"books",
			"sugar",
			"ricewine"
		]
	},
	jin: {
		produce: [
			"antler",
			"leather",
			"timber",
			"fish",
			"horse_t"
		],
		demand: [
			"books",
			"paper",
			"saltpeter",
			"copper",
			"ricewine",
			"sugar"
		]
	},
	mon: {
		produce: [
			"cheese",
			"kumis",
			"horse_t",
			"leather",
			"antler"
		],
		demand: [
			"tobacco",
			"sugar",
			"flour",
			"copper",
			"lacquer"
		]
	},
	xi: {
		produce: [
			"sugar",
			"tobacco",
			"lacquer",
			"paper",
			"saltpeter"
		],
		demand: [
			"horse_t",
			"leather",
			"copper",
			"pearl"
		]
	}
};
var VILLAGE_PRODUCE = {
	ming: [
		"grain",
		"cloth",
		"meat",
		"wine",
		"salt",
		"flour",
		"hemp",
		"timber",
		"pottery",
		"fish"
	],
	jin: [
		"fur",
		"ginseng",
		"grain",
		"antler",
		"leather",
		"timber"
	],
	mon: [
		"meat",
		"fur",
		"cheese",
		"kumis",
		"leather",
		"horse_t"
	],
	chuang: [
		"grain",
		"wine",
		"flour",
		"hemp"
	],
	xi: [
		"herb",
		"tea",
		"salt",
		"sugar",
		"tobacco"
	]
};
var L = (faction, list) => list.map(([name, title, trait], i) => ({
	id: `${faction}_lord${i}`,
	name,
	faction,
	title,
	trait
}));
var LORD_DEFS = [
	...L("ming", [
		[
			"卢象升",
			"宣大总督",
			"brave"
		],
		[
			"孙传庭",
			"陕西巡抚",
			"honorable"
		],
		[
			"洪承畴",
			"三边总督",
			"cautious"
		],
		[
			"曹文诏",
			"总兵",
			"brave"
		],
		[
			"左良玉",
			"总兵",
			"greedy"
		],
		[
			"秦良玉",
			"石砫宣抚使",
			"honorable"
		],
		[
			"祖大寿",
			"锦州总兵",
			"cautious"
		],
		[
			"吴三桂",
			"宁远游击",
			"greedy"
		],
		[
			"周遇吉",
			"总兵",
			"brave"
		],
		[
			"杨嗣昌",
			"督师",
			"cautious"
		],
		[
			"黄得功",
			"总兵",
			"brave"
		],
		[
			"贺人龙",
			"总兵",
			"brave"
		],
		[
			"高杰",
			"总兵",
			"greedy"
		],
		[
			"史可法",
			"巡抚",
			"honorable"
		],
		[
			"唐通",
			"总兵",
			"greedy"
		],
		[
			"马科",
			"总兵",
			"cautious"
		],
		[
			"刘泽清",
			"总兵",
			"greedy"
		],
		[
			"王朴",
			"总兵",
			"cautious"
		],
		[
			"姜瓖",
			"大同总兵",
			"greedy"
		],
		[
			"白广恩",
			"总兵",
			"brave"
		]
	]),
	...L("jin", [
		[
			"多尔衮",
			"贝勒",
			"cautious"
		],
		[
			"多铎",
			"贝勒",
			"brave"
		],
		[
			"阿济格",
			"贝勒",
			"brave"
		],
		[
			"代善",
			"大贝勒",
			"honorable"
		],
		[
			"岳托",
			"贝勒",
			"brave"
		],
		[
			"豪格",
			"贝勒",
			"greedy"
		],
		[
			"济尔哈朗",
			"贝勒",
			"cautious"
		],
		[
			"孔有德",
			"都元帅",
			"greedy"
		],
		[
			"阿巴泰",
			"贝勒",
			"brave"
		],
		[
			"尚可喜",
			"总兵",
			"greedy"
		],
		[
			"耿仲明",
			"总兵",
			"cautious"
		],
		[
			"杜度",
			"贝勒",
			"brave"
		]
	]),
	...L("chuang", [
		[
			"刘宗敏",
			"权将军",
			"brave"
		],
		[
			"李过",
			"制将军",
			"brave"
		],
		[
			"高一功",
			"果毅将军",
			"honorable"
		],
		[
			"田见秀",
			"制将军",
			"cautious"
		],
		[
			"袁宗第",
			"将军",
			"brave"
		],
		[
			"郝摇旗",
			"将军",
			"greedy"
		],
		[
			"李岩",
			"制将军",
			"honorable"
		],
		[
			"刘芳亮",
			"将军",
			"brave"
		],
		[
			"贺锦",
			"将军",
			"brave"
		]
	]),
	...L("xi", [
		[
			"孙可望",
			"平东将军",
			"cautious"
		],
		[
			"李定国",
			"安西将军",
			"honorable"
		],
		[
			"刘文秀",
			"抚南将军",
			"brave"
		],
		[
			"艾能奇",
			"定北将军",
			"brave"
		],
		[
			"王尚礼",
			"将军",
			"greedy"
		]
	]),
	...L("mon", [
		[
			"额哲",
			"台吉",
			"cautious"
		],
		[
			"衮楚克",
			"台吉",
			"brave"
		],
		[
			"布延图",
			"诺颜",
			"greedy"
		],
		[
			"多尔济",
			"台吉",
			"brave"
		],
		[
			"巴雅尔",
			"诺颜",
			"honorable"
		],
		[
			"僧格",
			"诺颜",
			"greedy"
		],
		[
			"固穆",
			"台吉",
			"brave"
		],
		[
			"阿穆尔",
			"台吉",
			"honorable"
		]
	])
];
var COMPANIONS = [
	{
		id: "c_qian",
		name: "戚安",
		title: "戚家后人",
		story: "戚少保的远房后裔，熟读《纪效新书》，一心想重整鸳鸯阵。",
		cost: 400,
		hp: 110,
		atk: 22,
		def: 16,
		skill: 12,
		mounted: false,
		skills: {
			training: 4,
			leadership: 2,
			powerstrike: 3,
			tactics: 2
		}
	},
	{
		id: "c_qin",
		name: "秦红缨",
		title: "江湖女侠",
		story: "峨眉山下长大的女侠，一杆红缨枪使得出神入化。",
		cost: 500,
		hp: 95,
		atk: 24,
		def: 10,
		skill: 13,
		mounted: true,
		skills: {
			powerstrike: 4,
			riding: 3,
			ironflesh: 1
		}
	},
	{
		id: "c_liu",
		name: "柳文远",
		title: "落第书生",
		story: "三试不第，转而钻研岐黄之术，颇有心得。",
		cost: 250,
		hp: 70,
		atk: 10,
		def: 6,
		skill: 5,
		mounted: false,
		skills: {
			surgery: 5,
			trade: 2,
			pathfinding: 1
		}
	},
	{
		id: "c_batu",
		name: "巴图",
		title: "蒙古射手",
		story: "部落被吞并后流落关内，箭术百发百中。",
		cost: 450,
		hp: 90,
		atk: 15,
		def: 10,
		skill: 10,
		rng: 20,
		mounted: true,
		skills: {
			archery: 4,
			spotting: 4,
			riding: 3
		}
	},
	{
		id: "c_wang",
		name: "王铁山",
		title: "镖头",
		story: "威远镖局的镖头，镖局倒闭后欲另谋出路。",
		cost: 350,
		hp: 115,
		atk: 18,
		def: 14,
		skill: 10,
		mounted: false,
		skills: {
			ironflesh: 3,
			training: 2,
			pathfinding: 3
		}
	},
	{
		id: "c_lin",
		name: "林阿四",
		title: "海商",
		story: "跑过吕宋、长崎的海商，精于算计。",
		cost: 300,
		hp: 75,
		atk: 12,
		def: 8,
		skill: 6,
		rng: 22,
		mounted: false,
		skills: {
			trade: 5,
			pathfinding: 2,
			spotting: 1
		}
	},
	{
		id: "c_qing",
		name: "青松子",
		title: "武当道人",
		story: "云游四方的道人，通医理、晓天文。",
		cost: 350,
		hp: 90,
		atk: 17,
		def: 8,
		skill: 12,
		mounted: false,
		skills: {
			surgery: 3,
			spotting: 3,
			tactics: 2
		}
	},
	{
		id: "c_tang",
		name: "汤若瑟",
		title: "西洋教士",
		story: "随利玛窦之后来华的耶稣会士，精通历算与火器。",
		cost: 400,
		hp: 70,
		atk: 9,
		def: 8,
		skill: 5,
		rng: 34,
		mounted: false,
		skills: {
			tactics: 3,
			surgery: 2,
			trade: 2
		}
	},
	{
		id: "c_zhao",
		name: "赵四海",
		title: "盐枭",
		story: "贩私盐起家的江湖豪客，三教九流无所不识。",
		cost: 300,
		hp: 100,
		atk: 18,
		def: 11,
		skill: 9,
		mounted: true,
		skills: {
			prisoner: 4,
			trade: 2,
			leadership: 2
		}
	},
	{
		id: "c_aluo",
		name: "阿萝",
		title: "苗家猎手",
		story: "湘西苗寨的猎手，熟悉山林，行走如飞。",
		cost: 300,
		hp: 85,
		atk: 14,
		def: 7,
		skill: 10,
		rng: 17,
		mounted: false,
		skills: {
			pathfinding: 4,
			archery: 3,
			spotting: 2
		}
	}
];
var BANDIT_ZONES = [
	{
		lon: 113.8,
		lat: 37,
		r: 1,
		troop: "bandit_mtn",
		name: "太行山贼"
	},
	{
		lon: 108.5,
		lat: 33.4,
		r: 1.2,
		troop: "bandit_mtn",
		name: "秦岭山贼"
	},
	{
		lon: 115.5,
		lat: 31,
		r: .9,
		troop: "bandit_mtn",
		name: "大别山贼"
	},
	{
		lon: 117.6,
		lat: 27.3,
		r: 1,
		troop: "bandit_mtn",
		name: "武夷山贼"
	},
	{
		lon: 120.8,
		lat: 29.3,
		r: .8,
		troop: "bandit_wokou",
		name: "倭寇"
	},
	{
		lon: 119,
		lat: 25.4,
		r: .8,
		troop: "bandit_wokou",
		name: "倭寇"
	},
	{
		lon: 116.3,
		lat: 23.4,
		r: .8,
		troop: "bandit_wokou",
		name: "海寇"
	},
	{
		lon: 112.5,
		lat: 42,
		r: 1.8,
		troop: "bandit_horse",
		name: "马贼"
	},
	{
		lon: 106,
		lat: 38.4,
		r: 1.4,
		troop: "bandit_horse",
		name: "马贼"
	},
	{
		lon: 116,
		lat: 34,
		r: 1.3,
		troop: "bandit_rover",
		name: "流寇"
	},
	{
		lon: 111,
		lat: 29.8,
		r: 1.3,
		troop: "bandit_rover",
		name: "流寇"
	},
	{
		lon: 107.5,
		lat: 26.5,
		r: 1.3,
		troop: "bandit_mtn",
		name: "苗疆山贼"
	}
];
var CHINESE_NUM = [
	"零",
	"一",
	"二",
	"三",
	"四",
	"五",
	"六",
	"七",
	"八",
	"九",
	"十"
];
//#endregion
//#region src/data/troops.ts
var T = (d) => ({
	mounted: d.cls === "cav" || d.cls === "hca",
	upgrades: [],
	wage: Math.round(2 + d.tier * d.tier * 2 + (d.cls === "cav" || d.cls === "hca" ? d.tier * 2 : 0)),
	...d
});
var TROOPS = {};
function add(...defs) {
	for (const d of defs) TROOPS[d.id] = d;
}
add(T({
	id: "ming_recruit",
	name: "民壮",
	culture: "ming",
	tier: 1,
	cls: "inf",
	hp: 40,
	atk: 8,
	def: 2,
	skill: 3,
	upgrades: ["ming_soldier", "ming_archer"],
	desc: "各地征发的乡民，手持柴刀木棍。"
}), T({
	id: "ming_soldier",
	name: "营兵",
	culture: "ming",
	tier: 2,
	cls: "inf",
	hp: 50,
	atk: 11,
	def: 6,
	skill: 5,
	upgrades: ["ming_spear", "ming_cav"],
	desc: "经过操练的明军营兵。"
}), T({
	id: "ming_archer",
	name: "弓手",
	culture: "ming",
	tier: 2,
	cls: "arc",
	hp: 45,
	atk: 8,
	def: 4,
	skill: 4,
	rng: 11,
	ammo: 20,
	upgrades: ["ming_gun"],
	desc: "持弓的明军射手。"
}), T({
	id: "ming_spear",
	name: "长枪手",
	culture: "ming",
	tier: 3,
	cls: "spear",
	hp: 60,
	atk: 14,
	def: 10,
	skill: 7,
	upgrades: ["ming_qi", "ming_baigan"],
	desc: "长枪如林，善于拒马。"
}), T({
	id: "ming_cav",
	name: "马兵",
	culture: "ming",
	tier: 3,
	cls: "cav",
	hp: 60,
	atk: 15,
	def: 10,
	skill: 7,
	upgrades: ["ming_guanning"],
	desc: "九边镇军中的骑兵。"
}), T({
	id: "ming_gun",
	name: "鸟铳手",
	culture: "ming",
	tier: 3,
	cls: "gun",
	hp: 50,
	atk: 9,
	def: 6,
	skill: 5,
	rng: 30,
	ammo: 15,
	upgrades: ["ming_shenji"],
	desc: "使用鸟铳的火器兵，一发破甲。"
}), T({
	id: "ming_qi",
	name: "戚家军",
	culture: "ming",
	tier: 4,
	cls: "spear",
	hp: 72,
	atk: 18,
	def: 15,
	skill: 10,
	desc: "承戚继光鸳鸯阵遗法，纪律严明的精锐步卒。"
}), T({
	id: "ming_baigan",
	name: "白杆兵",
	culture: "ming",
	tier: 4,
	cls: "inf",
	hp: 75,
	atk: 20,
	def: 13,
	skill: 10,
	desc: "秦良玉麾下石砫土兵，白杆钩镰，悍不畏死。"
}), T({
	id: "ming_guanning",
	name: "关宁铁骑",
	culture: "ming",
	tier: 5,
	cls: "cav",
	hp: 85,
	atk: 22,
	def: 20,
	skill: 12,
	desc: "关宁锦防线的铁甲骑兵，大明最后的利刃。"
}), T({
	id: "ming_shenji",
	name: "神机营铳手",
	culture: "ming",
	tier: 4,
	cls: "gun",
	hp: 60,
	atk: 11,
	def: 10,
	skill: 7,
	rng: 38,
	ammo: 18,
	desc: "京营神机营精锐火器手。"
}));
add(T({
	id: "jin_recruit",
	name: "包衣",
	culture: "jin",
	tier: 1,
	cls: "inf",
	hp: 42,
	atk: 9,
	def: 3,
	skill: 3,
	upgrades: ["jin_foot"],
	desc: "旗下奴仆，随军效力。"
}), T({
	id: "jin_foot",
	name: "披甲人",
	culture: "jin",
	tier: 2,
	cls: "inf",
	hp: 55,
	atk: 12,
	def: 8,
	skill: 6,
	upgrades: ["jin_archer", "jin_horse"],
	desc: "八旗中披甲的正兵。"
}), T({
	id: "jin_archer",
	name: "步射手",
	culture: "jin",
	tier: 3,
	cls: "arc",
	hp: 58,
	atk: 12,
	def: 10,
	skill: 7,
	rng: 15,
	ammo: 22,
	upgrades: ["jin_ujen"],
	desc: "满洲重箭，近射破甲。"
}), T({
	id: "jin_horse",
	name: "马甲",
	culture: "jin",
	tier: 3,
	cls: "cav",
	hp: 62,
	atk: 15,
	def: 12,
	skill: 8,
	upgrades: ["jin_bayara", "jin_hca"],
	desc: "八旗骑兵主力。"
}), T({
	id: "jin_ujen",
	name: "乌真超哈",
	culture: "jin",
	tier: 4,
	cls: "gun",
	hp: 62,
	atk: 12,
	def: 12,
	skill: 7,
	rng: 34,
	ammo: 16,
	desc: "汉军火器营，以降将孔有德部为骨干。"
}), T({
	id: "jin_bayara",
	name: "巴牙喇",
	culture: "jin",
	tier: 5,
	cls: "cav",
	hp: 85,
	atk: 22,
	def: 20,
	skill: 12,
	desc: "护军精锐，重甲白甲兵。"
}), T({
	id: "jin_hca",
	name: "骑射手",
	culture: "jin",
	tier: 4,
	cls: "hca",
	hp: 68,
	atk: 14,
	def: 12,
	skill: 9,
	rng: 15,
	ammo: 24,
	desc: "弓马娴熟的八旗骑射手。"
}));
add(T({
	id: "chuang_recruit",
	name: "饥民",
	culture: "chuang",
	tier: 1,
	cls: "inf",
	hp: 38,
	atk: 8,
	def: 1,
	skill: 3,
	upgrades: ["chuang_rebel"],
	desc: "天灾人祸之下揭竿而起的饥民。"
}), T({
	id: "chuang_rebel",
	name: "流民兵",
	culture: "chuang",
	tier: 2,
	cls: "inf",
	hp: 50,
	atk: 11,
	def: 4,
	skill: 5,
	upgrades: ["chuang_foot", "chuang_rider"],
	desc: "随闯王转战的流民兵。"
}), T({
	id: "chuang_foot",
	name: "闯营步卒",
	culture: "chuang",
	tier: 3,
	cls: "spear",
	hp: 60,
	atk: 14,
	def: 8,
	skill: 7,
	upgrades: ["chuang_vet", "chuang_gun"],
	desc: "闯营中的步兵。"
}), T({
	id: "chuang_rider",
	name: "闯营马兵",
	culture: "chuang",
	tier: 3,
	cls: "cav",
	hp: 58,
	atk: 14,
	def: 8,
	skill: 7,
	upgrades: ["chuang_elite"],
	desc: "一人多马，来去如风。"
}), T({
	id: "chuang_vet",
	name: "老营兵",
	culture: "chuang",
	tier: 4,
	cls: "inf",
	hp: 75,
	atk: 19,
	def: 12,
	skill: 10,
	desc: "久经战阵的闯营老卒。"
}), T({
	id: "chuang_gun",
	name: "闯营火铳手",
	culture: "chuang",
	tier: 4,
	cls: "gun",
	hp: 58,
	atk: 10,
	def: 8,
	skill: 6,
	rng: 30,
	ammo: 14,
	desc: "缴获官军火器而成的铳手。"
}), T({
	id: "chuang_elite",
	name: "老营骁骑",
	culture: "chuang",
	tier: 5,
	cls: "cav",
	hp: 80,
	atk: 21,
	def: 16,
	skill: 12,
	desc: "闯王亲领的骁骑。"
}));
add(T({
	id: "xi_recruit",
	name: "乡勇",
	culture: "xi",
	tier: 1,
	cls: "inf",
	hp: 40,
	atk: 8,
	def: 2,
	skill: 3,
	upgrades: ["xi_soldier", "xi_rider"],
	desc: "被裹挟入营的乡勇。"
}), T({
	id: "xi_soldier",
	name: "西营兵",
	culture: "xi",
	tier: 2,
	cls: "inf",
	hp: 50,
	atk: 11,
	def: 5,
	skill: 5,
	upgrades: ["xi_xbow", "xi_blade"],
	desc: "西营的步兵。"
}), T({
	id: "xi_rider",
	name: "川马兵",
	culture: "xi",
	tier: 2,
	cls: "cav",
	hp: 48,
	atk: 11,
	def: 5,
	skill: 5,
	upgrades: ["xi_lancer"],
	desc: "骑着矮小川马的骑兵。"
}), T({
	id: "xi_xbow",
	name: "弩手",
	culture: "xi",
	tier: 3,
	cls: "xbow",
	hp: 55,
	atk: 10,
	def: 8,
	skill: 6,
	rng: 19,
	ammo: 18,
	upgrades: ["xi_xbow2"],
	desc: "川中山地善用强弩。"
}), T({
	id: "xi_blade",
	name: "藤牌手",
	culture: "xi",
	tier: 3,
	cls: "inf",
	hp: 62,
	atk: 14,
	def: 12,
	skill: 7,
	upgrades: ["xi_guard"],
	desc: "藤牌腰刀，滚地而进。"
}), T({
	id: "xi_lancer",
	name: "西营骑兵",
	culture: "xi",
	tier: 3,
	cls: "cav",
	hp: 60,
	atk: 15,
	def: 9,
	skill: 7,
	desc: "西营的骑兵主力。"
}), T({
	id: "xi_xbow2",
	name: "劲弩手",
	culture: "xi",
	tier: 4,
	cls: "xbow",
	hp: 62,
	atk: 12,
	def: 11,
	skill: 8,
	rng: 25,
	ammo: 20,
	desc: "神臂劲弩，百步穿杨。"
}), T({
	id: "xi_guard",
	name: "西营亲兵",
	culture: "xi",
	tier: 4,
	cls: "inf",
	hp: 76,
	atk: 19,
	def: 15,
	skill: 10,
	desc: "八大王帐下亲兵。"
}));
add(T({
	id: "mon_recruit",
	name: "牧民",
	culture: "mon",
	tier: 1,
	cls: "hca",
	hp: 40,
	atk: 7,
	def: 2,
	skill: 3,
	rng: 8,
	ammo: 16,
	upgrades: ["mon_rider"],
	desc: "马背上长大的牧民。"
}), T({
	id: "mon_rider",
	name: "察哈尔骑手",
	culture: "mon",
	tier: 2,
	cls: "hca",
	hp: 50,
	atk: 10,
	def: 5,
	skill: 5,
	rng: 11,
	ammo: 20,
	upgrades: ["mon_hca", "mon_lancer"],
	desc: "林丹汗麾下骑手。"
}), T({
	id: "mon_hca",
	name: "蒙古骑射手",
	culture: "mon",
	tier: 3,
	cls: "hca",
	hp: 58,
	atk: 12,
	def: 8,
	skill: 7,
	rng: 14,
	ammo: 24,
	upgrades: ["mon_keshig"],
	desc: "来去如风的骑射手。"
}), T({
	id: "mon_lancer",
	name: "枪骑兵",
	culture: "mon",
	tier: 3,
	cls: "cav",
	hp: 62,
	atk: 15,
	def: 10,
	skill: 7,
	upgrades: ["mon_heavy"],
	desc: "持长枪冲阵的骑兵。"
}), T({
	id: "mon_keshig",
	name: "怯薛",
	culture: "mon",
	tier: 4,
	cls: "hca",
	hp: 70,
	atk: 15,
	def: 13,
	skill: 10,
	rng: 17,
	ammo: 26,
	desc: "大汗的宿卫。"
}), T({
	id: "mon_heavy",
	name: "重甲骑",
	culture: "mon",
	tier: 4,
	cls: "cav",
	hp: 78,
	atk: 20,
	def: 17,
	skill: 10,
	desc: "人马俱甲的重骑兵。"
}));
add(T({
	id: "bandit_mtn",
	name: "山贼",
	culture: "bandit",
	tier: 2,
	cls: "inf",
	hp: 46,
	atk: 10,
	def: 3,
	skill: 5,
	desc: "啸聚山林的强人。"
}), T({
	id: "bandit_rover",
	name: "流寇",
	culture: "bandit",
	tier: 2,
	cls: "inf",
	hp: 44,
	atk: 10,
	def: 3,
	skill: 4,
	desc: "流窜各地的乱兵与盗匪。"
}), T({
	id: "bandit_horse",
	name: "马贼",
	culture: "bandit",
	tier: 2,
	cls: "hca",
	hp: 48,
	atk: 10,
	def: 4,
	skill: 5,
	rng: 9,
	ammo: 14,
	desc: "塞外劫掠商旅的马贼。"
}), T({
	id: "bandit_wokou",
	name: "倭寇",
	culture: "bandit",
	tier: 3,
	cls: "inf",
	hp: 55,
	atk: 16,
	def: 5,
	skill: 8,
	desc: "东南沿海的海盗，长刀凶悍。"
}), T({
	id: "bandit_chief",
	name: "贼首",
	culture: "bandit",
	tier: 4,
	cls: "inf",
	hp: 80,
	atk: 18,
	def: 10,
	skill: 10,
	desc: "一伙强人的首领。"
}));
add(T({
	id: "merc_guard",
	name: "镖师",
	culture: "merc",
	tier: 3,
	cls: "inf",
	hp: 62,
	atk: 15,
	def: 9,
	skill: 8,
	wage: 26,
	desc: "走南闯北的镖局好手。"
}), T({
	id: "merc_rider",
	name: "雇佣骑手",
	culture: "merc",
	tier: 3,
	cls: "hca",
	hp: 58,
	atk: 12,
	def: 8,
	skill: 7,
	rng: 13,
	ammo: 20,
	wage: 32,
	desc: "受雇于人的蒙古骑手。"
}), T({
	id: "merc_monk",
	name: "少林武僧",
	culture: "merc",
	tier: 4,
	cls: "inf",
	hp: 78,
	atk: 19,
	def: 8,
	skill: 12,
	wage: 40,
	desc: "下山济世的少林僧兵。"
}), T({
	id: "merc_porto",
	name: "佛郎机铳手",
	culture: "merc",
	tier: 4,
	cls: "gun",
	hp: 62,
	atk: 12,
	def: 12,
	skill: 8,
	rng: 42,
	ammo: 16,
	wage: 50,
	desc: "来自澳门的葡萄牙火枪手，铳法精准。"
}), T({
	id: "civ_peasant",
	name: "农夫",
	culture: "civ",
	tier: 1,
	cls: "inf",
	hp: 35,
	atk: 6,
	def: 1,
	skill: 2,
	wage: 2,
	desc: ""
}), T({
	id: "civ_guard",
	name: "商队护卫",
	culture: "civ",
	tier: 3,
	cls: "inf",
	hp: 58,
	atk: 13,
	def: 9,
	skill: 7,
	desc: ""
}), T({
	id: "civ_cguard",
	name: "护商骑手",
	culture: "civ",
	tier: 3,
	cls: "cav",
	hp: 58,
	atk: 13,
	def: 9,
	skill: 7,
	desc: ""
}));
add(T({
	id: "god_cav",
	name: "金甲天骑",
	culture: "god",
	tier: 5,
	cls: "cav",
	hp: 420,
	atk: 85,
	def: 60,
	skill: 30,
	wage: 0,
	desc: "金甲金鞍，奔腾如雷，天降神兵。"
}), T({
	id: "god_guard",
	name: "金刚力士",
	culture: "god",
	tier: 5,
	cls: "inf",
	hp: 520,
	atk: 95,
	def: 70,
	skill: 30,
	wage: 0,
	desc: "身披金甲的力士，一刀断马。"
}), T({
	id: "god_gun",
	name: "神机天兵",
	culture: "god",
	tier: 5,
	cls: "gun",
	hp: 320,
	atk: 50,
	def: 50,
	skill: 28,
	rng: 140,
	ammo: 60,
	wage: 0,
	desc: "神机火铳，弹无虚发。"
}), T({
	id: "god_bow",
	name: "天弓骑",
	culture: "god",
	tier: 5,
	cls: "hca",
	hp: 360,
	atk: 60,
	def: 50,
	skill: 30,
	rng: 95,
	ammo: 80,
	wage: 0,
	desc: "马上开天弓，箭出如流星。"
}));
var GOD_TROOPS = [
	"god_cav",
	"god_guard",
	"god_gun",
	"god_bow"
];
var RECRUIT_OF = {
	ming: "ming_recruit",
	jin: "jin_recruit",
	chuang: "chuang_recruit",
	xi: "xi_recruit",
	mon: "mon_recruit"
};
var MERCS = [
	"merc_guard",
	"merc_rider",
	"merc_monk",
	"merc_porto"
];
function troopPower(t) {
	const off = Math.max(t.atk, t.rng ? t.rng * .8 : 0) + t.skill * .6;
	return t.hp / 10 * (off / 10) * (1 + t.def / 25) * (t.mounted ? 1.25 : 1);
}
function isRanged(c) {
	return c === "arc" || c === "xbow" || c === "gun" || c === "hca";
}
//#endregion
//#region src/data/items.ts
var items = [
	{
		id: "w_chaidao",
		name: "柴刀",
		slot: "melee",
		price: 30,
		tier: 1,
		dmg: 9,
		reach: 26,
		speed: .75,
		desc: "砍柴用的刀，聊胜于无。"
	},
	{
		id: "w_hunting",
		name: "猎刀",
		slot: "melee",
		price: 80,
		tier: 1,
		dmg: 11,
		reach: 26,
		speed: .7,
		desc: "猎户随身的短刀。"
	},
	{
		id: "w_podao",
		name: "朴刀",
		slot: "melee",
		price: 180,
		tier: 2,
		dmg: 15,
		reach: 32,
		speed: .85,
		desc: "长柄大刀，江湖常见。"
	},
	{
		id: "w_yanling",
		name: "雁翎刀",
		slot: "melee",
		price: 420,
		tier: 3,
		dmg: 18,
		reach: 30,
		speed: .7,
		desc: "明军制式腰刀，轻快锋利。"
	},
	{
		id: "w_spear",
		name: "长枪",
		slot: "melee",
		price: 260,
		tier: 2,
		dmg: 16,
		reach: 42,
		speed: .95,
		antiCav: true,
		desc: "一寸长一寸强，对骑兵有奇效。"
	},
	{
		id: "w_jian",
		name: "铁锏",
		slot: "melee",
		price: 520,
		tier: 3,
		dmg: 20,
		reach: 28,
		speed: .9,
		desc: "钝器破甲，对重甲敌人有效。"
	},
	{
		id: "w_miaodao",
		name: "苗刀",
		slot: "melee",
		price: 900,
		tier: 4,
		dmg: 24,
		reach: 36,
		speed: .85,
		desc: "戚继光仿倭刀所制长刀。"
	},
	{
		id: "w_guandao",
		name: "偃月刀",
		slot: "melee",
		price: 1400,
		tier: 5,
		dmg: 30,
		reach: 44,
		speed: 1.15,
		desc: "青龙偃月，势大力沉。"
	},
	{
		id: "w_horselance",
		name: "马槊",
		slot: "melee",
		price: 1100,
		tier: 4,
		dmg: 22,
		reach: 48,
		speed: 1,
		antiCav: true,
		desc: "骑兵冲锋利器。"
	},
	{
		id: "r_huntbow",
		name: "猎弓",
		slot: "ranged",
		price: 120,
		tier: 1,
		dmg: 10,
		range: 240,
		reload: 1.4,
		ammo: 25,
		kind: "bow",
		desc: "简陋的木弓。"
	},
	{
		id: "r_hornbow",
		name: "角弓",
		slot: "ranged",
		price: 450,
		tier: 3,
		dmg: 16,
		range: 280,
		reload: 1.3,
		ammo: 25,
		kind: "bow",
		desc: "牛角筋胶复合弓。"
	},
	{
		id: "r_manchubow",
		name: "满洲大弓",
		slot: "ranged",
		price: 800,
		tier: 4,
		dmg: 21,
		range: 260,
		reload: 1.6,
		ammo: 22,
		kind: "bow",
		desc: "弓力强劲，箭重破甲。"
	},
	{
		id: "r_xbow",
		name: "手弩",
		slot: "ranged",
		price: 350,
		tier: 2,
		dmg: 18,
		range: 250,
		reload: 2.4,
		ammo: 20,
		kind: "xbow",
		desc: "上弦稍慢，但无需膂力。"
	},
	{
		id: "r_niaochong",
		name: "鸟铳",
		slot: "ranged",
		price: 900,
		tier: 4,
		dmg: 34,
		range: 240,
		reload: 3.6,
		ammo: 18,
		kind: "gun",
		desc: "火绳枪，威力巨大，装填缓慢。"
	},
	{
		id: "r_sanyan",
		name: "三眼铳",
		slot: "ranged",
		price: 600,
		tier: 3,
		dmg: 26,
		range: 170,
		reload: 2.4,
		ammo: 18,
		kind: "gun",
		desc: "三管火铳，射程较近。"
	},
	{
		id: "a_cloth",
		name: "粗布衣",
		slot: "armor",
		price: 20,
		tier: 1,
		armor: 1,
		desc: ""
	},
	{
		id: "a_pao",
		name: "胖袄",
		slot: "armor",
		price: 160,
		tier: 1,
		armor: 6,
		desc: "明军棉衣，略可御寒防身。"
	},
	{
		id: "a_leather",
		name: "皮甲",
		slot: "armor",
		price: 380,
		tier: 2,
		armor: 10,
		desc: "硬皮缀成的甲衣。"
	},
	{
		id: "a_chain",
		name: "锁子甲",
		slot: "armor",
		price: 900,
		tier: 3,
		armor: 16,
		desc: "铁环相扣，防护均衡。"
	},
	{
		id: "a_cotton",
		name: "布面甲",
		slot: "armor",
		price: 1300,
		tier: 4,
		armor: 20,
		desc: "外覆棉布、内衬铁片的明式甲。"
	},
	{
		id: "a_fish",
		name: "鱼鳞甲",
		slot: "armor",
		price: 2200,
		tier: 5,
		armor: 26,
		desc: "甲片如鱼鳞层叠。"
	},
	{
		id: "a_shanwen",
		name: "山文甲",
		slot: "armor",
		price: 3500,
		tier: 5,
		armor: 32,
		desc: "将官所披的精工铠甲。"
	},
	{
		id: "h_cloth",
		name: "布巾",
		slot: "helm",
		price: 10,
		tier: 1,
		armor: 0,
		desc: ""
	},
	{
		id: "h_felt",
		name: "毡帽",
		slot: "helm",
		price: 60,
		tier: 1,
		armor: 2,
		desc: ""
	},
	{
		id: "h_iron",
		name: "铁盔",
		slot: "helm",
		price: 300,
		tier: 2,
		armor: 5,
		desc: ""
	},
	{
		id: "h_bowl",
		name: "八瓣帽儿盔",
		slot: "helm",
		price: 700,
		tier: 3,
		armor: 8,
		desc: "明军常见的铁盔。"
	},
	{
		id: "h_phoenix",
		name: "凤翅盔",
		slot: "helm",
		price: 1500,
		tier: 5,
		armor: 12,
		desc: "将官的华丽头盔。"
	},
	{
		id: "m_pack",
		name: "驮马",
		slot: "horse",
		price: 200,
		tier: 1,
		horseSpeed: 1.25,
		horseHp: 60,
		horseArmor: 0,
		desc: "驮货的老马，跑不快。"
	},
	{
		id: "m_chuan",
		name: "川马",
		slot: "horse",
		price: 450,
		tier: 2,
		horseSpeed: 1.45,
		horseHp: 80,
		horseArmor: 2,
		desc: "矮小耐劳的西南马。"
	},
	{
		id: "m_mongol",
		name: "蒙古马",
		slot: "horse",
		price: 800,
		tier: 3,
		horseSpeed: 1.6,
		horseHp: 100,
		horseArmor: 3,
		desc: "耐力极佳的草原马。"
	},
	{
		id: "m_hequ",
		name: "河曲马",
		slot: "horse",
		price: 1300,
		tier: 4,
		horseSpeed: 1.75,
		horseHp: 110,
		horseArmor: 4,
		desc: "黄河河曲所产骏马。"
	},
	{
		id: "m_armored",
		name: "披甲战马",
		slot: "horse",
		price: 2400,
		tier: 5,
		horseSpeed: 1.55,
		horseHp: 150,
		horseArmor: 12,
		desc: "马披铁甲的重装战马。"
	},
	{
		id: "m_ferghana",
		name: "大宛良驹",
		slot: "horse",
		price: 3200,
		tier: 5,
		horseSpeed: 1.95,
		horseHp: 120,
		horseArmor: 4,
		desc: "传说中的汗血宝马。"
	}
];
var MELEE = [
	[
		"w_club",
		"木棍",
		1,
		26,
		8,
		26,
		.7,
		"",
		"随手捡来的硬木棍。"
	],
	[
		"w_sickle",
		"镰刀",
		1,
		34,
		9,
		24,
		.65,
		"",
		"农家割麦的镰刀。"
	],
	[
		"w_hatchet",
		"短斧",
		1,
		55,
		10,
		24,
		.75,
		"",
		"劈柴的短柄斧。"
	],
	[
		"w_bamboo",
		"竹枪",
		1,
		45,
		10,
		40,
		1,
		"ac south",
		"削尖的毛竹，乡勇常用。"
	],
	[
		"w_tiechi",
		"铁尺",
		1,
		70,
		10,
		24,
		.6,
		"",
		"捕快衙役的随身兵器。"
	],
	[
		"w_yaodao",
		"腰刀",
		2,
		210,
		13,
		28,
		.7,
		"ming",
		"寻常军士佩带的腰刀。"
	],
	[
		"w_handaxe",
		"手斧",
		2,
		190,
		14,
		26,
		.8,
		"north",
		"边军短兵，近身劈砍。"
	],
	[
		"w_langxian",
		"狼筅",
		2,
		240,
		13,
		46,
		1.1,
		"ac south",
		"戚家军鸳鸯阵利器，枝杈拒敌。"
	],
	[
		"w_tangba",
		"镗钯",
		2,
		280,
		15,
		40,
		1,
		"ac south",
		"三叉镗钯，可架可刺。"
	],
	[
		"w_shuangdao",
		"双刀",
		2,
		300,
		13,
		26,
		.55,
		"",
		"左右开弓，快若疾风。"
	],
	[
		"w_tiebian",
		"铁鞭",
		2,
		320,
		15,
		26,
		.85,
		"north",
		"节节铁鞭，砸甲伤骨。"
	],
	[
		"w_mongolsabre",
		"蒙古弯刀",
		2,
		290,
		14,
		30,
		.68,
		"mon",
		"弧度大，马上劈砍顺手。"
	],
	[
		"w_changjian",
		"长剑",
		3,
		480,
		17,
		32,
		.7,
		"ming",
		"双刃长剑，文武皆宜。"
	],
	[
		"w_gouliang",
		"钩镰枪",
		3,
		560,
		17,
		44,
		1,
		"ac ming",
		"专钩马腿的长枪。"
	],
	[
		"w_bigaxe",
		"大斧",
		3,
		600,
		20,
		34,
		1,
		"north",
		"开山大斧，势大力沉。"
	],
	[
		"w_meteor",
		"流星锤",
		3,
		520,
		18,
		30,
		.9,
		"",
		"铁锤系索，出其不意。"
	],
	[
		"w_tiaodao",
		"挑刀",
		3,
		540,
		17,
		38,
		.9,
		"ming",
		"长柄挑刀，劈挑皆可。"
	],
	[
		"w_shundao",
		"满洲顺刀",
		3,
		580,
		18,
		30,
		.72,
		"jin",
		"八旗兵佩刀，厚背利刃。"
	],
	[
		"w_xiyuedao",
		"川刀",
		3,
		500,
		17,
		30,
		.7,
		"xi",
		"巴蜀铁匠所打的厚刀。"
	],
	[
		"w_zhanma",
		"斩马刀",
		4,
		1150,
		25,
		40,
		1,
		"north",
		"长柄巨刃，专斩马足。"
	],
	[
		"w_langya",
		"狼牙棒",
		4,
		1e3,
		24,
		32,
		1,
		"north",
		"满布铁钉，触者骨碎。"
	],
	[
		"w_huqiang",
		"虎枪",
		4,
		1050,
		22,
		46,
		.95,
		"ac jin",
		"猎虎用的重枪，八旗虎枪营所持。"
	],
	[
		"w_taidao",
		"倭刀",
		4,
		1200,
		23,
		34,
		.8,
		"south",
		"缴自倭寇的长刀，钢口极佳。"
	],
	[
		"w_guduo",
		"铁骨朵",
		4,
		950,
		22,
		28,
		.9,
		"mon",
		"蒙古贵人所持的瓜形铁锤。"
	],
	[
		"w_changfu",
		"长柄大斧",
		4,
		1250,
		26,
		40,
		1.1,
		"north",
		"双手长斧，破阵开甲。"
	],
	[
		"w_sanjian",
		"三尖两刃刀",
		4,
		1300,
		24,
		44,
		1.05,
		"ac ming",
		"刃分三尖，刺劈兼备。"
	],
	[
		"w_huaji",
		"方天画戟",
		5,
		2600,
		30,
		48,
		1.15,
		"ac ming",
		"戟中至尊，非猛将不能使。"
	],
	[
		"w_qixing",
		"七星宝剑",
		5,
		2400,
		26,
		34,
		.62,
		"ming",
		"剑身嵌七星，削铁如泥。"
	],
	[
		"w_modao",
		"陌刀",
		5,
		2800,
		32,
		44,
		1.2,
		"north",
		"唐时陌刀遗制，人马俱碎。"
	],
	[
		"w_jingua",
		"金瓜锤",
		5,
		2300,
		29,
		30,
		1,
		"ming",
		"仪卫重锤，镀金瓜首。"
	],
	[
		"w_binbtie",
		"镔铁大刀",
		5,
		2700,
		31,
		40,
		1.05,
		"jin",
		"镔铁打造的重刀，寒光逼人。"
	]
];
var RANGED = [
	[
		"r_slingbow",
		"竹弓",
		1,
		70,
		8,
		210,
		1.3,
		25,
		"bow",
		"south",
		"竹片所制的轻弓。"
	],
	[
		"r_shortbow",
		"短弓",
		1,
		140,
		11,
		230,
		1.2,
		25,
		"bow",
		"",
		"短小易携，马上亦可用。"
	],
	[
		"r_longbow",
		"长弓",
		2,
		300,
		13,
		270,
		1.4,
		25,
		"bow",
		"ming",
		"明军弓手常用的长弓。"
	],
	[
		"r_juezhang",
		"蹶张弩",
		2,
		380,
		19,
		260,
		2.6,
		20,
		"xbow",
		"ming",
		"以脚踏张弦的强弩。"
	],
	[
		"r_xiujian",
		"袖箭",
		2,
		260,
		12,
		160,
		1.6,
		15,
		"xbow",
		"",
		"藏于袖中的机括短箭。"
	],
	[
		"r_mongolbow",
		"蒙古角弓",
		3,
		520,
		16,
		290,
		1.25,
		26,
		"bow",
		"mon",
		"草原骑手的复合弓，射远而疾。"
	],
	[
		"r_shenbi",
		"神臂弩",
		3,
		640,
		23,
		290,
		2.8,
		20,
		"xbow",
		"ming",
		"宋时神臂弓遗制，三百步透甲。"
	],
	[
		"r_kuaiqiang",
		"快枪",
		3,
		560,
		24,
		180,
		2.2,
		18,
		"gun",
		"north",
		"边军火门枪，打完可当锤使。"
	],
	[
		"r_paoshou",
		"迅雷铳",
		4,
		1100,
		30,
		200,
		3,
		20,
		"gun",
		"ming",
		"五管轮放的火铳，赵士祯所制。"
	],
	[
		"r_dashao",
		"大梢弓",
		4,
		950,
		20,
		270,
		1.5,
		22,
		"bow",
		"jin",
		"大梢重弓，近射如锥。"
	],
	[
		"r_zhuque",
		"诸葛连弩",
		4,
		1e3,
		16,
		220,
		1,
		30,
		"xbow",
		"xi",
		"一发十矢，连珠而出。"
	],
	[
		"r_lumi",
		"鲁密铳",
		5,
		2200,
		40,
		270,
		3.4,
		18,
		"gun",
		"ming",
		"仿鲁迷国火绳枪，明军最精良的火器。"
	],
	[
		"r_diaogong",
		"雕弓",
		5,
		2e3,
		24,
		300,
		1.35,
		26,
		"bow",
		"mon",
		"可射落大雕的名弓。"
	],
	[
		"r_chedian",
		"掣电铳",
		5,
		2400,
		36,
		250,
		2.6,
		18,
		"gun",
		"south",
		"后装子铳，装填远胜鸟铳。"
	]
];
var ARMOR = [
	[
		"a_duanhe",
		"短褐",
		"armor",
		1,
		30,
		2,
		"",
		"穷苦人家的粗布短衣。"
	],
	[
		"a_haoyi",
		"号衣",
		"armor",
		1,
		90,
		4,
		"ming",
		"营兵的号坎，聊以识别。"
	],
	[
		"a_paperarmor",
		"纸甲",
		"armor",
		2,
		260,
		8,
		"south",
		"层层厚纸压制，箭矢难透。"
	],
	[
		"a_tengjia",
		"藤甲",
		"armor",
		2,
		320,
		9,
		"south",
		"山藤浸油编成，轻韧不沉。"
	],
	[
		"a_pizha",
		"皮扎甲",
		"armor",
		2,
		420,
		11,
		"mon",
		"牛皮甲片以皮绳扎就。"
	],
	[
		"a_suozibei",
		"锁子背心",
		"armor",
		3,
		700,
		14,
		"north",
		"只护胸背的锁甲，轻便灵活。"
	],
	[
		"a_zhaojia",
		"罩甲",
		"armor",
		3,
		820,
		15,
		"ming",
		"对襟罩甲，武官常服其外。"
	],
	[
		"a_yuanyang",
		"鸳鸯战袄",
		"armor",
		3,
		650,
		13,
		"ming",
		"两面可穿的厚棉战袄。"
	],
	[
		"a_mongolleather",
		"蒙古皮甲",
		"armor",
		3,
		760,
		14,
		"mon",
		"多层硬皮缝合，骑射轻甲。"
	],
	[
		"a_qiyao",
		"齐腰甲",
		"armor",
		4,
		1500,
		19,
		"ming",
		"护至腰际的铁甲，戚家军制。"
	],
	[
		"a_manchu",
		"满洲棉甲",
		"armor",
		4,
		1700,
		21,
		"jin",
		"内缀铁叶的棉甲，八旗正兵所披。"
	],
	[
		"a_tiezha",
		"铁扎甲",
		"armor",
		4,
		1800,
		22,
		"north",
		"铁片层叠扎成，九边精兵所用。"
	],
	[
		"a_mingguang",
		"明光铠",
		"armor",
		5,
		3800,
		30,
		"ming",
		"胸前护心镜明亮如日。"
	],
	[
		"a_lianhuan",
		"锁子连环甲",
		"armor",
		5,
		3300,
		28,
		"xi",
		"连环相扣的精锁甲。"
	],
	[
		"a_jinqi",
		"金漆山文甲",
		"armor",
		5,
		4800,
		34,
		"ming",
		"描金漆饰的山文铠，总兵以上方得披挂。"
	],
	[
		"h_douli",
		"斗笠",
		"helm",
		1,
		25,
		1,
		"south",
		"竹编斗笠，遮阳挡雨。"
	],
	[
		"h_fanyang",
		"范阳笠",
		"helm",
		1,
		70,
		2,
		"",
		"毡制大笠，江湖人常戴。"
	],
	[
		"h_leather",
		"皮盔",
		"helm",
		2,
		200,
		4,
		"mon",
		"硬皮缝制的头盔。"
	],
	[
		"h_hongying",
		"红缨帽",
		"helm",
		2,
		240,
		4,
		"jin",
		"缀红缨的暖帽，内衬铁片。"
	],
	[
		"h_tieli",
		"铁笠盔",
		"helm",
		3,
		600,
		7,
		"ming",
		"笠形铁盔，宽檐遮箭。"
	],
	[
		"h_jianding",
		"尖顶盔",
		"helm",
		3,
		680,
		8,
		"jin",
		"高顶尖盔，八旗兵式样。"
	],
	[
		"h_mongoliron",
		"蒙古铁盔",
		"helm",
		3,
		620,
		7,
		"mon",
		"带护颈的圆铁盔。"
	],
	[
		"h_huxiang",
		"护项铁盔",
		"helm",
		4,
		1e3,
		10,
		"north",
		"带铁护项的重盔。"
	],
	[
		"h_toumou",
		"头鍪",
		"helm",
		4,
		1100,
		10,
		"ming",
		"古制兜鍪，护耳护颈。"
	],
	[
		"h_gaoding",
		"满洲高顶盔",
		"helm",
		4,
		1150,
		11,
		"jin",
		"盔顶高耸插缨，巴牙喇常戴。"
	],
	[
		"h_jinkui",
		"金盔",
		"helm",
		5,
		1900,
		13,
		"ming",
		"鎏金铁盔，将门之冠。"
	],
	[
		"h_shitou",
		"狮头盔",
		"helm",
		5,
		2e3,
		13,
		"xi",
		"盔额铸狮首，威风凛凛。"
	]
];
var HORSES = [
	[
		"m_mule",
		"骡子",
		1,
		150,
		1.15,
		70,
		0,
		"",
		"驮重耐劳，就是跑不快。"
	],
	[
		"m_nag",
		"驽马",
		1,
		230,
		1.3,
		65,
		0,
		"",
		"老弱之马，勉强可骑。"
	],
	[
		"m_dian",
		"滇马",
		2,
		420,
		1.45,
		75,
		2,
		"south",
		"云南山马，善走山路。"
	],
	[
		"m_liao",
		"辽马",
		2,
		520,
		1.5,
		85,
		2,
		"jin",
		"辽东所产，体健耐寒。"
	],
	[
		"m_qinghai",
		"青海骢",
		3,
		900,
		1.65,
		95,
		3,
		"xi",
		"青海湖畔所产的骏马。"
	],
	[
		"m_ujimqin",
		"乌珠穆沁马",
		3,
		950,
		1.66,
		105,
		3,
		"mon",
		"草原名马，奔走如飞。"
	],
	[
		"m_guanxi",
		"关西马",
		3,
		850,
		1.6,
		100,
		4,
		"north",
		"关西骏马，边军精骑所乘。"
	],
	[
		"m_yili",
		"伊犁马",
		4,
		1500,
		1.8,
		115,
		4,
		"mon",
		"西域良马，高大俊美。"
	],
	[
		"m_hetao",
		"河套战马",
		4,
		1600,
		1.72,
		125,
		6,
		"north",
		"河套草场所育的战马，可披半甲。"
	],
	[
		"m_zhaoye",
		"照夜玉狮子",
		5,
		3600,
		2,
		120,
		4,
		"ming",
		"通体雪白的神驹。"
	],
	[
		"m_wuzhui",
		"乌骓",
		5,
		3400,
		1.9,
		140,
		8,
		"jin",
		"霸王坐骑之名，黑缎般的烈马。"
	]
];
var tags = {};
var flagged = (id, f) => {
	const t = f.split(" ").filter(Boolean);
	tags[id] = t.filter((x) => x !== "ac");
	return t.includes("ac");
};
for (const [id, name, tier, price, dmg, reach, speed, f, desc] of MELEE) items.push({
	id,
	name,
	slot: "melee",
	tier,
	price,
	dmg,
	reach,
	speed,
	antiCav: flagged(id, f) || void 0,
	desc
});
for (const [id, name, tier, price, dmg, range, reload, ammo, kind, f, desc] of RANGED) {
	flagged(id, f);
	items.push({
		id,
		name,
		slot: "ranged",
		tier,
		price,
		dmg,
		range,
		reload,
		ammo,
		kind,
		desc
	});
}
for (const [id, name, slot, tier, price, armor, f, desc] of ARMOR) {
	flagged(id, f);
	items.push({
		id,
		name,
		slot,
		tier,
		price,
		armor,
		desc
	});
}
for (const [id, name, tier, price, horseSpeed, horseHp, horseArmor, f, desc] of HORSES) {
	flagged(id, f);
	items.push({
		id,
		name,
		slot: "horse",
		tier,
		price,
		horseSpeed,
		horseHp,
		horseArmor,
		desc
	});
}
Object.assign(tags, {
	w_yanling: ["ming"],
	w_miaodao: ["south"],
	w_horselance: ["north"],
	r_hornbow: ["north"],
	r_manchubow: ["jin"],
	r_niaochong: ["ming", "south"],
	r_sanyan: ["north"],
	a_pao: ["ming"],
	a_cotton: ["ming"],
	a_fish: ["ming"],
	h_bowl: ["ming"],
	m_chuan: ["xi"],
	m_mongol: ["mon"],
	m_hequ: ["north"],
	m_ferghana: ["mon"]
});
var QUALITY = [
	{
		q: 0,
		suffix: "~0",
		name: {
			melee: "破旧",
			ranged: "破旧",
			armor: "破损",
			helm: "破损",
			horse: "瘦弱"
		},
		mul: .82,
		price: .5,
		minTier: 1
	},
	{
		q: 2,
		suffix: "~2",
		name: {
			melee: "精良",
			ranged: "精良",
			armor: "精制",
			helm: "精制",
			horse: "健壮"
		},
		mul: 1.12,
		price: 1.7,
		minTier: 2
	},
	{
		q: 3,
		suffix: "~3",
		name: {
			melee: "名匠",
			ranged: "名匠",
			armor: "名匠",
			helm: "名匠",
			horse: "神骏"
		},
		mul: 1.24,
		price: 3,
		minTier: 3
	}
];
var baseItems = items.filter((i) => i.price > 25);
for (const b of baseItems) for (const Q of QUALITY) {
	if (b.tier < Q.minTier) continue;
	const it = {
		...b,
		id: b.id + Q.suffix,
		name: Q.name[b.slot] + b.name,
		price: Math.round(b.price * Q.price),
		base: b.id,
		quality: Q.q
	};
	const r1 = (v) => v === void 0 ? void 0 : Math.max(0, Math.round(v * Q.mul * 10) / 10);
	if (it.dmg !== void 0) it.dmg = Math.max(1, Math.round(b.dmg * Q.mul));
	if (it.armor !== void 0) it.armor = Math.max(0, Math.round(b.armor * Q.mul));
	if (it.speed !== void 0) it.speed = Math.round(b.speed / Math.sqrt(Q.mul) * 100) / 100;
	if (it.reload !== void 0) it.reload = Math.round(b.reload / Math.sqrt(Q.mul) * 10) / 10;
	if (it.horseSpeed !== void 0) it.horseSpeed = Math.round(b.horseSpeed * Math.sqrt(Q.mul) * 100) / 100;
	if (it.horseHp !== void 0) it.horseHp = Math.round(b.horseHp * Q.mul);
	if (it.horseArmor !== void 0) it.horseArmor = r1(b.horseArmor);
	it.desc = Q.q === 0 ? `${b.desc}（年久失修）` : Q.q === 2 ? `${b.desc}（做工精良）` : `${b.desc}（名匠所制，世所罕见）`;
	items.push(it);
	tags[it.id] = tags[b.id] ?? [];
}
/** 装备的地域标签（用于商店进货权重） */
var ITEM_TAGS = tags;
var ITEMS = {};
for (const it of items) ITEMS[it.id] = it;
var ITEM_LIST = items;
var GOODS = [
	{
		id: "grain",
		name: "米粮",
		base: 18,
		food: 1
	},
	{
		id: "meat",
		name: "腌肉",
		base: 40,
		food: 1,
		morale: 2
	},
	{
		id: "wine",
		name: "烧酒",
		base: 55,
		food: 1,
		morale: 4
	},
	{
		id: "salt",
		name: "盐",
		base: 70
	},
	{
		id: "cloth",
		name: "棉布",
		base: 90
	},
	{
		id: "tea",
		name: "茶叶",
		base: 120
	},
	{
		id: "iron",
		name: "铁器",
		base: 150
	},
	{
		id: "herb",
		name: "药材",
		base: 160
	},
	{
		id: "fur",
		name: "毛皮",
		base: 180
	},
	{
		id: "porcelain",
		name: "瓷器",
		base: 230
	},
	{
		id: "silk",
		name: "丝绸",
		base: 300
	},
	{
		id: "ginseng",
		name: "人参",
		base: 420
	},
	{
		id: "flour",
		name: "面粉",
		base: 22,
		food: 1
	},
	{
		id: "fish",
		name: "鱼干",
		base: 34,
		food: 1
	},
	{
		id: "fruit",
		name: "干果",
		base: 46,
		food: 1,
		morale: 1
	},
	{
		id: "cheese",
		name: "奶食",
		base: 52,
		food: 1,
		morale: 2
	},
	{
		id: "kumis",
		name: "马奶酒",
		base: 62,
		food: 1,
		morale: 3
	},
	{
		id: "ricewine",
		name: "黄酒",
		base: 75,
		food: 1,
		morale: 4
	},
	{
		id: "timber",
		name: "木材",
		base: 38
	},
	{
		id: "hemp",
		name: "麻布",
		base: 50
	},
	{
		id: "pottery",
		name: "陶器",
		base: 60
	},
	{
		id: "sugar",
		name: "蔗糖",
		base: 85
	},
	{
		id: "leather",
		name: "皮革",
		base: 100
	},
	{
		id: "tobacco",
		name: "烟草",
		base: 130
	},
	{
		id: "paper",
		name: "纸墨",
		base: 140
	},
	{
		id: "copper",
		name: "铜料",
		base: 170
	},
	{
		id: "saltpeter",
		name: "硝石",
		base: 200
	},
	{
		id: "books",
		name: "书籍",
		base: 210
	},
	{
		id: "lacquer",
		name: "漆器",
		base: 260
	},
	{
		id: "spice",
		name: "香料",
		base: 340
	},
	{
		id: "antler",
		name: "鹿茸",
		base: 380
	},
	{
		id: "pearl",
		name: "珍珠",
		base: 500
	},
	{
		id: "jade",
		name: "玉器",
		base: 600
	},
	{
		id: "horse_t",
		name: "马匹（成群）",
		base: 260
	}
];
var GOOD = {};
for (const g of GOODS) GOOD[g.id] = g;
//#endregion
//#region src/core/state.ts
function warKey(a, b) {
	return a < b ? `${a}|${b}` : `${b}|${a}`;
}
//#endregion
//#region src/core/rng.ts
function randInt(a, b) {
	return a + Math.floor(Math.random() * (b - a + 1));
}
function randRange(a, b) {
	return a + Math.random() * (b - a);
}
function pick(arr) {
	return arr[Math.floor(Math.random() * arr.length)];
}
function chance(p) {
	return Math.random() < p;
}
function shuffle(arr) {
	for (let i = arr.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[arr[i], arr[j]] = [arr[j], arr[i]];
	}
	return arr;
}
function weighted(items) {
	let total = 0;
	for (const [, w] of items) total += w;
	let r = Math.random() * total;
	for (const [it, w] of items) {
		r -= w;
		if (r <= 0) return it;
	}
	return items[items.length - 1][0];
}
function hash2(x, y, seed) {
	let h = x * 374761393 + y * 668265263 + seed * 2147483647 | 0;
	h = Math.imul(h ^ h >>> 13, 1274126177);
	h ^= h >>> 16;
	return (h >>> 0) / 4294967296;
}
function smooth(t) {
	return t * t * (3 - 2 * t);
}
function valueNoise(x, y, seed) {
	const xi = Math.floor(x), yi = Math.floor(y);
	const xf = x - xi, yf = y - yi;
	const a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed);
	const c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
	const u = smooth(xf), v = smooth(yf);
	return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x, y, seed, oct = 4) {
	let s = 0, amp = .5, f = 1, norm = 0;
	for (let i = 0; i < oct; i++) {
		s += valueNoise(x * f, y * f, seed + i * 17) * amp;
		norm += amp;
		amp *= .5;
		f *= 2;
	}
	return s / norm;
}
function dist$1(ax, ay, bx, by) {
	return Math.hypot(ax - bx, ay - by);
}
var LAT0 = 45.5;
var WORLD_W = 3200;
var WORLD_H = 2800;
var GW = Math.ceil(WORLD_W / 16);
var GH = Math.ceil(WORLD_H / 16);
function ll(lon, lat) {
	return [(lon - 96) * 100, (LAT0 - lat) * 100];
}
function toLL(x, y) {
	return [x / 100 + 96, LAT0 - y / 100];
}
var Ter = /* @__PURE__ */ function(Ter) {
	Ter[Ter["Sea"] = 0] = "Sea";
	Ter[Ter["Plain"] = 1] = "Plain";
	Ter[Ter["Steppe"] = 2] = "Steppe";
	Ter[Ter["Forest"] = 3] = "Forest";
	Ter[Ter["Hills"] = 4] = "Hills";
	Ter[Ter["Mountain"] = 5] = "Mountain";
	Ter[Ter["Desert"] = 6] = "Desert";
	Ter[Ter["Plateau"] = 7] = "Plateau";
	return Ter;
}({});
var TER_SPEED = [
	0,
	1,
	1.05,
	.72,
	.8,
	.55,
	.78,
	0
];
var POLYS = [
	[
		[95, 46],
		[129, 46],
		[129, 42.5],
		[128, 41],
		[126.5, 40.3],
		[125.2, 39.9],
		[124.3, 39.8],
		[123.2, 39.6],
		[122.2, 39.2],
		[121.2, 38.75],
		[121.4, 39.3],
		[121.8, 39.8],
		[122.2, 40.5],
		[121.4, 40.85],
		[120.6, 40.4],
		[119.8, 39.9],
		[119, 39.3],
		[118.2, 39.05],
		[117.7, 38.9],
		[117.7, 38.3],
		[118.6, 37.8],
		[119.1, 37.2],
		[119.8, 37.2],
		[120.4, 37.6],
		[121.4, 37.6],
		[122.6, 37.35],
		[122, 36.9],
		[121, 36.6],
		[120.3, 36.05],
		[119.4, 35.2],
		[119.3, 34.7],
		[120.3, 34.3],
		[120.9, 32.7],
		[121.9, 31.75],
		[121.9, 30.95],
		[121, 30.55],
		[121.6, 30],
		[121.9, 29.7],
		[121.5, 28.7],
		[120.8, 27.9],
		[120.2, 27],
		[119.7, 26.1],
		[119, 25.2],
		[118.4, 24.5],
		[117.3, 23.7],
		[116.4, 22.95],
		[115.3, 22.7],
		[114.2, 22.3],
		[113.5, 22.15],
		[112.5, 21.8],
		[111.4, 21.5],
		[110.5, 21.2],
		[110.2, 20.3],
		[109.9, 20.6],
		[109.7, 21.5],
		[108.5, 21.6],
		[107.8, 21.4],
		[107, 20.6],
		[106.6, 19.6],
		[105.8, 18.6],
		[106.4, 17],
		[95, 17]
	],
	[
		[108.6, 19.1],
		[109.4, 18.25],
		[110.4, 18.6],
		[111, 19.6],
		[110.6, 20.1],
		[109.6, 20.05],
		[108.7, 19.6]
	],
	[
		[120.1, 23],
		[120.75, 21.95],
		[121.45, 23.2],
		[122, 25],
		[121.5, 25.3],
		[121, 25.05],
		[120.2, 24]
	]
];
var GREAT_WALL = [
	[96, 40.25],
	[97, 40.05],
	[98.2, 39.8],
	[100.5, 38.9],
	[102.6, 37.9],
	[104, 37.4],
	[106, 37.6],
	[107.6, 37.95],
	[109.7, 38.3],
	[111, 39.5],
	[112.4, 39.95],
	[113.3, 40.3],
	[114.6, 40.85],
	[115.6, 40.7],
	[116.5, 40.45],
	[117.8, 40.3],
	[119, 40.15],
	[119.75, 40],
	[119.87, 39.86]
];
function inPoly(lon, lat, poly) {
	let inside = false;
	for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
		const [xi, yi] = poly[i], [xj, yj] = poly[j];
		if (yi > lat !== yj > lat && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside;
	}
	return inside;
}
function segDist(px, py, line) {
	let best = 1e9;
	for (let i = 0; i < line.length - 1; i++) {
		const [ax, ay] = line[i], [bx, by] = line[i + 1];
		const dx = bx - ax, dy = by - ay;
		const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)));
		const d = Math.hypot(px - ax - t * dx, py - ay - t * dy);
		if (d < best) best = d;
	}
	return best;
}
var RIDGES = [
	{
		line: [
			[112.8, 35],
			[113.8, 36.5],
			[114.2, 38],
			[114.7, 39.6],
			[115.6, 40.5]
		],
		w: .38,
		t: 5
	},
	{
		line: [
			[104.5, 34.1],
			[106.5, 34],
			[108.5, 33.9],
			[110.6, 33.8],
			[112, 33.5]
		],
		w: .42,
		t: 5
	},
	{
		line: [
			[105.6, 32.4],
			[107.5, 32],
			[109.8, 31.6]
		],
		w: .45,
		t: 4
	},
	{
		line: [
			[115.6, 40.7],
			[117.5, 40.6],
			[119.2, 40.4]
		],
		w: .35,
		t: 4
	},
	{
		line: [
			[116.3, 25.8],
			[117.5, 27],
			[118.6, 28.4]
		],
		w: .55,
		t: 4
	},
	{
		line: [
			[109.5, 25.6],
			[112, 25.4],
			[115, 25]
		],
		w: .5,
		t: 4
	},
	{
		line: [
			[110.8, 36],
			[111.3, 37.5],
			[111.7, 39]
		],
		w: .3,
		t: 4
	},
	{
		line: [
			[124.5, 40.8],
			[126, 41.8],
			[127.5, 43]
		],
		w: .8,
		t: 5
	},
	{
		line: [
			[120.5, 45.5],
			[119.6, 44],
			[118.8, 42.8]
		],
		w: .5,
		t: 4
	},
	{
		line: [[114.5, 31.6], [116.2, 31]],
		w: .35,
		t: 4
	},
	{
		line: [
			[103.5, 28.2],
			[104.3, 31.8],
			[105.6, 32.4]
		],
		w: .35,
		t: 4
	},
	{
		line: [
			[100, 37.5],
			[101.5, 37.6],
			[103, 37.2]
		],
		w: .45,
		t: 5
	}
];
var SEED = 1635;
function terrainAt(lon, lat) {
	let land = false;
	for (const p of POLYS) if (inPoly(lon, lat, p)) {
		land = true;
		break;
	}
	if (!land) return 0;
	const n = fbm(lon * .9, lat * .9, SEED);
	const n2 = fbm(lon * 2.3 + 50, lat * 2.3, 1734, 3);
	const wob = (fbm(lat * .7, 3.3, 1642, 3) - .5) * 3.2;
	if (lon < 99.8 + wob + n * .8 && lat < 37.5 - wob * .3) return 7;
	if (lon < 103 + wob * .7 + (n - .5) * 1.5 && lat < 36.5 && lat > 26 + wob * .5) {
		if (lon < 101.2 + wob * .5) return n2 > .35 ? 5 : 4;
		return n2 > .45 ? 5 : 4;
	}
	for (const r of RIDGES) if (segDist(lon, lat, r.line) < r.w * (.45 + n2 * .9)) return r.t;
	if (Math.hypot((lon - 105) / 1.9, (lat - 30.2) / 1.4) < 1) return n2 > .72 ? 4 : 1;
	if (lat > 39.4 + (n - .5) && lon < 108.5) return n2 > .55 ? 2 : 6;
	if (lat > 42.6 + (n - .5) * 1.5 && lon < 113.5) return n2 > .4 ? 6 : 2;
	if (lat > 40.7 + (n - .5) * .8 && lon < 121) return n2 > .78 ? 4 : 2;
	if (lon >= 121 && lat > 40.5) {
		if (lon > 124.2 + (n - .5) * 2) return n2 > .45 ? 3 : 4;
		return n2 > .68 ? 3 : 1;
	}
	if (lon > 103.5 && lon < 112 && lat > 34.3 && lat < 39.5) return n2 > .56 ? 4 : 1;
	if (lon < 109.5 && lat < 28.6) return n2 > .5 ? 4 : n2 > .36 ? 3 : 1;
	if (lon > 113.5 && lat > 32 && lat < 40.5) return n2 > .8 ? 3 : 1;
	if (lat < 30.5) {
		if (lon > 119 && lat > 29.6) return n2 > .75 ? 4 : 1;
		if (n2 > .62) return 4;
		if (n2 > .47) return 3;
		return 1;
	}
	if (n2 > .7) return 3;
	if (n2 > .64) return 4;
	return 1;
}
var FW = Math.ceil(WORLD_W / 8);
var FH = Math.ceil(WORLD_H / 8);
var fineGrid = new Uint8Array(FW * FH);
var grid = /* @__PURE__ */ new Uint8Array(35e3);
var gridReady = false;
function buildGrid() {
	if (gridReady) return;
	for (let fy = 0; fy < FH; fy++) for (let fx = 0; fx < FW; fx++) {
		const [lon, lat] = toLL(fx * 8 + 4, fy * 8 + 4);
		fineGrid[fy * FW + fx] = terrainAt(lon, lat);
	}
	const r = 2;
	for (let gy = 0; gy < GH; gy++) for (let gx = 0; gx < GW; gx++) {
		let sea = 0, best = 0, slow = 99;
		for (let oy = 0; oy < r; oy++) for (let ox = 0; ox < r; ox++) {
			const fx = gx * r + ox, fy = gy * r + oy;
			const t = fx < FW && fy < FH ? fineGrid[fy * FW + fx] : 0;
			if (t === 0) sea++;
			else if (t === 7) {
				if (best === 0) best = t;
			} else if (TER_SPEED[t] < slow || best === 0 || best === 7) {
				slow = TER_SPEED[t];
				best = t;
			}
		}
		grid[gy * GW + gx] = sea >= 3 ? 0 : best;
	}
	gridReady = true;
}
function terAtXY(x, y) {
	const gx = Math.floor(x / 16), gy = Math.floor(y / 16);
	if (gx < 0 || gy < 0 || gx >= GW || gy >= GH) return 0;
	return grid[gy * GW + gx];
}
function passable(x, y) {
	return TER_SPEED[terAtXY(x, y)] > 0;
}
var wallSeg = (/* @__PURE__ */ new Int16Array(35e3)).fill(-1);
var gateCell = (/* @__PURE__ */ new Int8Array(35e3)).fill(-1);
var regionGrid = /* @__PURE__ */ new Uint8Array(35e3);
var wallRule = null;
function setWallRule(fn) {
	wallRule = fn;
}
function cellIndex(x, y) {
	const gx = Math.floor(x / 16), gy = Math.floor(y / 16);
	return gx < 0 || gy < 0 || gx >= GW || gy >= GH ? -1 : gy * GW + gx;
}
function wallRuleAt(x, y, who) {
	const ci = cellIndex(x, y);
	if (ci < 0 || wallSeg[ci] < 0 || !wallRule || who === void 0) return 1;
	return wallRule(ci, who);
}
/** 两点之间是否有挡路的城墙（2 = 需夜间潜越） */
function wallBetween(x0, y0, x1, y1, who) {
	if (who === void 0 || !wallRule) return 0;
	let worst = 0;
	traceCells(x0, y0, x1, y1, (ci) => {
		if (wallSeg[ci] < 0) return true;
		const r = wallRule(ci, who);
		if (r === 0) {
			worst = 1;
			return false;
		}
		if (r === 2) worst = 2;
		return true;
	});
	return worst;
}
/** 精确遍历线段经过的所有格（Amanatides–Woo，穿过格点时两侧邻格都算）。visit 返回 false 则中止；越界返回 false */
function traceCells(x0, y0, x1, y1, visit) {
	let gx = Math.floor(x0 / 16), gy = Math.floor(y0 / 16);
	const ex = Math.floor(x1 / 16), ey = Math.floor(y1 / 16);
	const inb = (x, y) => x >= 0 && y >= 0 && x < GW && y < GH;
	if (!inb(gx, gy)) return false;
	if (!visit(gy * GW + gx)) return false;
	const dx = x1 - x0, dy = y1 - y0;
	const stepX = dx > 0 ? 1 : -1, stepY = dy > 0 ? 1 : -1;
	const tdx = dx !== 0 ? Math.abs(16 / dx) : Infinity, tdy = dy !== 0 ? Math.abs(16 / dy) : Infinity;
	let tmx = dx !== 0 ? (stepX > 0 ? (gx + 1) * 16 - x0 : x0 - gx * 16) / Math.abs(dx) : Infinity;
	let tmy = dy !== 0 ? (stepY > 0 ? (gy + 1) * 16 - y0 : y0 - gy * 16) / Math.abs(dy) : Infinity;
	for (let n = 0; n < 1500 && (gx !== ex || gy !== ey); n++) {
		if (Math.abs(tmx - tmy) < 1e-9) {
			if (!inb(gx + stepX, gy) || !visit(gy * GW + gx + stepX)) return false;
			if (!inb(gx, gy + stepY) || !visit((gy + stepY) * GW + gx)) return false;
			gx += stepX;
			gy += stepY;
			tmx += tdx;
			tmy += tdy;
		} else if (tmx < tmy) {
			gx += stepX;
			tmx += tdx;
		} else {
			gy += stepY;
			tmy += tdy;
		}
		if (!inb(gx, gy) || !visit(gy * GW + gx)) return false;
	}
	return true;
}
function nearestPassable(x, y) {
	if (passable(x, y)) return [x, y];
	for (let r = 16; r < 600; r += 8) for (let a = 0; a < 16; a++) {
		const px = x + Math.cos(a / 16 * Math.PI * 2) * r, py = y + Math.sin(a / 16 * Math.PI * 2) * r;
		if (passable(px, py)) return [px, py];
	}
	return [x, y];
}
var gScore = /* @__PURE__ */ new Float32Array(35e3);
var came = /* @__PURE__ */ new Int32Array(35e3);
var closed = /* @__PURE__ */ new Uint8Array(35e3);
var stamp = /* @__PURE__ */ new Uint32Array(35e3);
var curStamp = 1;
var Heap = class {
	constructor() {
		this.a = [];
		this.f = [];
	}
	push(i, f) {
		this.a.push(i);
		this.f.push(f);
		let k = this.a.length - 1;
		while (k > 0) {
			const p = k - 1 >> 1;
			if (this.f[p] <= this.f[k]) break;
			[this.a[p], this.a[k]] = [this.a[k], this.a[p]];
			[this.f[p], this.f[k]] = [this.f[k], this.f[p]];
			k = p;
		}
	}
	pop() {
		const top = this.a[0];
		const la = this.a.pop(), lf = this.f.pop();
		if (this.a.length) {
			this.a[0] = la;
			this.f[0] = lf;
			let k = 0;
			const n = this.a.length;
			for (;;) {
				const l = 2 * k + 1, r = l + 1;
				let m = k;
				if (l < n && this.f[l] < this.f[m]) m = l;
				if (r < n && this.f[r] < this.f[m]) m = r;
				if (m === k) break;
				[this.a[m], this.a[k]] = [this.a[k], this.a[m]];
				[this.f[m], this.f[k]] = [this.f[k], this.f[m]];
				k = m;
			}
		}
		return top;
	}
	get size() {
		return this.a.length;
	}
};
function losClear(x0, y0, x1, y1, who) {
	if (who !== void 0 && wallBetween(x0, y0, x1, y1, who)) return false;
	let startSpeed = -1;
	return traceCells(x0, y0, x1, y1, (ci) => {
		const sp = TER_SPEED[grid[ci]];
		if (startSpeed < 0) {
			startSpeed = sp;
			return true;
		}
		if (sp <= 0) return false;
		if (sp < .7 && startSpeed >= .7) return false;
		startSpeed = Math.min(startSpeed, sp);
		return true;
	});
}
function findPath(sx, sy, tx, ty, who) {
	[tx, ty] = nearestPassable(tx, ty);
	if (who !== void 0 && wallRule) {
		const gi = cellIndex(tx, ty);
		if (gi >= 0 && wallSeg[gi] >= 0 && wallRule(gi, who) !== 1) {
			const si = cellIndex(sx, sy), sr = si >= 0 ? regionGrid[si] : 0;
			let ok = false;
			for (const r of [
				18,
				26,
				34,
				44,
				56
			]) {
				for (let a = 0; a < 16 && !ok; a++) {
					const px = tx + Math.cos(a / 16 * Math.PI * 2) * r, py = ty + Math.sin(a / 16 * Math.PI * 2) * r;
					const ci = cellIndex(px, py);
					if (ci < 0 || wallSeg[ci] >= 0 || TER_SPEED[grid[ci]] <= 0 || sr && regionGrid[ci] !== sr) continue;
					tx = px;
					ty = py;
					ok = true;
				}
				if (ok) break;
			}
		}
	}
	if (losClear(sx, sy, tx, ty, who) && Math.hypot(tx - sx, ty - sy) < 140) return [[tx, ty]];
	const walls = who !== void 0 && !!wallRule;
	const sgx = Math.floor(sx / 16), sgy = Math.floor(sy / 16);
	const tgx = Math.floor(tx / 16), tgy = Math.floor(ty / 16);
	if (tgx < 0 || tgy < 0 || tgx >= GW || tgy >= GH) return null;
	curStamp++;
	const start = sgy * GW + sgx, goal = tgy * GW + tgx;
	const heap = new Heap();
	stamp[start] = curStamp;
	gScore[start] = 0;
	came[start] = -1;
	closed[start] = 0;
	heap.push(start, 0);
	let found = false, iter = 0;
	while (heap.size && iter++ < 6e4) {
		const cur = heap.pop();
		if (cur === goal) {
			found = true;
			break;
		}
		if (closed[cur] && stamp[cur] === curStamp) continue;
		closed[cur] = 1;
		const cx = cur % GW, cy = cur / GW | 0;
		for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
			if (!dx && !dy) continue;
			const nx = cx + dx, ny = cy + dy;
			if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue;
			const ni = ny * GW + nx;
			const sp = TER_SPEED[grid[ni]];
			if (sp <= 0) continue;
			if (dx && dy && (TER_SPEED[grid[cy * GW + nx]] <= 0 || TER_SPEED[grid[ny * GW + cx]] <= 0)) continue;
			let mul = 1;
			if (walls && wallSeg[ni] >= 0) {
				const r = wallRule(ni, who);
				if (r === 0) continue;
				if (r === 2) mul = 6;
			}
			if (walls && dx && dy) {
				const c1 = cy * GW + nx, c2 = ny * GW + cx;
				if (wallSeg[c1] >= 0 && wallRule(c1, who) === 0 || wallSeg[c2] >= 0 && wallRule(c2, who) === 0) continue;
			}
			const cost = (dx && dy ? 1.4142 : 1) / sp * mul;
			const ng = gScore[cur] + cost;
			if (stamp[ni] !== curStamp) {
				stamp[ni] = curStamp;
				closed[ni] = 0;
				gScore[ni] = Infinity;
			}
			if (ng < gScore[ni]) {
				gScore[ni] = ng;
				came[ni] = cur;
				const h = Math.hypot(nx - tgx, ny - tgy) / 1.05;
				heap.push(ni, ng + h);
			}
		}
	}
	if (!found) return null;
	const cells = [];
	for (let c = goal; c !== -1 && c !== start; c = came[c]) cells.push([c % GW * 16 + 8, (c / GW | 0) * 16 + 8]);
	cells.reverse();
	cells[cells.length - 1] = [tx, ty];
	const out = [];
	let ax = sx, ay = sy, i = 0;
	while (i < cells.length) {
		let j = Math.min(cells.length - 1, i + 24);
		while (j > i && !losClear(ax, ay, cells[j][0], cells[j][1], who)) j--;
		out.push(cells[j]);
		[ax, ay] = cells[j];
		i = j + 1;
	}
	return out;
}
//#endregion
//#region src/core/character.ts
var SKILLS = [
	{
		id: "ironflesh",
		name: "铁骨",
		attr: "str",
		party: false,
		desc: "每级 +6 生命"
	},
	{
		id: "powerstrike",
		name: "强击",
		attr: "str",
		party: false,
		desc: "每级近战伤害 +8%"
	},
	{
		id: "training",
		name: "训练",
		attr: "str",
		party: true,
		desc: "每日为部下提供经验"
	},
	{
		id: "archery",
		name: "射术",
		attr: "agi",
		party: false,
		desc: "每级远程伤害 +7%，精度提高"
	},
	{
		id: "riding",
		name: "骑术",
		attr: "agi",
		party: false,
		desc: "可驾驭更好的马匹，马速提升"
	},
	{
		id: "tactics",
		name: "战术",
		attr: "int",
		party: true,
		desc: "自动结算时我军战力 +6%/级"
	},
	{
		id: "trade",
		name: "交易",
		attr: "int",
		party: true,
		desc: "买卖价格更优惠"
	},
	{
		id: "surgery",
		name: "医术",
		attr: "int",
		party: true,
		desc: "阵亡变为负伤的几率提高，伤兵恢复更快"
	},
	{
		id: "spotting",
		name: "侦察",
		attr: "int",
		party: true,
		desc: "大地图视野 +10%/级"
	},
	{
		id: "pathfinding",
		name: "寻路",
		attr: "int",
		party: true,
		desc: "大地图行军速度 +3%/级"
	},
	{
		id: "leadership",
		name: "统御",
		attr: "cha",
		party: false,
		desc: "部队上限 +5/级，士气提升，军饷降低"
	},
	{
		id: "prisoner",
		name: "管束",
		attr: "cha",
		party: true,
		desc: "俘虏上限 +5/级"
	}
];
var SKILL = {};
for (const s of SKILLS) SKILL[s.id] = s;
function newHero(name) {
	return {
		name,
		background: "",
		level: 1,
		xp: 0,
		attrs: {
			str: 5,
			agi: 5,
			int: 5,
			cha: 5
		},
		skills: {
			ironflesh: 0,
			powerstrike: 0,
			archery: 0,
			riding: 0,
			leadership: 0,
			training: 0,
			tactics: 0,
			trade: 0,
			surgery: 0,
			spotting: 0,
			pathfinding: 0,
			prisoner: 0
		},
		attrPts: 2,
		skillPts: 3,
		hp: 1,
		equip: {
			melee: "w_chaidao",
			ranged: null,
			armor: "a_cloth",
			helm: "h_cloth",
			horse: null
		},
		inventory: []
	};
}
function heroMaxHp(h) {
	return 50 + h.attrs.str * 3 + h.skills.ironflesh * 6 + h.level;
}
/** 队伍技能：取主角与健康同伴中的最高值 */
function partySkill(s, id) {
	let v = s.hero.skills[id];
	if (SKILL[id].party) for (const c of s.companions) {
		if (c.wounded > 0) continue;
		const cv = COMPANIONS.find((x) => x.id === c.id)?.skills[id] ?? 0;
		if (cv > v) v = cv;
	}
	return v;
}
function partyLimit(s) {
	return 20 + s.hero.skills.leadership * 5 + s.hero.attrs.cha + Math.floor(s.renown / 25);
}
function horseRidingReq(itemId) {
	const t = ITEMS[itemId]?.tier ?? 1;
	return Math.max(0, t - 2);
}
function heroArmor(h) {
	return (h.equip.armor ? ITEMS[h.equip.armor].armor ?? 0 : 0) + (h.equip.helm ? ITEMS[h.equip.helm].armor ?? 0 : 0);
}
//#endregion
//#region src/core/party.ts
function count(stacks) {
	let n = 0;
	for (const s of stacks) n += s.n;
	return n;
}
function healthy(stacks) {
	let n = 0;
	for (const s of stacks) n += s.n - s.w;
	return n;
}
function wounded(stacks) {
	let n = 0;
	for (const s of stacks) n += s.w;
	return n;
}
function addTroops(stacks, id, n, w = 0) {
	if (n <= 0) return;
	const st = stacks.find((s) => s.id === id);
	if (st) {
		st.n += n;
		st.w += w;
	} else stacks.push({
		id,
		n,
		w,
		xp: 0
	});
}
function removeTroops(stacks, id, n, preferWounded = false) {
	const st = stacks.find((s) => s.id === id);
	if (!st) return 0;
	const k = Math.min(n, st.n);
	st.n -= k;
	if (preferWounded) st.w = Math.max(0, st.w - k);
	else st.w = Math.min(st.w, st.n);
	if (st.n <= 0) stacks.splice(stacks.indexOf(st), 1);
	return k;
}
function cleanStacks(stacks) {
	for (let i = stacks.length - 1; i >= 0; i--) {
		const s = stacks[i];
		s.w = Math.max(0, Math.min(s.w, s.n));
		if (s.n <= 0) stacks.splice(i, 1);
	}
}
function strength(stacks, healthyOnly = true) {
	let p = 0;
	for (const s of stacks) {
		const t = TROOPS[s.id];
		if (!t) continue;
		p += troopPower(t) * (healthyOnly ? s.n - s.w : s.n);
	}
	return p;
}
function partyStrength(s, p) {
	let v = strength(p.troops);
	if (p.kind === "player") {
		v += 6 + s.hero.level * .8;
		for (const c of s.companions) if (c.wounded <= 0) v += 6;
	} else if (p.kind === "lord") v += 8;
	return v;
}
function partySize(s, p) {
	let n = count(p.troops);
	if (p.kind === "player") n += 1 + s.companions.length;
	return n;
}
/** 行军速度参数（GM 可在运行时调整）。
*  平地白天：玩家 7~10、AI 5~8；兵越多越慢、骑兵越多越快；地形/夜晚再降，但有底线。
*  金银、货物、火炮一律不影响速度。 */
var SPEED = {
	player: {
		max: 10,
		min: 7,
		sizeDrop: 3,
		sizeFull: 600,
		cav: 1.5,
		floor: 5
	},
	ai: {
		max: 8,
		min: 5,
		sizeDrop: 3,
		sizeFull: 400,
		cav: 1,
		floor: 4
	},
	night: .85,
	wounded: .12,
	pathfinding: .03,
	lowMorale: .9,
	kind: {
		caravan: .9,
		villager: .9,
		bandit: 1.05
	}
};
function mapSpeed(s, p, night) {
	const isP = p.kind === "player";
	const c = isP || p.kind === "hero" ? SPEED.player : SPEED.ai;
	const total = Math.max(1, count(p.troops));
	let mounted = 0;
	for (const st of p.troops) if (TROOPS[st.id]?.mounted) mounted += st.n - st.w;
	let v = c.max - c.sizeDrop * Math.min(1, total / c.sizeFull) + c.cav * (mounted / total);
	v *= 1 - wounded(p.troops) / total * SPEED.wounded;
	if (isP) {
		v *= 1 + partySkill(s, "pathfinding") * SPEED.pathfinding;
		if (s.morale < 20) v *= SPEED.lowMorale;
	} else v *= SPEED.kind[p.kind] ?? 1;
	v = Math.max(c.min, Math.min(c.max, v));
	if (night) v *= SPEED.night;
	v *= TER_SPEED[terAtXY(p.x, p.y)] || .5;
	return Math.max(c.floor, v);
}
function weeklyWages(s, p) {
	let w = 0;
	for (const st of p.troops) w += (TROOPS[st.id]?.wage ?? 2) * st.n;
	return Math.round(w * (1 - s.hero.skills.leadership * .04));
}
/** 每日粮食消耗（单位） */
function dailyFood(s, p) {
	return Math.max(1, Math.ceil(partySize(s, p) / 12));
}
//#endregion
//#region src/core/wall.ts
/** 关隘：existing 表示沿用原有城堡 */
var PASSES = [
	{
		id: "jiayu",
		name: "嘉峪关",
		lon: 98.2,
		desc: "天下第一雄关，扼河西走廊西端。"
	},
	{
		id: "huama",
		name: "花马池",
		lon: 107.3,
		desc: "宁夏东路要隘，套虏入寇必经之地。"
	},
	{
		id: "yulin",
		name: "榆林",
		lon: 109.73,
		existing: true,
		desc: "九边重镇，镇北台雄踞长城之上。"
	},
	{
		id: "piantou",
		name: "偏头关",
		lon: 111.5,
		desc: "外三关之首，黄河在此入塞。"
	},
	{
		id: "shahu",
		name: "杀虎口",
		lon: 112.4,
		desc: "晋北锁钥，西口古道由此出塞。"
	},
	{
		id: "zhangjia",
		name: "张家口",
		lon: 114.88,
		desc: "宣府北门，茶马互市之所。"
	},
	{
		id: "juyong",
		name: "居庸关",
		lon: 116.1,
		desc: "太行八陉之一，京师北门。"
	},
	{
		id: "gubei",
		name: "古北口",
		lon: 117.15,
		desc: "燕山要冲，京师东北屏障。"
	},
	{
		id: "xifeng",
		name: "喜峰口",
		lon: 118.4,
		desc: "滦河谷口，昔年金兵入塞之路。"
	},
	{
		id: "shanhai",
		name: "山海关",
		lon: 119.75,
		existing: true,
		desc: "天下第一关，京师与辽东之咽喉。"
	}
];
var SEG = 64;
var SEGS = [];
var built = false;
/** 在长城折线上取某经度处的点 */
function wallPointAtLon(lon) {
	for (let i = 0; i < GREAT_WALL.length - 1; i++) {
		const [a, b] = [GREAT_WALL[i], GREAT_WALL[i + 1]];
		if ((lon - a[0]) * (lon - b[0]) <= 0) {
			const t = (lon - a[0]) / (b[0] - a[0] || 1);
			return ll(lon, a[1] + (b[1] - a[1]) * t);
		}
	}
	return ll(GREAT_WALL[0][0], GREAT_WALL[0][1]);
}
function buildWall() {
	if (built) return;
	buildGrid();
	built = true;
	const pts = GREAT_WALL.map(([lo, la]) => ll(lo, la));
	let acc = 0, prev = -1;
	const mark = (gx, gy, seg) => {
		if (gx < 0 || gy < 0 || gx >= GW || gy >= GH) return;
		const i = gy * GW + gx;
		if (wallSeg[i] < 0) wallSeg[i] = seg;
	};
	for (let i = 0; i < pts.length - 1; i++) {
		const [x0, y0] = pts[i], [x1, y1] = pts[i + 1];
		const L = Math.hypot(x1 - x0, y1 - y0), n = Math.ceil(L / 2);
		for (let k = 0; k <= n; k++) {
			const t = k / n, x = x0 + (x1 - x0) * t, y = y0 + (y1 - y0) * t;
			const seg = Math.floor((acc + L * t) / SEG);
			while (SEGS.length <= seg) SEGS.push({
				x,
				y,
				nx: -(y1 - y0) / L,
				ny: (x1 - x0) / L,
				gate: -1
			});
			const gx = Math.floor(x / 16), gy = Math.floor(y / 16), ci = gy * GW + gx;
			if (prev >= 0 && ci !== prev) {
				const px = prev % GW, py = prev / GW | 0;
				if (px !== gx && py !== gy) mark(px, gy, seg);
			}
			mark(gx, gy, seg);
			prev = ci;
		}
		acc += L;
	}
	const sums = SEGS.map(() => [
		0,
		0,
		0
	]);
	for (let i = 0; i < GW * GH; i++) if (wallSeg[i] >= 0) {
		const s = sums[wallSeg[i]];
		s[0] += i % GW * 16 + 8;
		s[1] += (i / GW | 0) * 16 + 8;
		s[2]++;
	}
	sums.forEach((s, k) => {
		if (s[2]) {
			SEGS[k].x = s[0] / s[2];
			SEGS[k].y = s[1] / s[2];
		}
	});
	PASSES.forEach((ps, k) => {
		const [px, py] = wallPointAtLon(ps.lon);
		for (let i = 0; i < GW * GH; i++) {
			if (wallSeg[i] < 0) continue;
			const cx = i % GW * 16 + 8, cy = (i / GW | 0) * 16 + 8;
			if (Math.hypot(cx - px, cy - py) < 25.6) {
				gateCell[i] = k;
				SEGS[wallSeg[i]].gate = k;
			}
		}
	});
	const [kx, ky] = ll(114.3, 34.8);
	const start = cellIndex(kx, ky);
	const q = [start];
	regionGrid[start] = 1;
	while (q.length) {
		const c = q.pop(), cx = c % GW, cy = c / GW | 0;
		for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
			const nx = cx + dx, ny = cy + dy;
			if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue;
			const ni = ny * GW + nx;
			if (regionGrid[ni] || wallSeg[ni] >= 0 || TER_SPEED[grid[ni]] <= 0) continue;
			if (dx && dy && (wallSeg[cy * GW + nx] >= 0 || wallSeg[ny * GW + cx] >= 0)) continue;
			regionGrid[ni] = 1;
			q.push(ni);
		}
	}
	for (let i = 0; i < GW * GH; i++) if (!regionGrid[i] && wallSeg[i] < 0 && TER_SPEED[grid[i]] > 0) regionGrid[i] = 2;
	setWallRule(rule);
}
function whoOf(p) {
	return {
		f: p.kind === "player" ? playerSide() ?? "player" : p.faction,
		player: p.kind === "player",
		sneak: (p.kind === "player" || p.kind === "hero" || p.kind === "bandit") && count(p.troops) <= 30,
		army: p.kind === "lord"
	};
}
function passSettlement(k) {
	return S.settlements[PASSES[k]?.id];
}
function gateOpenFor(k, who) {
	const st = passSettlement(k);
	if (!st) return true;
	if (who.player) return !playerHostileToSettlement(st);
	if (who.army) return st.faction === who.f;
	return !factionHostileToSettlement(who.f, st);
}
function isBreached(k) {
	const h = S.wallHp?.[k];
	return h !== void 0 && h < 30;
}
function rule(ci, w) {
	const who = w;
	const sg = wallSeg[ci];
	if (sg < 0) return 1;
	const k = gateCell[ci];
	if (k >= 0) return gateOpenFor(k, who) ? 1 : 0;
	if (isBreached(sg)) return 1;
	return who.sneak ? 2 : 0;
}
function regionAt(x, y) {
	const ci = cellIndex(x, y);
	return ci < 0 ? 0 : regionGrid[ci];
}
/** 势力 f 能否从 a 走到 b（粗略：同侧，或有打开的关隘/缺口） */
function reachableFor(who, ax, ay, bx, by) {
	const ra = regionAt(ax, ay), rb = regionAt(bx, by);
	if (!ra || !rb || ra === rb) return true;
	if (S.wallHp?.some((h) => h < 30)) return true;
	return PASSES.some((_, k) => gateOpenFor(k, who));
}
function ensureWall(s) {
	buildWall();
	if (!s.wallHp || s.wallHp.length !== SEGS.length) s.wallHp = SEGS.map(() => 100);
	s.beacons ||= [];
}
function nearestPassName(x, y) {
	let best = PASSES[0].name, bd = Infinity;
	for (const ps of PASSES) {
		const [px, py] = wallPointAtLon(ps.lon);
		const d = Math.hypot(px - x, py - y);
		if (d < bd) {
			bd = d;
			best = ps.name;
		}
	}
	return best;
}
/** 拥有这段城墙的势力（最近关隘的主人） */
function wallOwnerAt(x, y) {
	let best, bd = Infinity;
	PASSES.forEach((ps, k) => {
		const st = passSettlement(k);
		if (!st) return;
		const [px, py] = wallPointAtLon(ps.lon);
		const d = Math.hypot(px - x, py - y);
		if (d < bd) {
			bd = d;
			best = st;
		}
	});
	return best?.faction ?? "ming";
}
function breachWall(seg, by) {
	if (!S.wallHp || S.wallHp[seg] === void 0 || isBreached(seg) || SEGS[seg].gate >= 0) return;
	S.wallHp[seg] = 0;
	const sg = SEGS[seg];
	lightBeacon(sg.x, sg.y, 72);
	log(`${by ? by.lordId ? `${FACTION[by.faction]?.name ?? ""}${lordName(by.lordId)}` : by.name : "敌军"}在${nearestPassName(sg.x, sg.y)}附近拆毁边墙，打开了一道缺口！`, "war");
}
function lightBeacon(x, y, hours = 48) {
	S.beacons ||= [];
	if (S.beacons.some((b) => Math.hypot(b.x - x, b.y - y) < 80 && b.until > S.time)) return;
	S.beacons.push({
		x,
		y,
		until: S.time + hours
	});
}
/** 找一段可拆的城墙（离关隘较远、离 p 最近），返回段号与本侧的站位 */
function pickBreachSeg(p) {
	const myReg = regionAt(p.x, p.y);
	let best = -1, bd = Infinity;
	SEGS.forEach((sg, k) => {
		if (sg.gate >= 0 || isBreached(k)) return;
		const d = Math.hypot(sg.x - p.x, sg.y - p.y);
		if (d < bd) {
			bd = d;
			best = k;
		}
	});
	if (best < 0 || bd > 900) return null;
	const sg = SEGS[best];
	for (const side of [1, -1]) {
		const [x, y] = nearestPassable(sg.x + sg.nx * 26 * side, sg.y + sg.ny * 26 * side);
		if (regionAt(x, y) === myReg) return {
			seg: best,
			x,
			y
		};
	}
	return null;
}
/** 每小时：烽火（敌军入塞）、清理过期烽火 */
function wallHourly() {
	if (!S.beacons) return;
	S.beacons = S.beacons.filter((b) => b.until > S.time);
	for (const p of S.parties) {
		if (p.inside) continue;
		const r = regionAt(p.x, p.y);
		if (!r) continue;
		const prev = p.reg;
		p.reg = r;
		if (prev === 2 && r === 1 && p.kind === "lord") {
			const owner = wallOwnerAt(p.x, p.y);
			if (owner === p.faction) continue;
			lightBeacon(p.x, p.y - 30, 48);
			const pp = player();
			const near = Math.hypot(pp.x - p.x, pp.y - p.y) < 900;
			const side = playerSide();
			if (near || side === owner || owner === "player") {
				const gate = settlementList().find((s) => s.isPass && Math.hypot(s.x - p.x, s.y - p.y) < 45);
				const how = gate ? `经由${gate.name}` : `从${nearestPassName(p.x, p.y)}附近的边墙破口`;
				log(`烽火台狼烟四起——${FACTION[p.faction]?.name ?? ""}${lordName(p.lordId ?? null)}部${count(p.troops)}人${how}入塞了！`, "bad");
			}
		}
	}
}
/** 每日：边墙自行修缮（无敌军在旁时，十日修好一段） */
function wallDaily() {
	if (!S.wallHp) return;
	S.wallHp.forEach((h, k) => {
		if (h > 0 && h >= 100) return;
		const sg = SEGS[k];
		const owner = wallOwnerAt(sg.x, sg.y);
		if (!S.parties.some((p) => !p.inside && p.kind === "lord" && Math.hypot(p.x - sg.x, p.y - sg.y) < 160 && p.faction !== owner)) S.wallHp[k] = Math.min(100, h + 10);
	});
}
/** 关隘关税：玩家拥有的关隘每周收入 */
function passToll() {
	const out = [];
	PASSES.forEach((ps, k) => {
		const st = passSettlement(k);
		if (st && st.owner === "player") out.push({
			name: ps.name,
			gold: 160 + Math.round(st.prosperity * 2)
		});
	});
	return out;
}
//#endregion
//#region src/core/god.ts
var GOD_DEFAULT = {
	on: true,
	invincible: true,
	oneHit: false,
	mapSpeed: 8,
	battleSpeed: 1.6,
	aura: true,
	reveal: false,
	hidden: false,
	any: true,
	eye: true
};
({ ...GOD_DEFAULT });
/** 规范化（服务器收到 GM 修改时用） */
function normGod(g) {
	const n = {
		...GOD_DEFAULT,
		...g
	};
	n.mapSpeed = Math.max(1, Math.min(50, Number(n.mapSpeed) || 1));
	n.battleSpeed = Math.max(1, Math.min(4, Number(n.battleSpeed) || 1));
	for (const k of [
		"on",
		"invincible",
		"oneHit",
		"aura",
		"reveal",
		"hidden",
		"any",
		"eye"
	]) n[k] = !!n[k];
	return n;
}
//#endregion
//#region src/core/quests.ts
function addRel(q, d) {
	const st = S.settlements[q.giver];
	if (st) st.relation = Math.max(-100, Math.min(100, st.relation + d));
	changePlayerRel(q.giverFaction, Math.round(d / 2));
}
function finishQuest(q, success) {
	S.quests = S.quests.filter((x) => x.id !== q.id);
	if (success) {
		player().gold += q.reward;
		S.renown += 5;
		S.honor += 1;
		addRel(q, 6);
		log(`任务完成：${q.title}，获得 ${q.reward} 两银子。`, "quest");
	} else {
		addRel(q, -5);
		log(`任务失败：${q.title}`, "bad");
	}
}
function dailyQuests() {
	for (const q of [...S.quests]) if (S.time > q.deadline) {
		if (q.type === "bandit" && typeof q.target === "number") {
			const p = partyById(q.target);
			if (p) {
				p.questId = void 0;
				removeParty(p);
			}
		}
		finishQuest(q, false);
	}
}
//#endregion
//#region src/core/combat.ts
function pickVictim(stacks, down) {
	const opts = [];
	for (const s of stacks) {
		const left = s.n - s.w - (down[s.id] || 0);
		if (left > 0) opts.push([s.id, left / Math.sqrt(TROOPS[s.id]?.tier ?? 1)]);
	}
	return opts.length ? weighted(opts) : null;
}
function remainingPower(stacks, down) {
	let p = 0;
	for (const s of stacks) {
		const t = TROOPS[s.id];
		if (!t) continue;
		p += troopPower(t) * Math.max(0, s.n - s.w - (down[s.id] || 0));
	}
	return p;
}
/** 通用自动结算。bonusA/B 为额外战力（主角、同伴、守城加成等） */
function autoResolve(a, b, multA = 1, multB = 1, extraA = 0, extraB = 0) {
	const aDown = {}, bDown = {};
	const a0 = strength(a) * multA + extraA, b0 = strength(b) * multB + extraB;
	for (let round = 0; round < 60; round++) {
		const pa = remainingPower(a, aDown) * multA + extraA * (round < 30 ? 1 : .5);
		const pb = remainingPower(b, bDown) * multB + extraB * (round < 30 ? 1 : .5);
		const na = healthyLeft(a, aDown), nb = healthyLeft(b, bDown);
		if (na <= 0 && extraA <= 0) break;
		if (nb <= 0 && extraB <= 0) break;
		if (na <= 0 && nb <= 0) break;
		if (pa < a0 * .18 && chance(.4)) break;
		if (pb < b0 * .18 && chance(.4)) break;
		const kills = Math.max(1, Math.round((na + nb) * .05));
		for (let k = 0; k < kills; k++) if (Math.random() * (pa + pb) < pa) {
			const v = pickVictim(b, bDown);
			if (v) bDown[v] = (bDown[v] || 0) + 1;
		} else {
			const v = pickVictim(a, aDown);
			if (v) aDown[v] = (aDown[v] || 0) + 1;
		}
	}
	const ra = remainingPower(a, aDown) * multA + extraA * .5, rb = remainingPower(b, bDown) * multB + extraB * .5;
	return {
		aWin: ra / Math.max(1, a0) > rb / Math.max(1, b0) ? ra > 0 : rb <= 0,
		aDown,
		bDown
	};
}
function healthyLeft(stacks, down) {
	let n = 0;
	for (const s of stacks) n += Math.max(0, s.n - s.w - (down[s.id] || 0));
	return n;
}
function setOwner(st, faction, owner) {
	st.faction = faction;
	st.owner = owner;
	st.siege = null;
	for (const vid of st.villages) {
		const v = S.settlements[vid];
		v.faction = faction;
		v.owner = owner;
	}
}
function checkFactionAlive(f) {
	if (f === "player" || !S.alive[f]) return;
	const cf = S.customFactions?.[f];
	const forts = factionSettlements(f).filter((s) => s.kind !== "village").length;
	if (cf) {
		if (forts > 0) {
			if (cf.exileSince != null) {
				delete cf.exileSince;
				delete FACTION[f].exileSince;
				log(`${cf.name}光复城池，重整旗鼓！`, "gold");
			}
		} else {
			if (cf.exileSince == null) {
				cf.exileSince = S.time;
				FACTION[f].exileSince = S.time;
				log(`${cf.name}失去了最后一座城池！${cf.ruler}率残部流亡，誓要光复故土（60 日内须夺回一城，否则国祚断绝）。`, "gold");
			}
			if (S.time - cf.exileSince < 1440) {
				checkVictory();
				return;
			}
		}
	}
	if (forts === 0) {
		S.alive[f] = false;
		log(`${FACTION[f].name}已经覆灭！`, "gold");
		for (const p of [...S.parties]) if (p.faction === f && p.kind !== "player" && p.kind !== "hero") removeParty(p);
		for (const l of Object.values(S.lords)) if (l.faction === f) {
			l.dead = true;
			l.partyId = null;
		}
		S.wars = S.wars.filter((k) => !k.split("|").includes(f));
		if (S.playerFaction === f) {
			S.playerFaction = null;
			log("你效忠的势力已灭亡，你重获自由。", "bad");
		}
		if (S.mercOf === f) S.mercOf = null;
	}
	checkVictory();
}
function checkVictory() {
	const towns = Object.values(S.settlements).filter((s) => s.kind === "town");
	const side = S.playerFaction ?? "player";
	if (!S.won && towns.every((t) => t.faction === side)) {
		S.won = true;
		emit("victory");
	}
}
//#endregion
//#region src/core/strategy.ts
var THEATERS = [
	{
		id: "liao",
		name: "蓟辽",
		anchors: [
			"shanhai",
			"ningyuan",
			"jinzhou",
			"xifeng",
			"gubei",
			"tianjin"
		],
		min: 3
	},
	{
		id: "bian",
		name: "宣大九边",
		anchors: [
			"zhangjia",
			"xuanfu",
			"datong",
			"juyong",
			"shahu",
			"piantou",
			"yulin",
			"huama"
		],
		min: 3
	},
	{
		id: "jing",
		name: "京营",
		anchors: ["beijing"],
		min: 2
	},
	{
		id: "zhong",
		name: "中原",
		anchors: [
			"kaifeng",
			"luoyang",
			"xian",
			"nanyang",
			"tongguan",
			"ruzhou",
			"shangluo",
			"xuzhou",
			"jinan",
			"taiyuan"
		],
		min: 3
	},
	{
		id: "nan",
		name: "湖广川陕",
		anchors: [
			"wuchang",
			"xiangyang",
			"changsha",
			"chengdu",
			"chongqing",
			"kuizhou",
			"hanzhong"
		],
		min: 2
	}
];
Object.fromEntries(THEATERS.map((t) => [t.id, t.name]));
var ZONE_R = 280;
function anchorsOf(t) {
	return t.anchors.map((id) => S.settlements[id]).filter(Boolean);
}
/** 战区内友方锚点（无则退回全部锚点） */
function homeAnchors(t, f = "ming") {
	const a = anchorsOf(t);
	const own = a.filter((s) => s.faction === f);
	return own.length ? own : a;
}
function inTheater(t, x, y, r = ZONE_R) {
	return anchorsOf(t).some((s) => Math.hypot(s.x - x, s.y - y) < r);
}
function theaterOf(id) {
	return THEATERS.find((t) => t.id === id);
}
function theaterCenter(t) {
	const a = homeAnchors(t);
	if (!a.length) return [0, 0];
	return [a.reduce((s, x) => s + x.x, 0) / a.length, a.reduce((s, x) => s + x.y, 0) / a.length];
}
var mingLordParties = () => S.parties.filter((p) => p.kind === "lord" && p.faction === "ming" && p.lordId && S.lords[p.lordId] && !S.lords[p.lordId].dead);
var isPlayerFollower = (p) => p.ai.mode === "follow" && p.ai.target === player().id;
/** 各战区的威胁值 */
function theaterThreat(t) {
	let th = 0;
	const anchors = anchorsOf(t);
	for (const p of S.parties) {
		if (p.kind !== "lord" && p.kind !== "bandit") continue;
		if (p.faction === "ming" || !(p.kind === "bandit" || atWar("ming", p.faction))) continue;
		if (!anchors.some((s) => Math.hypot(s.x - p.x, s.y - p.y) < 360)) continue;
		th += partyStrength(S, p) * (p.kind === "bandit" ? .25 : 1);
	}
	for (const s of anchors) {
		if (s.faction !== "ming" && s.faction !== "player" && atWar("ming", s.faction)) th += 250 + count(s.garrison) * 2;
		if (s.faction === "ming" && s.siege) th += 900;
	}
	for (const b of S.beacons ?? []) if (b.until > S.time && anchors.some((s) => Math.hypot(s.x - b.x, s.y - b.y) < 400)) th += 600;
	return th;
}
/** 兵部：按威胁重新分派各镇兵马 */
function mingCourt() {
	if (!S.alive.ming) return;
	const ps = mingLordParties().filter((p) => !isPlayerFollower(p));
	if (!ps.length) return;
	for (const p of ps) {
		const l = S.lords[p.lordId];
		if (l.theater && theaterOf(l.theater)) continue;
		let best = THEATERS[0], bd = Infinity;
		for (const t of THEATERS) for (const a of anchorsOf(t)) {
			const d = Math.hypot(a.x - p.x, a.y - p.y);
			if (d < bd) {
				bd = d;
				best = t;
			}
		}
		l.theater = best.id;
	}
	const threat = {};
	let total = 0;
	for (const t of THEATERS) {
		threat[t.id] = theaterThreat(t) + 60;
		total += threat[t.id];
	}
	const n = ps.length, sumMin = THEATERS.reduce((a, t) => a + t.min, 0);
	const spare = Math.max(0, n - sumMin);
	const want = {};
	for (const t of THEATERS) want[t.id] = Math.min(t.min, Math.ceil(n * t.min / sumMin)) + Math.round(spare * threat[t.id] / total);
	const have = {};
	for (const t of THEATERS) have[t.id] = [];
	for (const p of ps) have[S.lords[p.lordId].theater]?.push(p);
	for (let k = 0; k < 3; k++) {
		const deficit = THEATERS.map((t) => ({
			t,
			d: want[t.id] - have[t.id].length
		})).sort((a, b) => b.d - a.d);
		const need = deficit[0], extra = deficit[deficit.length - 1];
		if (need.d < 1 || extra.d > -1) break;
		const [cx, cy] = theaterCenter(need.t);
		const p = have[extra.t.id].filter((p) => p.ai.mode !== "siege" && !(p.ai.mode === "follow" && p.ai.target !== void 0 && partyById(p.ai.target)?.faction === "ming" && isPlayerFollower(partyById(p.ai.target)))).sort((a, b) => Math.hypot(a.x - cx, a.y - cy) - Math.hypot(b.x - cx, b.y - cy))[0];
		if (!p) break;
		const l = S.lords[p.lordId];
		l.theater = need.t.id;
		have[extra.t.id].splice(have[extra.t.id].indexOf(p), 1);
		have[need.t.id].push(p);
		p.ai.mode = "idle";
		p.ai.path = [];
		p.ai.nextThink = S.time;
		p.inside = void 0;
		const north = need.t.id === "liao" || need.t.id === "bian" || need.t.id === "jing";
		const urgent = threat[need.t.id] > 1500;
		const pp = player();
		if (playerSide() === "ming" || Math.hypot(pp.x - p.x, pp.y - p.y) < 600 || urgent) log(north && urgent ? `兵部急檄：${l.title}${l.name}率部星夜北上，驰援${need.t.name}！` : north ? `${l.title}${l.name}奉调移防${need.t.name}。` : `${l.title}${l.name}奉旨赴${need.t.name}剿寇。`, urgent ? "war" : "dim");
	}
}
/** 明军领主在战区之外时，先赶赴战区（供 thinkLord 调用；返回目标点或 null） */
function theaterMarch(p) {
	if (p.faction !== "ming" || !p.lordId) return null;
	const t = theaterOf(S.lords[p.lordId]?.theater);
	if (!t) return null;
	if (inTheater(t, p.x, p.y, 340)) return null;
	const a = homeAnchors(t);
	if (!a.length) return null;
	return a.sort((x, y) => Math.hypot(x.x - p.x, x.y - p.y) - Math.hypot(y.x - p.x, y.y - p.y))[0];
}
/** 战区内可作为目标的点（离战区太远的目标不去） */
function theaterAllows(p, x, y) {
	if (p.faction !== "ming" || !p.lordId) return true;
	const t = theaterOf(S.lords[p.lordId]?.theater);
	if (!t) return true;
	return inTheater(t, x, y, 540);
}
function summon(leader, n, radius = 1100) {
	const reg = regionAt(leader.x, leader.y);
	const cands = S.parties.filter((p) => p !== leader && p.kind === "lord" && p.faction === leader.faction && !p.inside && p.ai.mode !== "follow" && p.ai.mode !== "siege" && healthy(p.troops) > 20 && Math.hypot(p.x - leader.x, p.y - leader.y) < radius && (!reg || regionAt(p.x, p.y) === reg)).sort((a, b) => Math.hypot(a.x - leader.x, a.y - leader.y) - Math.hypot(b.x - leader.x, b.y - leader.y)).slice(0, n);
	for (const p of cands) {
		p.ai.mode = "follow";
		p.ai.target = leader.id;
		p.ai.until = S.time + 336;
		p.ai.path = [];
		p.ai.nextThink = S.time;
	}
	return cands;
}
function strengthOf(f, filter = () => true) {
	let s = 0;
	for (const p of S.parties) if (p.kind === "lord" && p.faction === f && filter(p)) s += partyStrength(S, p);
	return s;
}
function mingNorthStrength() {
	const zones = THEATERS.filter((t) => t.id === "liao" || t.id === "bian" || t.id === "jing");
	return strengthOf("ming", (p) => zones.some((t) => inTheater(t, p.x, p.y, 360)));
}
function qingThink() {
	if (!S.alive.jin || !S.alive.ming) return;
	const f = S.flags ||= {};
	const day = dayOf(S.time);
	if (f.raidPlan) return;
	if (f.raiders || !atWar("jin", "ming") || day < 50) return;
	if (S.time - Number(f.lastRaid ?? -1e9) < 672) return;
	const outside = (p) => regionAt(p.x, p.y) === 2;
	const jinOut = strengthOf("jin", outside);
	const mingN = mingNorthStrength();
	const ratio = jinOut / Math.max(300, mingN);
	if (ratio < .6 || !chance(Math.min(.5, .15 * ratio))) return;
	const lead = S.parties.filter((p) => p.kind === "lord" && p.faction === "jin" && outside(p) && p.ai.mode !== "siege" && healthy(p.troops) > 40).sort((a, b) => partyStrength(S, b) - partyStrength(S, a))[0];
	if (!lead) return;
	const ming = S.parties.filter((p) => p.kind === "lord" && p.faction === "ming");
	const cands = SEGS.map((sg, k) => ({
		sg,
		k
	})).filter(({ sg, k }) => sg.gate < 0 && !isBreached(k) && Math.hypot(sg.x - lead.x, sg.y - lead.y) < 1300);
	if (!cands.length) return;
	let best = cands[0], bs = -Infinity;
	for (const c of cands.length > 10 ? Array.from({ length: 10 }, () => pick(cands)) : cands) {
		const s = Math.min(...ming.map((p) => Math.hypot(p.x - c.sg.x, p.y - c.sg.y)), 2e3) - Math.hypot(c.sg.x - lead.x, c.sg.y - lead.y) * .3;
		if (s > bs) {
			bs = s;
			best = c;
		}
	}
	const sg = best.sg;
	let stand = null;
	for (const side of [1, -1]) {
		const [x, y] = nearestPassable(sg.x + sg.nx * 26 * side, sg.y + sg.ny * 26 * side);
		if (regionAt(x, y) === 2) {
			stand = [x, y];
			break;
		}
	}
	if (!stand) return;
	lead.ai.mode = "breach";
	lead.ai.target = best.k;
	lead.ai.until = void 0;
	lead.ai.tx = stand[0];
	lead.ai.ty = stand[1];
	lead.ai.path = [];
	lead.ai.nextThink = S.time;
	summon(lead, 3, 1400);
	f.raidPlan = JSON.stringify({
		lead: lead.lordId,
		seg: best.k,
		at: S.time
	});
	if (playerSide() === "ming" || chance(.5)) log(`细作来报：关外八旗正在${FACTION.jin.name}${lordName(lead.lordId)}麾下集结，似有入塞之意。`, "warn");
}
function chuangThink() {
	if (!S.alive.chuang) return;
	const f = S.flags ||= {};
	if (f.jinjing || !S.alive.ming) return;
	const bj = S.settlements.beijing;
	if (!bj || bj.faction !== "ming" || bj.siege) return;
	const ch = strengthOf("chuang");
	const mingAll = strengthOf("ming");
	if (!settlementList().filter((s) => s.faction === "chuang" && s.kind !== "village" && Math.hypot(s.x - bj.x, s.y - bj.y) < 1e3).length || ch < mingAll * .75 || dayOf(S.time) < 120 || !chance(.2)) return;
	const lead = S.parties.filter((p) => p.kind === "lord" && p.faction === "chuang" && regionAt(p.x, p.y) === 1).sort((a, b) => partyStrength(S, b) - partyStrength(S, a))[0];
	if (!lead) return;
	lead.ai.mode = "siege";
	lead.ai.target = "beijing";
	lead.ai.path = [];
	lead.ai.nextThink = S.time;
	lead.ai.until = void 0;
	summon(lead, 4, 1400);
	f.jinjing = S.time;
	f.jinjingLead = lead.lordId ?? "";
}
/** 国力：各势力的兵源补充。明廷财政逐年崩坏；八旗兵源稳定；闯营随饥荒壮大 */
function vigor() {
	const y = Math.max(0, S.time / 24 / 36);
	const fam = calYearFamine();
	const V = {
		ming: [140, Math.max(.12, .42 - y * .035)],
		jin: [210, .62],
		chuang: [170, .22 + fam * .45],
		xi: [150, .3 + fam * .15],
		mon: [130, .3]
	};
	for (const p of S.parties) {
		if (p.kind !== "lord" || p.inside) continue;
		const v = V[p.faction];
		if (!v) continue;
		if (count(p.troops) < v[0] && chance(v[1])) for (const t of genTroops(FACTION[p.faction].culture, 3 + Math.floor(Math.random() * 4), p.faction === "jin" ? .55 : .4)) addTroops(p.troops, t.id, t.n);
	}
}
function calYearFamine() {
	const yr = 1635 + Math.floor(dayOf(S.time) / 36);
	return yr >= 1638 && yr <= 1643 ? .8 : yr >= 1636 ? .4 : .2;
}
function strategyDaily() {
	const day = dayOf(S.time);
	vigor();
	if (day % 3 === 1) mingCourt();
	qingThink();
	if (day % 2 === 0) chuangThink();
}
//#endregion
//#region src/core/calendar.ts
var show = (c) => emit("chronicle", c);
var BASE_NAMES = {};
function applyFlags() {
	const f = S.flags ?? {};
	for (const id of [
		"ming",
		"jin",
		"chuang",
		"xi"
	]) {
		const F = FACTION[id];
		if (!F) continue;
		BASE_NAMES[id] ||= {
			name: F.name,
			ruler: F.ruler,
			rulerTitle: F.rulerTitle,
			capital: F.capital
		};
		Object.assign(F, BASE_NAMES[id]);
	}
	if (f.qing) Object.assign(FACTION.jin, {
		name: "大清",
		rulerTitle: "大清皇帝"
	});
	if (f.qingRegent) Object.assign(FACTION.jin, {
		ruler: "多尔衮",
		rulerTitle: "摄政王"
	});
	if (f.dashun) Object.assign(FACTION.chuang, {
		name: "大顺",
		ruler: "李自成",
		rulerTitle: "大顺皇帝"
	});
	if (f.daxi) Object.assign(FACTION.xi, {
		name: "大西",
		ruler: "张献忠",
		rulerTitle: "大西皇帝"
	});
	if (f.mingFell) Object.assign(FACTION.ming, {
		name: "南明",
		ruler: "朱由崧",
		rulerTitle: "弘光帝",
		capital: "nanjing"
	});
}
var flag = (k, v = true) => {
	(S.flags ||= {})[k] = v;
	applyFlags();
};
var st = (id) => S.settlements[id];
var owns = (f, id) => st(id)?.faction === f;
var alive = (f) => !!S.alive[f];
var lordParty = (lid) => {
	const l = S.lords[lid];
	return l?.partyId != null ? S.parties.find((p) => p.id === l.partyId) : void 0;
};
function placeNear(x, y, region, r = 40) {
	for (let k = 0; k < 30; k++) {
		const [px, py] = nearestPassable(x + (Math.random() - .5) * r * 2, y + (Math.random() - .5) * r * 2);
		if (!region || regionAt(px, py) === region) return [px, py];
	}
	return nearestPassable(x, y);
}
/** 召集某势力若干领主于 (x,y)，组成以第一人为帅的军团 */
function muster(f, n, x, y, add, region = 0, prefer = []) {
	const lords = Object.values(S.lords).filter((l) => l.faction === f && !l.dead).sort((a, b) => (prefer.includes(b.id) ? 1 : 0) - (prefer.includes(a.id) ? 1 : 0) || Math.random() - .5).slice(0, n);
	const out = [];
	for (const l of lords) {
		let p = lordParty(l.id);
		if (!p) {
			l.respawnAt = 0;
			spawnLordParty(l);
			p = lordParty(l.id);
		}
		if (!p) continue;
		[p.x, p.y] = placeNear(x, y, region);
		p.inside = void 0;
		p.reg = regionAt(p.x, p.y);
		for (const t of genTroops(FACTION[f].culture, add, .6)) addTroops(p.troops, t.id, t.n);
		p.ai.path = [];
		p.ai.nextThink = S.time;
		out.push(p);
	}
	const lead = out[0];
	for (const p of out.slice(1)) {
		p.ai.mode = "follow";
		p.ai.target = lead.id;
		p.ai.until = S.time + 240;
	}
	return out;
}
function orderSiege(lead, target) {
	if (!lead || !target) return;
	lead.ai.mode = "siege";
	lead.ai.target = target.id;
	lead.ai.path = [];
	lead.ai.nextThink = S.time;
	lead.ai.until = void 0;
}
function orderRaid(lead, nearX, nearY) {
	if (!lead) return;
	const vs = settlementList().filter((v) => v.kind === "village" && v.faction !== lead.faction && regionAt(v.x, v.y) === 1).sort((a, b) => Math.hypot(a.x - nearX, a.y - nearY) - Math.hypot(b.x - nearX, b.y - nearY));
	if (!vs.length) return;
	lead.ai.mode = "raid";
	lead.ai.target = vs[0].id;
	lead.ai.until = void 0;
	lead.ai.path = [];
	lead.ai.nextThink = S.time;
}
function defect(lid, to) {
	const l = S.lords[lid];
	if (!l || l.dead || l.faction === to) return false;
	const from = l.faction;
	l.faction = to;
	const p = lordParty(lid);
	if (p) {
		p.faction = to;
		p.ai.mode = "idle";
		p.ai.target = void 0;
	}
	const keepers = Object.values(S.lords).filter((o) => o.faction === from && !o.dead && o.id !== lid);
	for (const s of settlementList()) if (s.owner === lid) {
		if (regionAt(s.x, s.y) === 2 && !s.isPass) setOwner(s, to, lid);
		else {
			const k = keepers.sort((a, b) => settlementList().filter((x) => x.owner === a.id).length - settlementList().filter((x) => x.owner === b.id).length)[0];
			s.owner = k ? k.id : null;
		}
	}
	checkFactionAlive(from);
	return true;
}
var zhongStr = () => strengthOf("ming", (p) => inTheater(THEATERS[3], p.x, p.y, 380));
var EVENTS = [
	{
		id: "fengyang",
		name: "凤阳之变",
		when: () => alive("chuang") || alive("xi"),
		run: () => {
			const f = alive("chuang") ? "chuang" : "xi";
			const xz = st("xuzhou");
			if (xz) orderRaid(muster(f, 2, xz.x - 60, xz.y + 40, 30, 1)[0], xz.x, xz.y);
			show({
				title: `凤阳之变`,
				text: "荥阳大会之后，十三家七十二营流寇分兵东进，一把火烧了凤阳皇陵，享殿松柏尽成焦土。\n\n消息传到京师，崇祯帝素服避殿，哭告太庙。中原各路义军声势大振。",
				x: xz?.x,
				y: xz?.y,
				big: true
			});
		}
	},
	{
		id: "qing",
		name: "大清建号",
		when: () => alive("jin") && dayOf(S.time) >= 30 && (dayOf(S.time) >= 45 || settlementList().filter((s) => s.faction === "jin" && s.kind !== "village").length >= 9),
		run: () => {
			flag("qing");
			show({
				title: `大清建号`,
				text: "盛京城中，皇太极受满、蒙、汉诸臣劝进，即皇帝位，改国号为“大清”，改元崇德。\n\n后金自此称大清，与大明分庭抗礼。",
				x: st("shengjing")?.x,
				y: st("shengjing")?.y,
				big: true
			});
		}
	},
	{
		id: "gaoyingxiang",
		name: "闯王被擒",
		when: () => alive("chuang") && dayOf(S.time) >= 30 && strengthOf("chuang") < zhongStr() * .6 && chance(.12),
		run: () => {
			for (const p of S.parties) if (p.faction === "chuang" && p.kind === "lord") for (const s of [...p.troops]) removeTroops(p.troops, s.id, Math.floor(s.n * .3));
			show({
				title: `闯王被擒`,
				text: "官军设伏大破义军，闯王高迎祥被擒，解京凌迟。\n\n部众推举李自成继为“闯王”。闯军元气大伤，暂时退入山中。"
			});
		}
	},
	{
		id: "gucheng",
		name: "谷城受抚",
		when: () => alive("xi") && atWar("xi", "ming") && dayOf(S.time) >= 40 && settlementList().filter((s) => s.faction === "xi" && s.kind !== "village").length <= 2,
		run: () => {
			setWar("xi", "ming", false);
			S.truceUntil["ming|xi"] = S.time + 384;
			flag("guchengAt", S.time);
			show({
				title: `谷城受抚`,
				text: "张献忠屡战不利，于谷城诈降，受朝廷招抚。西营屯兵谷城，表面归顺，暗中积草屯粮。"
			});
		}
	},
	{
		id: "xifan",
		name: "谷城复叛",
		when: () => !!S.flags?.guchengAt && S.time > Number(S.flags.guchengAt) + 384 && alive("xi"),
		run: () => {
			setWar("xi", "ming", true);
			const g = st("xiangyang") ?? st("wuchang");
			const lead = S.parties.filter((p) => p.kind === "lord" && p.faction === "xi").sort((a, b) => count(b.troops) - count(a.troops))[0];
			if (lead && g && g.faction !== "xi") {
				orderSiege(lead, g);
				summon(lead, 3);
			}
			show({
				title: `谷城复叛`,
				text: "张献忠杀谷城知县，焚其城垣，复举义旗。罗汝才等九营响应，楚地大乱。",
				x: g?.x,
				y: g?.y
			});
		}
	},
	{
		id: "chuangwang",
		name: "迎闯王",
		when: () => dayOf(S.time) >= 100 && (famine() > .5 || zhongStr() < 700) && chance(.08),
		run: () => {
			let base = st("shangluo") ?? st("nanyang");
			if (!alive("chuang") && base) {
				S.alive.chuang = true;
				for (const l of Object.values(S.lords)) if (l.faction === "chuang") {
					l.dead = false;
					l.respawnAt = 0;
					l.partyId = null;
				}
				if (base.faction !== "player" && base.owner !== "player") {
					setOwner(base, "chuang", null);
					base.garrison = genTroops("chuang", 60, .5);
				}
				for (const f of ["ming", "mon"]) if (S.alive[f]) setWar("chuang", f, true);
				for (const l of Object.values(S.lords)) if (l.faction === "chuang") spawnLordParty(l);
			}
			if (!alive("chuang")) return false;
			for (const p of S.parties) if (p.kind === "lord" && p.faction === "chuang") for (const t of genTroops("chuang", 70, .4)) addTroops(p.troops, t.id, t.n);
			base = settlementList().find((s) => s.faction === "chuang" && s.kind !== "village") ?? base;
			flag("chuangRise");
			show({
				title: `迎闯王，不纳粮`,
				text: `${zhongStr() < 700 ? "官军精锐尽被抽调北上，中原空虚。" : ""}中原连年大旱，赤地千里。李自成率十八骑出商洛山，饥民从之如流。\n\n李岩编歌谣传唱四方：“迎闯王，不纳粮！”旬日之间，闯军复聚至数十万。`,
				x: base?.x,
				y: base?.y,
				big: true
			});
		}
	},
	{
		id: "luoyang",
		name: "洛阳陷落",
		when: () => owns("chuang", "luoyang") && !!S.flags?.lyMing,
		run: () => {
			const l = st("luoyang");
			l.prosperity = Math.max(10, l.prosperity - 20);
			show({
				title: `洛阳陷落`,
				text: "闯军攻破洛阳，福王朱常洵被杀。李自成开福王府仓廪赈济饥民，四方震动。",
				x: l.x,
				y: l.y,
				big: true
			});
		}
	},
	{
		id: "songjin1",
		name: "松锦大战",
		when: () => alive("jin") && atWar("jin", "ming") && owns("ming", "jinzhou") && dayOf(S.time) >= 60 && !S.flags?.raidPlan && !S.flags?.raiders && strengthOf("jin", (p) => regionAt(p.x, p.y) === 2) > strengthOf("ming", (p) => inTheater(THEATERS[0], p.x, p.y)) * 1.1 && chance(.1),
		run: () => {
			const j = st("jinzhou");
			const lead = S.parties.filter((p) => p.kind === "lord" && p.faction === "jin" && regionAt(p.x, p.y) === 2).sort((a, b) => count(b.troops) - count(a.troops))[0];
			if (!lead) return false;
			orderSiege(lead, j);
			summon(lead, 4, 1500);
			flag("songjinAt", S.time);
			show({
				title: `松锦大战`,
				text: `${FACTION.jin.name}${lordName(lead.lordId)}尽起八旗，合围锦州，祖大寿困守孤城。兵部急调蓟辽各镇出关驰援。\n\n大明与${FACTION.jin.name}的国运之战，就此拉开序幕。`,
				x: j.x,
				y: j.y,
				big: true
			});
		}
	},
	{
		id: "songjin2",
		name: "松锦终局",
		when: () => !!S.flags?.songjinAt && (owns("jin", "jinzhou") || S.time - Number(S.flags.songjinAt) > 480),
		run: () => {
			if (owns("jin", "jinzhou")) {
				const a = chance(.7) && defect("ming_lord2", "jin");
				show({
					title: `锦州陷落`,
					text: `锦州城破，${defect("ming_lord6", "jin") ? "祖大寿开城投降" : "守军死战殆尽"}；${a ? "洪承畴兵败被俘，绝食数日后终降" : "洪承畴收拾残兵退守宁远"}。\n\n关外大明城池岌岌可危，山海关成为京师最后的屏障。`,
					big: true
				});
			} else {
				show({
					title: `锦州解围`,
					text: "锦州城下，明军坚守不退，八旗久攻无功，只得退兵。此番松锦之战，大明挡住了清兵——史书由此改写。",
					big: true
				});
				if (playerSide() === "ming") changePlayerRel("ming", 3);
			}
		}
	},
	{
		id: "huangtaiji",
		name: "皇太极猝死",
		when: () => alive("jin") && dayOf(S.time) >= 250 && chance(1 / 30),
		run: () => {
			flag("qingRegent");
			if (atWar("jin", "ming")) {
				setWar("jin", "ming", false);
				S.truceUntil["jin|ming"] = S.time + 144;
			}
			show({
				title: `皇太极猝死`,
				text: "皇太极于盛京清宁宫无疾而终。诸王争立，最终议定由六岁的福临继位，睿亲王多尔衮与郑亲王济尔哈朗辅政。\n\n大清暂息兵戈。"
			});
		}
	},
	{
		id: "dashun",
		name: "大顺建国",
		when: () => alive("chuang") && dayOf(S.time) >= 180 && (owns("chuang", "xian") || settlementList().filter((s) => s.faction === "chuang" && s.kind !== "village").length >= 8),
		run: () => {
			flag("dashun");
			show({
				title: `大顺建国`,
				text: "李自成称王，国号“大顺”，改元永昌。闯军将士欢声雷动，誓言东征，直指北京。",
				big: true
			});
		}
	},
	{
		id: "jinjing",
		name: "兵临北京",
		when: () => !!S.flags?.jinjing && owns("ming", "beijing") && (() => {
			const b = st("beijing");
			return !!b.siege || S.parties.some((p) => p.faction === "chuang" && p.kind === "lord" && Math.hypot(p.x - b.x, p.y - b.y) < 260);
		})(),
		run: () => {
			const b = st("beijing");
			const n = S.parties.filter((p) => p.faction === "chuang" && p.kind === "lord" && Math.hypot(p.x - b.x, p.y - b.y) < 400).length;
			show({
				title: `兵临北京`,
				text: `${FACTION.chuang.name}大军${n}路兵临北京城下，彰义门外营帐连绵。京营兵饷久欠，守城者多老弱。\n\n若有忠勇之士入城助守，或可挽狂澜于既倒……`,
				x: b.x,
				y: b.y,
				big: true
			});
		}
	},
	{
		id: "shanhai",
		name: "山海关之变",
		when: () => alive("jin") && !!st("beijing") && !["ming", "player"].includes(st("beijing").faction),
		run: () => shanhaiEvent()
	},
	{
		id: "daxi",
		name: "大西建国",
		when: () => alive("xi") && (owns("xi", "chengdu") || owns("xi", "chongqing")) && dayOf(S.time) >= 150,
		run: () => {
			flag("daxi");
			const cd = st("chengdu");
			show({
				title: `大西建国`,
				text: "张献忠据有巴蜀，于成都称帝，国号“大西”，改元大顺。\n\n巴蜀天府，自此兵连祸结。",
				x: cd?.x,
				y: cd?.y,
				big: true
			});
		}
	}
];
/** 小冰期：崇祯十一年后旱蝗连年 */
function famine() {
	const y = calYear();
	return y >= 1638 && y <= 1643 ? .8 : y >= 1636 ? .4 : .2;
}
/** 山海关之变：吴三桂何去何从（玩家可以干预） */
function shanhaiEvent() {
	flag("mingFell");
	const sh = st("shanhai");
	if (!sh) return true;
	const wu = S.lords["ming_lord7"];
	const marchIn = () => {
		if (alive("chuang") && !atWar("jin", "chuang")) setWar("jin", "chuang", true);
		const lead = S.parties.filter((p) => p.kind === "lord" && p.faction === "jin").sort((a, b) => count(b.troops) - count(a.troops))[0];
		const bj = st("beijing");
		if (lead && bj && bj.faction !== "jin") {
			orderSiege(lead, bj);
			summon(lead, 5, 2e3);
		}
		flag("ruguan");
	};
	if (sh.owner === "player" || sh.faction === "player") {
		show({
			title: `京师陷落`,
			text: `京师已陷，崇祯帝自缢于煤山。天下的目光都落在了你镇守的山海关上——关外八旗虎视眈眈，关内${FACTION[st("beijing").faction]?.name ?? "敌军"}气焰正盛。\n\n明室遗臣于南京拥立福王，是为南明。`,
			x: sh.x,
			y: sh.y,
			big: true
		});
		return;
	}
	if (sh.faction === "jin") {
		marchIn();
		show({
			title: `清军入关`,
			text: `京师已陷，崇祯帝自缢于煤山。山海关早已在${FACTION.jin.name}手中，摄政王多尔衮闻讯，尽起八旗长驱入关，以“为明复仇”为名直扑北京。\n\n明室遗臣于南京拥立福王，是为南明。`,
			x: sh.x,
			y: sh.y,
			big: true
		});
		return;
	}
	if (sh.faction !== "ming" || !wu || wu.dead || wu.faction !== "ming") {
		show({
			title: `甲申之变`,
			text: "京师已陷，崇祯帝自缢于煤山。明室遗臣于南京拥立福王，是为南明。",
			big: true
		});
		return;
	}
	const doDefect = () => {
		defect("ming_lord7", "jin");
		if (sh.faction !== "jin") setOwner(sh, "jin", "ming_lord7");
		setWar("jin", "ming", true);
		marchIn();
		show({
			title: `山海关之战`,
			text: "吴三桂“冲冠一怒为红颜”，开关迎清兵入关。一片石一战，闯军大败。多尔衮率八旗铁骑长驱入关，直取北京。\n\n天下大势，至此一变。",
			x: sh.x,
			y: sh.y,
			big: true
		});
	};
	const stay = () => show({
		title: `吴三桂拒清`,
		text: "吴三桂读罢来信，掷书于地：“我吴家世受国恩，岂能开门揖盗！”山海关依旧紧闭，八旗无隙可乘。\n\n这一年，历史走向了另一条岔路。",
		x: sh.x,
		y: sh.y,
		big: true
	});
	if (playerSide() === "ming" || !playerSide() && (S.playerRel.ming ?? 0) >= 0) {
		const odds = Math.min(.9, .3 + S.renown / 1500 + Math.max(0, wu.relation) / 40);
		show({
			title: `甲申之变`,
			text: `京师已陷，崇祯帝自缢于煤山。明室遗臣于南京拥立福王，是为南明。\n\n山海关总兵吴三桂手握关宁铁骑，进退两难：关外多尔衮许以王爵，关内闯军拘其父、夺其爱妾陈圆圆。有消息说，他已与清人暗通书信……\n\n你若此时修书一封，或许能左右他的抉择（成功率约 ${Math.round(odds * 100)}%）。`,
			x: sh.x,
			y: sh.y,
			big: true,
			choices: [{
				label: "✍ 修书劝说吴三桂",
				run: () => {
					if (chance(odds)) {
						stay();
						wu.relation += 5;
					} else doDefect();
				}
			}, {
				label: "听天由命",
				run: () => {
					if (chance(.25)) stay();
					else doDefect();
				}
			}]
		});
		return;
	}
	if (chance(.75)) doDefect();
	else stay();
}
/** 入塞：清军破墙之后的跟进（由 strategy.ts 发起） */
function raidFollow() {
	const f = S.flags;
	if (!f?.raidPlan) return;
	let plan;
	try {
		plan = JSON.parse(String(f.raidPlan));
	} catch {
		delete f.raidPlan;
		return;
	}
	const lead = lordParty(plan.lead);
	if (!lead || lead.faction !== "jin" || S.time - plan.at > 336) {
		delete f.raidPlan;
		f.lastRaid = S.time;
		return;
	}
	if (!isBreached(plan.seg) && regionAt(lead.x, lead.y) !== 1) return;
	const sg = SEGS[plan.seg];
	const army = [lead, ...S.parties.filter((p) => p.ai.mode === "follow" && p.ai.target === lead.id)];
	for (const p of army) p.ai.until = S.time + 96;
	orderRaid(lead, sg.x, sg.y);
	delete f.raidPlan;
	f.lastRaid = S.time;
	f.raidN = Number(f.raidN ?? 0) + 1;
	f.raidUntil = S.time + 336;
	delete f.raidHomeMsg;
	f.raiders = army.map((p) => p.lordId).filter(Boolean).join(",");
	const where = nearestPassName(sg.x, sg.y);
	const n = Number(f.raidN);
	show({
		title: `${n > 1 ? `清军第${cnNum(n)}次入塞` : "清军入塞"}`,
		text: `${FACTION.jin.name}${lordName(lead.lordId)}率八旗劲旅${army.length}路，避开坚城，在${where}附近拆毁边墙，破口入塞！烽火自长城一路传至京师，畿辅震动。\n\n八旗所过之处，掳掠人口牲畜无数。各镇勤王兵马须速速截击。`,
		x: sg.x,
		y: sg.y,
		big: true
	});
	chronAdd(n > 1 ? `清军第${cnNum(n)}次入塞` : "清军入塞");
}
function chronAdd(name) {
	(S.chronLog ||= []).push({
		n: name,
		at: S.time
	});
	log(`【大事】${name}`, "gold");
}
function calendarInit() {
	S.calendarDone ||= [];
	S.flags ||= {};
	applyFlags();
}
/** 入塞八旗：劫掠十四日后携掳获出塞 */
function manageRaid() {
	const f = S.flags;
	if (!f?.raiders) return;
	const ids = String(f.raiders).split(",");
	const home = settlementList().filter((s) => s.faction === "jin" && s.kind !== "village" && regionAt(s.x, s.y) === 2);
	let active = 0;
	for (const lid of ids) {
		const p = lordParty(lid);
		if (!p || p.faction !== "jin") continue;
		if (regionAt(p.x, p.y) !== 1 && !p.inside) continue;
		if (p.inside && S.settlements[p.inside] && regionAt(S.settlements[p.inside].x, S.settlements[p.inside].y) !== 1) continue;
		active++;
		const ai = p.ai;
		if (S.time < Number(f.raidUntil)) {
			if (ai.mode === "siege" || ai.mode === "idle" || ai.mode === "patrol" || ai.mode === "wander" || ai.mode === "recruit") orderRaid(p, p.x, p.y);
		} else if (ai.mode !== "travel" && ai.mode !== "flee" && home.length) {
			const h = home.sort((a, b) => Math.hypot(a.x - p.x, a.y - p.y) - Math.hypot(b.x - p.x, b.y - p.y))[0];
			p.inside = void 0;
			ai.mode = "travel";
			ai.target = h.id;
			ai.path = [];
			ai.until = void 0;
			ai.nextThink = S.time;
		}
	}
	if (!active || S.time > Number(f.raidUntil) + 480) {
		delete f.raiders;
		delete f.raidUntil;
	} else if (S.time >= Number(f.raidUntil) && !f.raidHomeMsg) {
		f.raidHomeMsg = true;
		log(`${FACTION.jin.name}入塞大军满载掳获，开始北返出塞。`, "war");
	}
}
function calendarDaily() {
	if (owns("ming", "luoyang")) (S.flags ||= {}).lyMing = true;
	guardCal(manageRaid);
	guardCal(raidFollow);
	guardCal(strategyDaily);
	const done = S.calendarDone ||= [];
	for (const e of EVENTS) {
		if (done.includes(e.id)) continue;
		if (!e.when()) continue;
		if (e.run() !== false) {
			done.push(e.id);
			chronAdd(e.name);
		}
	}
	if (!S.flags?.mingFell && S.settlements.beijing && S.settlements.beijing.faction !== "ming" && S.settlements.beijing.faction !== "player") {
		flag("mingFell");
		if (!alive("jin")) show({
			title: `甲申之变`,
			text: `北京易手，${FACTION[S.settlements.beijing.faction]?.name ?? "敌军"}入主紫禁城。明室南渡，于南京另立新君，是为南明。`,
			big: true
		});
	}
}
function guardCal(fn) {
	try {
		fn();
	} catch (e) {
		console.error("[calendar]", e);
	}
}
function randomEvents() {
	const pp = player();
	const roll = Math.random();
	if (roll < .1) {
		const v = pick(settlementList().filter((s) => s.kind === "village"));
		const area = settlementList().filter((s) => s.kind === "village" && Math.hypot(s.x - v.x, s.y - v.y) < 220);
		for (const s of area) {
			s.prosperity = Math.max(5, s.prosperity - 15);
			s.recruits = Math.max(0, s.recruits - 2);
		}
		log(`${v.name}一带${chance(.5) ? "大旱" : "飞蝗蔽日"}，${area.length}个村庄颗粒无收，流民四起。`, "bad");
		for (let i = 0; i < 2; i++) spawnBandit();
	} else if (roll < .16) {
		const t = pick(settlementList().filter((s) => s.kind === "town"));
		for (const s of t.garrison) removeTroops(t.garrison, s.id, Math.floor(s.n * .15));
		t.prosperity = Math.max(5, t.prosperity - 10);
		log(`${t.name}爆发大疫，“十室九空”，守军亦多病殁。`, "bad");
	} else if (roll < .22) {
		const v = pick(settlementList().filter((s) => s.kind === "village"));
		v.prosperity = Math.min(100, v.prosperity + 15);
		log(`${v.name}今岁风调雨顺，五谷丰登。`, "good");
	} else if (roll < .27 && S.renown >= 80 && healthy(pp.troops) > 0) {
		const ids = [
			"ming_soldier",
			"ming_archer",
			"ming_spear"
		];
		const n = randInt(3, 6 + Math.floor(S.renown / 150));
		const id = pick(ids);
		show({
			title: "豪杰来投",
			text: `一队${n}名${chance(.5) ? "乡勇" : "败兵"}慕你的威名而来，跪在营门外：“愿随将军杀贼！”`
		});
		addTroops(pp.troops, id, n);
	} else if (roll < .3 && S.flags?.chuangRise && alive("chuang")) {
		for (const p of S.parties) if (p.faction === "chuang" && p.kind === "lord" && chance(.5)) for (const t of genTroops("chuang", randInt(8, 18), .35)) addTroops(p.troops, t.id, t.n);
		log("饥民成群结队投奔闯营，闯军声势日盛。", "war");
	}
}
var REVIVE_TEXT = {
	ming: ["明室宗亲起兵", "大明宗室于{t}登高一呼，旧部云集，复举日月旗号。"],
	jin: ["八旗余部复起", "八旗残部于{t}重整旗鼓，誓要卷土重来。"],
	chuang: ["闯营余部复起", "闯营旧将收拾残兵，于{t}复竖“闯”字大旗，饥民从之。"],
	xi: ["西营余部复起", "西营旧部于{t}啸聚山林，重整旗鼓。"],
	mon: ["察哈尔部复起", "察哈尔诸台吉于{t}会盟，重振黄金家族的旗帜。"]
};
function reviveFactions() {
	S.flags ||= {};
	for (const f of MAJOR_FACTIONS) {
		if (S.alive[f] || f === "player") continue;
		const k = "deadSince_" + f;
		if (S.flags[k] === void 0) {
			S.flags[k] = S.time;
			continue;
		}
		if (S.time - Number(S.flags[k]) < 960 || !chance(.3)) continue;
		const home = TOWN_DEFS.filter((d) => d.faction === f && d.kind !== "village").map((d) => S.settlements[d.id]).filter((s) => s && s.owner !== "player" && s.faction !== "player" && !s.siege);
		if (!home.length) continue;
		home.sort((a, b) => count(a.garrison) - count(b.garrison));
		const t = home[0];
		const old = t.faction;
		S.alive[f] = true;
		delete S.flags[k];
		for (const l of Object.values(S.lords)) if (l.faction === f) {
			l.dead = false;
			l.respawnAt = 0;
			l.partyId = null;
		}
		setOwner(t, f, null);
		t.garrison = genTroops(FACTION[f].culture, 120, .5);
		for (const l of Object.values(S.lords)) if (l.faction === f) {
			spawnLordParty(l);
			const pp = lordParty(l.id);
			if (pp) for (const tt of genTroops(FACTION[f].culture, 40, .5)) addTroops(pp.troops, tt.id, tt.n);
		}
		if (old && old !== f && S.alive[old]) setWar(f, old, true);
		const [title, text] = REVIVE_TEXT[f] ?? ["余部复起", "{t}有人起兵。"];
		show({
			title: `${title}`,
			text: text.replace("{t}", t.name) + `\n\n${FACTION[f].name}重新回到了天下的棋局之中。`,
			x: t.x,
			y: t.y
		});
		checkFactionAlive(old);
		return;
	}
}
//#endregion
//#region src/core/game.ts
var S = null;
function setState(s) {
	S = s;
}
var listeners = {};
function on(ev, fn) {
	(listeners[ev] ||= []).push(fn);
}
function emit(ev, ...args) {
	for (const fn of listeners[ev] || []) fn(...args);
}
function log(msg, cls = "") {
	S.log.push({
		t: S.time,
		msg,
		cls
	});
	if (S.log.length > 300) S.log.splice(0, S.log.length - 300);
	emit("log", msg, cls);
}
function dayOf(t) {
	return Math.floor(t / 24);
}
function cnNum(n) {
	if (n <= 10) return CHINESE_NUM[n];
	if (n < 20) return "十" + CHINESE_NUM[n - 10];
	const t = Math.floor(n / 10), o = n % 10;
	return CHINESE_NUM[t] + "十" + (o ? CHINESE_NUM[o] : "");
}
/** 城防系数：攻方须有守方数倍之力 */
function fortMult(s) {
	if (s.id === "shanhai") return 3;
	if (s.isPass) return 2.4;
	if (s.id === "beijing") return 2.2;
	return s.kind === "town" ? 1.6 : 1.8;
}
/** 城防上限：都城与关隘远比寻常城堡坚固 */
function garrisonCap(s) {
	if (s.kind === "village") return 0;
	if (s.id === "shanhai") return 230;
	if (s.id === "beijing") return 300;
	if (s.id === "nanjing" || Object.values(FACTION).some((f) => f.capital === s.id)) return 220;
	if (s.isPass) return 125;
	return s.kind === "town" ? 130 : 85;
}
function calYear(t = S.time) {
	return 1635 + Math.floor(dayOf(t) / 36);
}
function isNight(t = S.time) {
	const h = t % 24;
	return h < 5 || h >= 20;
}
function atWar(a, b) {
	if (a === b) return false;
	if (a === "bandit" || b === "bandit") return true;
	return S.wars.includes(warKey(a, b));
}
function setWar(a, b, war) {
	const k = warKey(a, b);
	const i = S.wars.indexOf(k);
	if (war && i < 0) S.wars.push(k);
	if (!war && i >= 0) S.wars.splice(i, 1);
}
function playerOwnsLand() {
	return Object.values(S.settlements).some((s) => s.owner === "player");
}
/** 玩家实际所属阵营 */
function playerSide() {
	if (S.playerFaction) return S.playerFaction;
	if (S.mercOf) return S.mercOf;
	if (playerOwnsLand()) return "player";
	return null;
}
function playerHostileTo(f) {
	if (f === "bandit") return true;
	if (f === "none") return false;
	const side = playerSide();
	if (side && f === side) return false;
	if (side && atWar(side, f)) return true;
	if (!side && atWar("player", f)) return true;
	return (S.playerRel[f] ?? 0) <= -10;
}
function hostile(a, b) {
	if (a.kind === "player") return playerHostileTo(b.faction);
	if (b.kind === "player") return playerHostileTo(a.faction);
	return atWar(a.faction, b.faction);
}
function factionHostileToSettlement(f, st) {
	if (st.owner === "player") return f === "player" ? false : (playerSide() ? atWar(playerSide(), f) : atWar("player", f)) || (S.playerRel[f] ?? 0) <= -10;
	return atWar(f, st.faction);
}
function playerHostileToSettlement(st) {
	return st.owner !== "player" && playerHostileTo(st.faction);
}
function changePlayerRel(f, d) {
	if (f === "bandit" || f === "none" || f === "player") return;
	const before = S.playerRel[f] ?? 0;
	S.playerRel[f] = Math.max(-100, Math.min(100, before + d));
	if (before > -10 && S.playerRel[f] <= -10) log(`${FACTION[f].name}已将你视为敌人！`, "bad");
}
function player() {
	return S.parties.find((p) => p.id === S.playerId);
}
function partyById(id) {
	return S.parties.find((p) => p.id === id);
}
function settlementList() {
	return Object.values(S.settlements);
}
function factionSettlements(f) {
	return settlementList().filter((s) => s.faction === f);
}
function lordName(id) {
	if (!id) return "无";
	if (id === "player") return S.hero.name;
	if (id.startsWith("P:")) return id.slice(2);
	if (id.startsWith("ruler_")) {
		const f = FACTION[id.slice(6)];
		return `${f.rulerTitle}${f.ruler}`;
	}
	const l = S.lords[id];
	return l ? l.name : "无";
}
function nearestSettlement(x, y, filter = () => true) {
	let best = null, bd = Infinity;
	for (const s of settlementList()) {
		if (!filter(s)) continue;
		const d = dist$1(x, y, s.x, s.y);
		if (d < bd) {
			bd = d;
			best = s;
		}
	}
	return best;
}
function fiefsOf(owner) {
	return settlementList().filter((s) => s.owner === owner);
}
function genTroops(culture, n, quality) {
	const stacks = [];
	const base = RECRUIT_OF[culture];
	if (!base) return stacks;
	for (let i = 0; i < n; i++) {
		let id = base;
		for (let k = 0; k < 5; k++) {
			const t = TROOPS[id];
			if (!t.upgrades.length || !chance(quality)) break;
			id = pick(t.upgrades);
		}
		addTroops(stacks, id, 1);
	}
	return stacks;
}
function newId() {
	return S.nextId++;
}
function makeParty(kind, name, faction, x, y, troops, extra = {}) {
	const p = {
		id: newId(),
		kind,
		name,
		faction,
		x,
		y,
		troops,
		prisoners: [],
		gold: 0,
		goods: {},
		ai: {
			mode: "idle",
			nextThink: S.time + Math.random() * 2
		},
		...extra
	};
	S.parties.push(p);
	return p;
}
function removeParty(p) {
	const i = S.parties.indexOf(p);
	if (i >= 0) S.parties.splice(i, 1);
	if (p.lordId && S.lords[p.lordId]) {
		const l = S.lords[p.lordId];
		l.partyId = null;
		l.respawnAt = S.time + randRange(48, 120);
	}
	for (const s of settlementList()) if (s.siege && s.siege.by === p.id) s.siege = null;
}
/** 据点所在地域的商品/装备标签 */
function regionTags(st) {
	const lat = toLL(st.x, st.y)[1], lon = toLL(st.x, st.y)[0];
	const c = st.culture === "chuang" ? "ming" : st.culture;
	const t = [c];
	if (c === "ming" || c === "xi") {
		if (lat < 32.5) t.push("south");
		else if (lon < 106.5) t.push("west");
		else t.push("north");
	}
	return t;
}
/** 铁匠铺 / 军需库进货：城镇 45~55 件，城堡 10~14 件；按地域、繁荣度、品质加权，尽量不重样 */
function refreshShop(st) {
	const town = st.kind === "town";
	const rich = st.prosperity;
	const maxTier = town ? rich > 60 ? 5 : 4 : 3;
	const tagsHere = regionTags(st);
	const qW = (q) => q === 0 ? rich < 40 ? 1.1 : .55 : q === 2 ? town ? .5 : .25 : q === 3 ? town && rich > 55 ? .14 : 0 : 1;
	const pool = [];
	for (const it of ITEM_LIST) {
		if (it.tier > maxTier || it.price <= 25) continue;
		const local = (ITEM_TAGS[it.id] ?? []).some((t) => tagsHere.includes(t));
		const foreign = (ITEM_TAGS[it.id] ?? []).length > 0 && !local;
		const w = (6 - it.tier) * (local ? 3 : foreign ? .6 : 1) * qW(it.quality ?? 1);
		if (w > 0) pool.push([it, w]);
	}
	const n = town ? randInt(42, 48) + Math.floor(rich / 12) : randInt(10, 14);
	const out = [];
	const take = (cands) => {
		const free = cands.filter(([i]) => !out.includes(i.id));
		if (!free.length) return;
		out.push(weighted(free).id);
	};
	if (town) for (const slot of [
		"melee",
		"ranged",
		"armor",
		"helm",
		"horse"
	]) for (let k = 0; k < 6; k++) take(pool.filter(([i]) => i.slot === slot));
	while (out.length < n && out.length < pool.length) take(pool);
	st.shop = out;
}
function refreshTavern(st) {
	const used = /* @__PURE__ */ new Set([...S.companions.map((c) => c.id), ...settlementList().map((s) => s.tavern.companion).filter(Boolean)]);
	if (st.tavern.companion) used.delete(st.tavern.companion);
	const free = COMPANIONS.filter((c) => !used.has(c.id));
	st.tavern.companion = free.length && chance(.35) ? pick(free).id : null;
	st.tavern.mercs = chance(.6) ? {
		id: pick(MERCS),
		n: randInt(3, 9)
	} : null;
	st.tavern.refresh = S.time + 24 * randInt(5, 9);
}
var BACKGROUNDS = [
	{
		id: "soldier",
		name: "卫所军户",
		desc: "世袭军户出身，自幼习武。力量+2，铁骨1、强击1、骑术1，带着五名同乡民壮。",
		apply: (s) => {
			const h = s.hero;
			h.attrs.str += 2;
			h.skills.ironflesh = 1;
			h.skills.powerstrike = 1;
			h.skills.riding = 1;
			h.equip.melee = "w_podao";
			h.equip.armor = "a_pao";
			h.equip.helm = "h_iron";
			addTroops(player().troops, "ming_recruit", 5);
			player().gold = 350;
		}
	},
	{
		id: "merchant",
		name: "江南商贾",
		desc: "苏州丝商之子，家道中落。智力+1、魅力+1，交易2、寻路1，盘缠充足，还有一批丝绸。",
		apply: (s) => {
			const h = s.hero;
			h.attrs.int += 1;
			h.attrs.cha += 1;
			h.skills.trade = 2;
			h.skills.pathfinding = 1;
			h.equip.melee = "w_hunting";
			player().gold = 1400;
			player().goods.silk = 4;
			h.equip.horse = "m_pack";
		}
	},
	{
		id: "scholar",
		name: "落第书生",
		desc: "寒窗十年，屡试不第，投笔从戎。智力+2，医术2、战术1、统御1。",
		apply: (s) => {
			const h = s.hero;
			h.attrs.int += 2;
			h.skills.surgery = 2;
			h.skills.tactics = 1;
			h.skills.leadership = 1;
			h.equip.melee = "w_chaidao";
			player().gold = 700;
			addTroops(player().troops, "ming_recruit", 3);
		}
	},
	{
		id: "hunter",
		name: "辽东猎户",
		desc: "在白山黑水间讨生活的猎户。敏捷+2，射术2、骑术2、侦察1，自带角弓与蒙古马。",
		apply: (s) => {
			const h = s.hero;
			h.attrs.agi += 2;
			h.skills.archery = 2;
			h.skills.riding = 2;
			h.skills.spotting = 1;
			h.equip.melee = "w_hunting";
			h.equip.ranged = "r_hornbow";
			h.equip.horse = "m_mongol";
			h.equip.armor = "a_leather";
			player().gold = 300;
		}
	},
	{
		id: "escort",
		name: "江湖镖师",
		desc: "走镖多年的老江湖。力量+1、魅力+1，强击1、铁骨1、统御1、训练1，带着两名镖师兄弟。",
		apply: (s) => {
			const h = s.hero;
			h.attrs.str += 1;
			h.attrs.cha += 1;
			h.skills.powerstrike = 1;
			h.skills.ironflesh = 1;
			h.skills.leadership = 1;
			h.skills.training = 1;
			h.equip.melee = "w_podao";
			h.equip.armor = "a_leather";
			addTroops(player().troops, "merc_guard", 2);
			player().gold = 500;
		}
	}
];
function placeVillage(px, py, taken, idx) {
	for (let k = 0; k < 40; k++) {
		const a = idx * 2.4 + k * .7 + Math.random() * .4;
		const r = 42 + Math.random() * 40 + k;
		const x = px + Math.cos(a) * r, y = py + Math.sin(a) * r;
		if (!passable(x, y)) continue;
		if (taken.some((t) => dist$1(t.x, t.y, x, y) < 36)) continue;
		return [x, y];
	}
	return null;
}
function stockFor(st) {
	const stock = {};
	for (const g of GOODS) {
		if (st.kind === "village" && !st.produce.includes(g.id) && g.id !== "grain") continue;
		stock[g.id] = targetStock(st, g.id);
	}
	return stock;
}
function targetStock(st, g) {
	const pf = .5 + st.prosperity / 100;
	if (st.kind === "village") return Math.round((st.produce.includes(g) ? 25 : 10) * pf);
	if (st.produce.includes(g)) return Math.round(60 * pf);
	if (st.demand.includes(g)) return Math.round(10 * pf);
	return Math.round(28 * pf);
}
function newGame(heroName, bgId) {
	buildGrid();
	const s = {
		version: 1,
		seed: Date.now() % 1e5,
		time: 8,
		hero: newHero(heroName),
		playerId: 0,
		parties: [],
		settlements: {},
		lords: {},
		wars: [],
		truceUntil: {},
		alive: {},
		playerFaction: null,
		mercOf: null,
		mercUntil: 0,
		ownFactionName: `${heroName}军`,
		playerRel: {},
		renown: 0,
		honor: 0,
		morale: 70,
		companions: [],
		quests: [],
		log: [],
		nextId: 1,
		stats: {
			kills: 0,
			won: 0,
			lost: 0,
			days: 0
		},
		lastDay: 0,
		speed: 1
	};
	setState(s);
	for (const f of MAJOR_FACTIONS) {
		s.alive[f] = true;
		s.playerRel[f] = 0;
	}
	for (const [a, b] of INITIAL_WARS) setWar(a, b, true);
	const taken = [];
	for (const d of TOWN_DEFS) {
		let [x, y] = ll(d.lon, d.lat);
		[x, y] = nearestPassable(x, y);
		const st = {
			id: d.id,
			name: d.name,
			kind: d.kind,
			faction: d.faction,
			owner: null,
			x,
			y,
			villages: [],
			garrison: [],
			prosperity: randInt(40, 70),
			stock: {},
			produce: d.produce ?? [],
			demand: d.demand ?? [],
			shop: [],
			recruits: 0,
			relation: 0,
			lootedUntil: 0,
			siege: null,
			tavern: {
				companion: null,
				mercs: null,
				refresh: 0
			},
			culture: FACTION[d.faction].culture
		};
		s.settlements[d.id] = st;
		taken.push(st);
	}
	for (const st of Object.values(s.settlements)) {
		if (st.kind !== "town") continue;
		for (const tg of regionTags(st)) {
			const R = REGION_GOODS[tg];
			if (!R) continue;
			for (const g of shuffle([...R.produce]).slice(0, randInt(1, 2))) if (!st.produce.includes(g) && !st.demand.includes(g)) st.produce.push(g);
			for (const g of shuffle([...R.demand]).slice(0, randInt(1, 2))) if (!st.produce.includes(g) && !st.demand.includes(g)) st.demand.push(g);
		}
	}
	const names = shuffle([...VILLAGE_NAMES]);
	const cultNames = {
		jin: shuffle([...JIN_VILLAGE_NAMES]),
		mon: shuffle([...MON_VILLAGE_NAMES])
	};
	let vi = 0, hi = 0;
	for (const d of TOWN_DEFS) {
		const parent = s.settlements[d.id];
		const nv = d.kind === "town" ? 2 : 1;
		for (let k = 0; k < nv; k++) {
			const pos = placeVillage(parent.x, parent.y, taken, vi);
			if (!pos) continue;
			const id = `v${vi}`;
			const pool = cultNames[FACTION[d.faction].culture];
			const name = pool?.length ? pool.shift() : names[hi % names.length] + (hi++ >= names.length ? "二" : "");
			vi++;
			const prod = shuffle([...VILLAGE_PRODUCE[FACTION[d.faction].culture] ?? ["grain"]]).slice(0, randInt(2, 3));
			const v = {
				id,
				name,
				kind: "village",
				faction: d.faction,
				owner: null,
				x: pos[0],
				y: pos[1],
				parent: d.id,
				villages: [],
				garrison: [],
				prosperity: randInt(35, 70),
				stock: {},
				produce: prod,
				demand: [],
				shop: [],
				recruits: randInt(3, 8),
				relation: randInt(-5, 10),
				lootedUntil: 0,
				siege: null,
				tavern: {
					companion: null,
					mercs: null,
					refresh: 0
				},
				culture: FACTION[d.faction].culture
			};
			s.settlements[id] = v;
			parent.villages.push(id);
			taken.push(v);
		}
	}
	for (const c of CAMP_DEFS) {
		let [x, y] = nearestPassable(...ll(c.lon, c.lat));
		if (taken.some((t) => dist$1(t.x, t.y, x, y) < 36)) {
			const p2 = placeVillage(x, y, taken, vi);
			if (p2) [x, y] = p2;
		}
		let parent = null, bd = Infinity;
		for (const o of Object.values(s.settlements)) if (o.kind !== "village" && o.faction === c.faction) {
			const dd = dist$1(o.x, o.y, x, y);
			if (dd < bd) {
				bd = dd;
				parent = o;
			}
		}
		if (!parent) continue;
		const v = {
			id: c.id,
			name: c.name,
			kind: "village",
			camp: true,
			faction: c.faction,
			owner: null,
			x,
			y,
			parent: parent.id,
			villages: [],
			garrison: [],
			prosperity: randInt(30, 60),
			stock: {},
			produce: shuffle([
				"meat",
				"fur",
				"cheese",
				"kumis",
				"horse_t",
				"leather"
			]).slice(0, 3),
			demand: [],
			shop: [],
			recruits: randInt(4, 9),
			relation: randInt(-5, 10),
			lootedUntil: 0,
			siege: null,
			tavern: {
				companion: null,
				mercs: null,
				refresh: 0
			},
			culture: "mon"
		};
		s.settlements[c.id] = v;
		parent.villages.push(c.id);
		taken.push(v);
	}
	for (const st of Object.values(s.settlements)) {
		st.stock = stockFor(st);
		if (st.kind !== "village") {
			const n = st.kind === "town" ? randInt(70, 110) : randInt(45, 70);
			st.garrison = genTroops(st.culture, n, .55);
			refreshShop(st);
		}
	}
	const start = s.settlements["kaifeng"];
	const pp = makeParty("player", heroName, "player", start.x + 14, start.y + 10, []);
	s.playerId = pp.id;
	pp.goods.grain = 6;
	pp.goods.meat = 2;
	for (const st of Object.values(s.settlements)) if (st.kind === "town") refreshTavern(st);
	for (const f of MAJOR_FACTIONS) {
		const lords = LORD_DEFS.filter((l) => l.faction === f);
		for (const ld of lords) s.lords[ld.id] = {
			id: ld.id,
			name: ld.name,
			faction: f,
			title: ld.title,
			trait: ld.trait,
			relation: randInt(-3, 5),
			partyId: null,
			respawnAt: 0
		};
		const fiefs = Object.values(s.settlements).filter((x) => x.faction === f && x.kind !== "village");
		const cap = FACTION[f].capital;
		let li = 0;
		for (const st of fiefs) {
			if (st.id === cap) st.owner = `ruler_${f}`;
			else {
				st.owner = lords[li % lords.length].id;
				li++;
			}
			for (const vid of st.villages) s.settlements[vid].owner = st.owner;
		}
		for (const ld of lords) spawnLordParty(s.lords[ld.id], true);
	}
	for (let i = 0; i < 26; i++) spawnBandit();
	for (let i = 0; i < 10; i++) spawnCaravan();
	ensureWorld(s);
	BACKGROUNDS.find((b) => b.id === bgId)?.apply(s);
	s.hero.background = bgId;
	log(`崇祯八年正月，天下大乱。${heroName}来到开封城外，决心在这乱世中闯出一番天地。`, "gold");
	log("提示：点击地图移动，点击城镇进入；按空格扎营等待，鼠标滚轮缩放。", "hint");
	return s;
}
function lordHome(l) {
	const own = fiefsOf(l.id).filter((x) => x.kind !== "village");
	if (own.length) return pick(own);
	const cap = S.settlements[FACTION[l.faction].capital];
	if (cap && cap.faction === l.faction) return cap;
	const fs = factionSettlements(l.faction).filter((x) => x.kind !== "village");
	return fs.length ? pick(fs) : null;
}
function spawnLordParty(l, initial = false) {
	if (l.dead || !S.alive[l.faction]) return;
	const home = lordHome(l);
	if (!home) return;
	const culture = FACTION[l.faction].culture;
	const troops = genTroops(culture, initial ? randInt(45, 90) : randInt(25, 45), initial ? .6 : .45);
	const [x, y] = nearestPassable(home.x + randRange(-15, 15), home.y + randRange(-15, 15));
	const p = makeParty("lord", `${l.name}部`, l.faction, x, y, troops, {
		lordId: l.id,
		home: home.id,
		gold: randInt(500, 1500)
	});
	p.goods.grain = 20;
	l.partyId = p.id;
}
function spawnBandit(zoneIdx, strong = false) {
	const zi = zoneIdx ?? randInt(0, BANDIT_ZONES.length - 1);
	const z = BANDIT_ZONES[zi];
	for (let k = 0; k < 20; k++) {
		const [x, y] = ll(z.lon + randRange(-z.r, z.r), z.lat + randRange(-z.r, z.r));
		if (!passable(x, y)) continue;
		if (dist$1(x, y, player()?.x ?? -999, player()?.y ?? -999) < 150) continue;
		const n = strong ? randInt(25, 45) : randInt(6, 26);
		const troops = [{
			id: z.troop,
			n,
			w: 0,
			xp: 0
		}];
		if (n > 15 || strong) addTroops(troops, "bandit_chief", 1);
		if (z.troop === "bandit_mtn" && chance(.4)) addTroops(troops, "bandit_rover", randInt(2, 6));
		const p = makeParty("bandit", z.name, "bandit", x, y, troops, {
			zone: zi,
			gold: n * randInt(5, 12)
		});
		p.ai.ax = x;
		p.ai.ay = y;
		if (chance(.5)) p.goods[pick([
			"grain",
			"wine",
			"salt",
			"cloth",
			"silk",
			"tea"
		])] = randInt(1, 4);
		return p;
	}
	return null;
}
function spawnCaravan() {
	const towns = settlementList().filter((s) => s.kind === "town" && s.faction !== "player");
	if (!towns.length) return null;
	const home = pick(towns);
	const f = home.faction;
	const troops = [];
	addTroops(troops, "civ_guard", randInt(8, 16));
	addTroops(troops, "civ_cguard", randInt(2, 6));
	const p = makeParty("caravan", `${home.name}商队`, f, home.x + 8, home.y + 8, troops, {
		home: home.id,
		gold: randInt(400, 1e3)
	});
	for (const g of home.produce) p.goods[g] = randInt(3, 8);
	return p;
}
function spawnVillager(v) {
	if (!v.parent) return null;
	const troops = [{
		id: v.camp ? "mon_recruit" : "civ_peasant",
		n: randInt(5, 14),
		w: 0,
		xp: 0
	}];
	const [vx, vy] = nearestPassable(v.x + 5, v.y + 5);
	const p = makeParty("villager", `${v.name}${v.camp ? "牧民" : "乡民"}`, v.faction, vx, vy, troops, {
		home: v.id,
		gold: randInt(20, 80)
	});
	for (const g of v.produce) p.goods[g] = randInt(2, 6);
	return p;
}
function ensureWorld(s) {
	ensureWall(s);
	for (const ps of PASSES) {
		let st = s.settlements[ps.id];
		const [wx, wy] = wallPointAtLon(ps.lon);
		if (!st) {
			let near = null, bd = Infinity;
			for (const o of Object.values(s.settlements)) if (o.kind !== "village") {
				const d = Math.hypot(o.x - wx, o.y - wy);
				if (d < bd) {
					bd = d;
					near = o;
				}
			}
			const f = s.time < 48 ? "ming" : near?.faction ?? "ming";
			const fc = f === "player" ? "ming" : f;
			st = {
				id: ps.id,
				name: ps.name,
				kind: "castle",
				faction: f,
				owner: null,
				x: wx,
				y: wy,
				villages: [],
				garrison: genTroops(FACTION[fc]?.culture ?? "ming", randInt(60, 85), .6),
				prosperity: randInt(30, 55),
				stock: {},
				produce: [],
				demand: [],
				shop: [],
				recruits: 0,
				relation: 0,
				lootedUntil: 0,
				siege: null,
				tavern: {
					companion: null,
					mercs: null,
					refresh: 0
				},
				culture: FACTION[fc]?.culture ?? "ming"
			};
			const lords = Object.values(s.lords).filter((l) => l.faction === f && !l.dead);
			if (f === "player") st.owner = "player";
			else if (lords.length) {
				const fiefN = (id) => Object.values(s.settlements).filter((o) => o.owner === id).length;
				st.owner = lords.sort((a, b) => fiefN(a.id) - fiefN(b.id))[0].id;
			} else st.owner = `ruler_${f}`;
			st.stock = stockFor(st);
			s.settlements[ps.id] = st;
		} else if (ps.existing) {
			st.x = wx;
			st.y = wy;
		}
		st.isPass = true;
	}
	for (const st of Object.values(s.settlements)) {
		if (st.isPass) continue;
		for (let r = 0; r < 60 && wallSeg[cellIndex(st.x, st.y)] >= 0; r += 4) {
			st.x += 0;
			st.y += 4;
		}
	}
	for (const ld of LORD_DEFS) if (!s.lords[ld.id] && s.alive[ld.faction]) s.lords[ld.id] = {
		id: ld.id,
		name: ld.name,
		faction: ld.faction,
		title: ld.title,
		trait: ld.trait,
		relation: randInt(-3, 5),
		partyId: null,
		respawnAt: 0
	};
	s.calendarDone ||= [];
	if (!s.flags?.fortV13) {
		for (const st of Object.values(s.settlements)) {
			const cap = garrisonCap(st);
			if (cap > 130 || st.isPass) {
				const need = Math.round(cap * .8) - count(st.garrison);
				if (need > 0) for (const t of genTroops(FACTION[st.faction]?.culture ?? "ming", need, .6)) addTroops(st.garrison, t.id, t.n);
			}
		}
		(s.flags ||= {}).fortV13 = true;
	}
	calendarInit();
}
//#endregion
//#region src/net/hooks.ts
var NETH = {
	on: false,
	eid: 0,
	name: "",
	req: (_op, _args) => Promise.resolve({ ok: true }),
	send: (_m) => {}
};
//#endregion
//#region src/core/economy.ts
function dailyEconomy() {
	for (const st of Object.values(S.settlements)) {
		for (const g of GOODS) {
			if (st.stock[g.id] === void 0) continue;
			const t = targetStock(st, g.id);
			const cur = st.stock[g.id];
			st.stock[g.id] = cur + (t - cur) * .1 + (Math.random() - .5) * 1.2;
			if (st.stock[g.id] < 0) st.stock[g.id] = 0;
		}
		if (st.lootedUntil > S.time) st.prosperity = Math.max(5, st.prosperity - .3);
		else if (st.siege) st.prosperity = Math.max(5, st.prosperity - .5);
		else st.prosperity = Math.min(100, st.prosperity + .05);
	}
}
//#endregion
//#region src/core/war.ts
var d2 = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
/** 按各部可战人数把一份总伤亡分摊到各部 */
function splitDown(down, parts) {
	const out = {};
	for (const p of parts) out[p.pid] = {};
	for (const id in down) {
		let left = down[id];
		const avail = parts.map((p) => ({
			p,
			n: p.stacks.filter((s) => s.id === id).reduce((a, s) => a + s.n - s.w, 0)
		})).filter((x) => x.n > 0);
		let total = avail.reduce((a, x) => a + x.n, 0);
		for (const x of avail) {
			if (left <= 0 || total <= 0) break;
			const k = Math.min(x.n, Math.round(left * x.n / total));
			if (k > 0) out[x.p.pid][id] = (out[x.p.pid][id] || 0) + k;
			left -= k;
			total -= x.n;
		}
		if (left > 0 && avail.length) {
			const x = avail[0];
			out[x.p.pid][id] = (out[x.p.pid][id] || 0) + left;
		}
	}
	return out;
}
function mergeStacks(parts) {
	const m = /* @__PURE__ */ new Map();
	for (const p of parts) for (const s of p.stacks) {
		const e = m.get(s.id);
		if (e) {
			e.n += s.n;
			e.w += s.w;
		} else m.set(s.id, { ...s });
	}
	return [...m.values()];
}
/** 跟随某部的部队（军团成员） */
function followersOf(leader, r = 90) {
	return S.parties.filter((p) => p !== leader && p.ai.mode === "follow" && p.ai.target === leader.id && !p.inside && d2(p, leader) < r);
}
/** 军团：主将 + 附近随行诸部 */
function armyOf(p, r = 90) {
	return [p, ...followersOf(p, r)];
}
/** 城中驻扎、会协助守城的领主部队 */
function lordsInside(st) {
	return S.parties.filter((p) => p.kind === "lord" && p.inside === st.id && p.faction === st.faction && healthy(p.troops) > 0).slice(0, 3);
}
/** 按 downBy 结算友军部队伤亡（约四分之三阵亡，其余负伤） */
function applyPartyLosses(p, down) {
	if (!down) return 0;
	let n = 0;
	for (const id in down) {
		const k = down[id];
		n += k;
		const dead = Math.round(k * .7);
		removeTroops(p.troops, id, dead);
		const st = p.troops.find((s) => s.id === id);
		if (st) st.w = Math.min(st.n, st.w + (k - dead));
	}
	cleanStacks(p.troops);
	return n;
}
function partyLabel(p) {
	return p.lordId ? `${FACTION[p.faction]?.name ?? ""}${lordName(p.lordId)}部` : p.name;
}
function aiArmyBattle(a, b) {
	const A = armyOf(a), B = armyOf(b);
	for (const p of S.parties) {
		if (p.inside || p.kind !== "lord" || A.includes(p) || B.includes(p) || p.kind !== "lord" || player() === p) continue;
		if (d2(p, a) > 60) continue;
		if (!hostile(p, b) && hostile(p, a)) continue;
		if (hostile(p, b) && !hostile(p, a) && A.length < 5) A.push(p);
		else if (hostile(p, a) && !hostile(p, b) && B.length < 5) B.push(p);
	}
	const pa = A.map((p) => ({
		pid: String(p.id),
		stacks: p.troops
	})), pb = B.map((p) => ({
		pid: String(p.id),
		stacks: p.troops
	}));
	const lords = (xs) => xs.filter((p) => p.kind === "lord").length;
	const r = autoResolve(mergeStacks(pa), mergeStacks(pb), lords(A) ? 1.1 : 1, lords(B) ? 1.1 : 1, lords(A) * 8, lords(B) * 8);
	const da = splitDown(r.aDown, pa), db = splitDown(r.bDown, pb);
	for (const p of A) applyPartyLosses(p, da[String(p.id)]);
	for (const p of B) applyPartyLosses(p, db[String(p.id)]);
	const win = r.aWin ? A : B, lose = r.aWin ? B : A;
	const loot = lose.reduce((s, p) => s + Math.round(p.gold * .5), 0);
	win[0].gold += loot;
	for (const p of lose) for (const g in p.goods) win[0].goods[g] = (win[0].goods[g] || 0) + Math.floor(p.goods[g] / 2);
	const near = d2(player(), a) < 400;
	const big = A.length + B.length > 2;
	if (win[0].lordId || lose[0].lordId || near) {
		const wn = big && win.length > 1 ? `${partyLabel(win[0])}等${win.length}路兵马` : partyLabel(win[0]);
		const ln = big && lose.length > 1 ? `${partyLabel(lose[0])}等${lose.length}路兵马` : partyLabel(lose[0]);
		if (win[0].lordId && lose[0].lordId) log(`${wn}大破${ln}。`, "war");
		else if (near) log(`${wn}击败了${ln}。`, "dim");
	}
	for (const p of lose) {
		if (p.lordId && S.lords[p.lordId]) S.lords[p.lordId].grudge = win[0].lordId ?? void 0;
		removeParty(p);
	}
	for (const p of win) {
		cleanStacks(p.troops);
		if (healthy(p.troops) <= 0) removeParty(p);
	}
}
/** 领主决定攻城时，召集附近同阵营空闲领主组成军团 */
function rallyArmy(leader, maxN = 3) {
	const cands = S.parties.filter((p) => p !== leader && p.kind === "lord" && p.faction === leader.faction && !p.inside && p.ai.mode !== "follow" && p.ai.mode !== "siege" && p.ai.mode !== "recruit" && p.ai.mode !== "flee" && d2(p, leader) < 380 && healthy(p.troops) > 25 && !followersOf(p).length).sort((x, y) => d2(x, leader) - d2(y, leader)).slice(0, maxN);
	for (const p of cands) {
		p.ai.mode = "follow";
		p.ai.target = leader.id;
		p.ai.until = S.time + 168;
		p.ai.path = [];
		p.ai.nextThink = S.time;
	}
	if (cands.length >= 2) {
		if (d2(player(), leader) < 700 || playerSide() === leader.faction || atWar(leader.faction, playerSide() ?? "player")) log(`${partyLabel(leader)}召集${cands.map((p) => lordName(p.lordId)).join("、")}合兵一处，号称大军！`, "war");
	}
	return cands;
}
/** 潜在军团的总战力（用于 AI 判断能否攻城） */
function rallyPotential(leader, strengthOf) {
	let s = 0;
	for (const p of S.parties) if (p !== leader && p.kind === "lord" && p.faction === leader.faction && !p.inside && p.ai.mode !== "siege" && p.ai.mode !== "follow" && d2(p, leader) < 380) s += strengthOf(p) * .85;
	return Math.min(s, strengthOf(leader) * 2.5);
}
/** 跟随者的思考：贴近主将；主将不在或期限已到则解散 */
function thinkFollower(p, goTo) {
	const ai = p.ai;
	if (ai.mode !== "follow") return false;
	const L = typeof ai.target === "number" ? partyById(ai.target) : void 0;
	const pp = player();
	if (!L || ai.until !== void 0 && S.time > ai.until || L !== pp && L.faction !== p.faction || L === pp && hostile(pp, p)) {
		if (L === pp) log(`${partyLabel(p)}辞别了你的军团。`, "dim");
		ai.mode = "idle";
		ai.target = void 0;
		ai.path = [];
		return false;
	}
	ai.nextThink = S.time + .5;
	if (L.inside) {
		const st = S.settlements[L.inside];
		if (st && d2(p, st) > 30) goTo(p, st.x + (p.id % 5 - 2) * 6, st.y + 10);
		return true;
	}
	const k = p.id % 6, ox = Math.cos(k) * 14, oy = Math.sin(k) * 14;
	const dd = d2(p, L);
	if (dd < 10) {
		ai.path = [];
		return true;
	}
	if (ai.path?.length && ai.tx !== void 0 && Math.hypot(ai.tx - L.x - ox, ai.ty - L.y - oy) < 12 && dd > 90) return true;
	goTo(p, L.x + ox, L.y + oy);
	return true;
}
function armySiegeAssault(p, st) {
	const A = armyOf(p, 60);
	const D = lordsInside(st);
	const pa = A.map((x) => ({
		pid: String(x.id),
		stacks: x.troops
	}));
	const pd = [{
		pid: "g",
		stacks: st.garrison
	}, ...D.map((x) => ({
		pid: String(x.id),
		stacks: x.troops
	}))];
	const defMult = fortMult(st);
	const r = autoResolve(mergeStacks(pa), mergeStacks(pd), 1, defMult, 8 * A.length, 10 + 8 * D.length);
	const da = splitDown(r.aDown, pa), dd = splitDown(r.bDown, pd);
	for (const x of A) {
		for (const id in da[String(x.id)]) removeTroops(x.troops, id, da[String(x.id)][id]);
		cleanStacks(x.troops);
	}
	for (const id in dd.g) removeTroops(st.garrison, id, dd.g[id]);
	cleanStacks(st.garrison);
	for (const x of D) applyPartyLosses(x, dd[String(x.id)]);
	const old = st.faction, oldOwner = st.owner;
	const name = A.length > 1 ? `${partyLabel(p)}等${A.length}路大军` : `${FACTION[p.faction].name}${lordName(p.lordId ?? null)}`;
	if (r.aWin) {
		for (const x of D) removeParty(x);
		for (const s of [...p.troops]) {
			const k = Math.floor((s.n - s.w) * .35);
			removeTroops(p.troops, s.id, k);
			addTroops(st.garrison, s.id, k);
		}
		setOwner(st, p.faction, p.lordId ?? null);
		log(`${name}攻陷了${FACTION[old]?.name ?? ""}的${st.name}！`, "war");
		if (oldOwner === "player") log(`你的封地${st.name}失守了！`, "bad");
		checkFactionAlive(old);
		for (const x of A) if (x !== p && x.ai.mode === "follow") {
			x.ai.mode = "idle";
			x.ai.target = void 0;
		}
	} else log(`${name}攻打${st.name}失利。`, "war");
	st.siege = null;
	for (const x of A) if (healthy(x.troops) < 5) removeParty(x);
}
//#endregion
//#region src/core/recruits.ts
var RECRUIT = {
	realtime: false,
	perSec: 1,
	cap: 60,
	campPerSec: 1,
	campCap: 60,
	relationBonus: .02,
	daily: {
		min: 1,
		max: 4,
		cap: 15
	},
	lordDraw: 10
};
function recruitCap(s) {
	return RECRUIT.realtime ? s.camp ? RECRUIT.campCap : RECRUIT.cap : RECRUIT.daily.cap;
}
/** 联机：按真实经过秒数补充兵源（由服务器主循环调用） */
function tickRecruits(sec) {
	if (!RECRUIT.realtime || sec <= 0) return;
	for (const s of settlementList()) {
		if (s.kind !== "village") continue;
		if (s.lootedUntil > S.time) continue;
		const cap = recruitCap(s);
		if (s.recruits >= cap) {
			s.racc = 0;
			continue;
		}
		const rate = (s.camp ? RECRUIT.campPerSec : RECRUIT.perSec) * Math.max(.3, 1 + s.relation * RECRUIT.relationBonus);
		const acc = (s.racc ?? 0) + rate * sec;
		const whole = Math.floor(acc);
		s.recruits = Math.min(cap, s.recruits + whole);
		s.racc = acc - whole;
	}
}
/** 单机：每日补充 */
function dailyRecruits() {
	if (RECRUIT.realtime) return;
	const d = RECRUIT.daily;
	for (const s of settlementList()) if (s.kind === "village") s.recruits = Math.min(d.cap, s.recruits + randInt(d.min, d.max) + Math.max(0, Math.floor(s.relation / 15)));
}
/** 某村庄招来的兵种（玩家与 AI 通用）。蒙古包只出骑兵 */
function recruitTroopOf(s, culture, relation = s.relation) {
	if (s.camp) return relation >= 15 ? CAMP_RECRUIT_GOOD : CAMP_RECRUIT;
	return RECRUIT_OF[culture ?? FACTION[s.faction]?.culture ?? "ming"] ?? "ming_recruit";
}
/** AI 领主驻城时补兵。单机：凭空生成（旧规则）；联机：从该城下辖及附近自家村庄的兵源里带走 */
function lordReinforce(p, s) {
	if (!RECRUIT.realtime) {
		for (const t of genTroops(FACTION[p.faction].culture, randInt(5, 10), .35)) addTroops(p.troops, t.id, t.n);
		return;
	}
	const vills = s.villages.map((id) => S.settlements[id]).filter((v) => v && v.faction === p.faction && v.recruits > 0);
	for (const v of vills) {
		const n = Math.min(v.recruits, RECRUIT.lordDraw);
		v.recruits -= n;
		addTroops(p.troops, recruitTroopOf(v, FACTION[p.faction].culture, 20), n);
	}
}
//#endregion
//#region src/core/sim.ts
var nav = {
	path: [],
	target: null,
	waiting: false,
	lastPathAt: 0,
	graceUntil: 0
};
/** 城墙检查：0 可走，1 被挡（清空路径），2 等待夜色 */
function wallStop(p, nx, ny) {
	if (cellIndex(p.x, p.y) === cellIndex(nx, ny)) return 0;
	const r = wallRuleAt(nx, ny, whoOf(p));
	if (r === 0) return 1;
	if (r === 2 && !isNight()) return 2;
	return 0;
}
/** 联机服务器钩子：玩家部队（hero）不走 AI，由服务器驱动 */
var SIM_HOOKS = {};
function moveAlong(p, path, d) {
	while (d > 0 && path.length) {
		if (!passable(path[0][0], path[0][1])) path[0] = nearestPassable(path[0][0], path[0][1]);
		const [tx, ty] = path[0];
		const dd = Math.hypot(tx - p.x, ty - p.y);
		const k = dd <= d ? 1 : d / dd;
		const nx = p.x + (tx - p.x) * k, ny = p.y + (ty - p.y) * k;
		const ws = wallStop(p, nx, ny);
		if (ws === 1) {
			path.length = 0;
			p.ai.replan = true;
			return;
		}
		if (ws === 2) return;
		if (!passable(nx, ny)) {
			const sx = p.x + (nx - p.x), sy = p.y + (ny - p.y);
			if (passable(sx, p.y) && wallStop(p, sx, p.y) === 0 && Math.abs(nx - p.x) > .001) {
				p.x = sx;
				d -= Math.abs(nx - p.x) || d;
				continue;
			}
			if (passable(p.x, sy) && wallStop(p, p.x, sy) === 0 && Math.abs(ny - p.y) > .001) {
				p.y = sy;
				d -= Math.abs(ny - p.y) || d;
				continue;
			}
			path.length = 0;
			p.ai.replan = true;
			return;
		}
		if (dd <= d) {
			p.x = tx;
			p.y = ty;
			d -= dd;
			path.shift();
		} else {
			p.x = nx;
			p.y = ny;
			d = 0;
		}
	}
}
/** 规划路线：近处且视线畅通时直走，否则 A* 寻路。返回是否找到路 */
function goTo(p, x, y) {
	[x, y] = nearestPassable(x, y);
	p.ai.tx = x;
	p.ai.ty = y;
	p.ai.replan = false;
	const who = whoOf(p);
	if (dist$1(p.x, p.y, x, y) < 90 && losClear(p.x, p.y, x, y, who)) {
		p.ai.path = [[x, y]];
		return true;
	}
	if (pathBudget <= 0) {
		p.ai.path = [];
		p.ai.replan = true;
		return true;
	}
	pathBudget--;
	const path = findPath(p.x, p.y, x, y, who);
	p.ai.path = path ?? [];
	return !!path;
}
/** 防卡死：有目标却长时间不动的部队，强制换个想法 */
var stuckResets = 0;
var MOVING = /* @__PURE__ */ new Set([
	"travel",
	"patrol",
	"chase",
	"flee",
	"wander",
	"raid",
	"recruit"
]);
function unstick(p) {
	const ai = p.ai;
	if (p.inside) {
		ai.lm = void 0;
		return;
	}
	if (!passable(p.x, p.y)) [p.x, p.y] = nearestPassable(p.x, p.y);
	const lm = ai.lm;
	if (!lm || Math.hypot(lm[0] - p.x, lm[1] - p.y) > 6) {
		ai.lm = [
			p.x,
			p.y,
			S.time
		];
		return;
	}
	if (!MOVING.has(ai.mode)) {
		lm[2] = S.time;
		return;
	}
	if (ai.tx !== void 0 && dist$1(p.x, p.y, ai.tx, ai.ty) < 24 && ai.mode !== "flee" && ai.mode !== "chase") {
		lm[2] = S.time;
		return;
	}
	if (S.time - lm[2] < 10) return;
	stuckResets++;
	markBad(p, ai.target);
	ai.mode = "idle";
	ai.path = [];
	ai.target = void 0;
	ai.until = void 0;
	ai.tx = ai.ty = void 0;
	ai.nextThink = S.time;
	ai.lm = [
		p.x,
		p.y,
		S.time
	];
}
var isGrudge = (l, o) => !!l?.grudge && (o.lordId === l.grudge || l.grudge === "player" && o.kind === "player");
var avoiding = (p, t) => p.ai.avoid === t && (p.ai.avoidUntil ?? 0) > S.time || (p.ai.bad?.[String(t)] ?? 0) > S.time;
/** 记下一个暂时去不了的目标 */
function markBad(p, t, hours = 48) {
	if (t === void 0) return;
	const b = p.ai.bad ??= {};
	for (const k in b) if (b[k] <= S.time) delete b[k];
	b[String(t)] = S.time + hours;
	p.ai.avoid = t;
	p.ai.avoidUntil = S.time + hours;
}
var regionOfParty = (p) => regionAt(p.x, p.y);
var STEP = .25;
var pathBudget = 0;
var PATH_BUDGET = 14;
/** 推进 hours 小时。若触发事件则提前返回 */
function simulate(hours) {
	if (NETH.on) return false;
	let left = hours;
	while (left > 1e-6) {
		const h = Math.min(STEP, left);
		left -= h;
		if (step(h)) return true;
	}
	return false;
}
function step(h) {
	const prevDay = dayOf(S.time);
	const prevHour = Math.floor(S.time);
	S.time += h;
	pathBudget = PATH_BUDGET;
	const night = isNight();
	const pp = player();
	if (nav.target && !pp.inside) {
		if (nav.target.kind === "party") {
			const tp = partyById(nav.target.id);
			if (!tp || tp.inside) {
				nav.target = null;
				nav.path = [];
			} else if (dist$1(pp.x, pp.y, tp.x, tp.y) < 100 && !wallBetween(pp.x, pp.y, tp.x, tp.y, whoOf(pp))) nav.path = [[tp.x, tp.y]];
			else if (S.time - nav.lastPathAt > 1.5) {
				nav.path = findPath(pp.x, pp.y, tp.x, tp.y, whoOf(pp)) ?? nav.path;
				nav.lastPathAt = S.time;
			}
		}
		moveAlong(pp, nav.path, mapSpeed(S, pp, night) * h);
		if (nav.target?.kind === "settlement") {
			const st = S.settlements[nav.target.id];
			if (dist$1(pp.x, pp.y, st.x, st.y) < 10 || !nav.path.length) {
				nav.target = null;
				nav.path = [];
				emit("arrive", st);
				return true;
			}
		} else if (nav.target?.kind === "party") {
			const tp = partyById(nav.target.id);
			if (tp && dist$1(pp.x, pp.y, tp.x, tp.y) < 12) {
				nav.target = null;
				nav.path = [];
				emit("encounter", tp, false);
				return true;
			}
		} else if (nav.target?.kind === "point" && !nav.path.length) nav.target = null;
	}
	for (const s of settlementList()) if (s.siege && s.siege.by === pp.id && dist$1(pp.x, pp.y, s.x, s.y) > 60) {
		s.siege = null;
		log(`你离开了${s.name}，包围解除。`, "dim");
	}
	for (const p of [...S.parties]) {
		if (p.kind === "player" || !S.parties.includes(p)) continue;
		if (p.busy) continue;
		if (p.kind === "hero") {
			if (!p.inside) SIM_HOOKS.heroMove?.(p, h, night);
			continue;
		}
		if (S.time >= p.ai.nextThink) try {
			think(p);
		} catch (e) {
			p.ai.mode = "idle";
			p.ai.path = [];
			p.ai.nextThink = S.time + 2;
			guard("think:" + p.kind, () => {
				throw e;
			});
		}
		if (p.inside) continue;
		if (p.ai.path && p.ai.path.length) {
			if (p.ai.mode === "chase" || p.ai.mode === "flee" && typeof p.ai.target === "number") {
				const t = partyById(p.ai.target);
				if (t && p.ai.mode === "chase" && dist$1(p.x, p.y, t.x, t.y) < 90 && losClear(p.x, p.y, t.x, t.y, whoOf(p))) {
					p.ai.path = [[t.x, t.y]];
					p.ai.tx = t.x;
					p.ai.ty = t.y;
				}
			}
			moveAlong(p, p.ai.path, mapSpeed(S, p, night) * h * (p.ai.mode === "follow" ? 1.25 : 1));
		}
		if (p.ai.replan && !p.ai.path?.length && p.ai.tx !== void 0 && pathBudget > 0) {
			if (!goTo(p, p.ai.tx, p.ai.ty)) {
				markBad(p, p.ai.target);
				p.ai.mode = "idle";
				p.ai.target = void 0;
				p.ai.nextThink = S.time;
			}
		}
		arrive(p);
	}
	if (Math.floor(S.time) !== prevHour) guard("hourly", hourly);
	if (dayOf(S.time) !== prevDay) guard("daily", daily);
	if (contacts()) return true;
	if (S.pendingDefense && pendingDefenseValid()) return true;
	return false;
}
/** “入城助守”提示的自愈：敌军已不在、围城已解、玩家已离开，或提示丢失超过 3 小时，则清除 */
function pendingDefenseValid() {
	const pd = S.pendingDefense;
	const st = S.settlements[pd.st], foe = partyById(pd.by), pp = player();
	pd.at ??= S.time;
	const here = !!st && (pp.inside === st.id || Math.hypot(pp.x - st.x, pp.y - st.y) < 40);
	if (st && foe && st.siege && st.siege.by === foe.id && here && S.time - pd.at < 3) return true;
	S.pendingDefense = null;
	if (st && foe && st.siege && st.siege.by === foe.id) guard("defenseFallback", () => armySiegeAssault(foe, st));
	return false;
}
var simErrors = [];
function guard(where, fn) {
	try {
		fn();
	} catch (e) {
		const msg = e instanceof Error ? `${e.message}\n${(e.stack ?? "").split("\n").slice(1, 5).join("\n")}` : String(e);
		if (simErrors.length < 40) simErrors.push({
			at: S.time,
			where,
			msg
		});
		console.error("[sim]", where, e);
	}
}
function contacts() {
	const pp = player();
	const ps = S.parties;
	for (let i = 0; i < ps.length; i++) {
		const a = ps[i];
		if (a.inside || a.busy) continue;
		for (let j = i + 1; j < ps.length; j++) {
			const b = ps[j];
			if (b.inside || b.busy) continue;
			const dx = a.x - b.x, dy = a.y - b.y;
			if (dx * dx + dy * dy > 100) continue;
			if (!hostile(a, b)) continue;
			if (regionOfParty(a) !== regionOfParty(b) && wallBetween(a.x, a.y, b.x, b.y, whoOf(a)) === 1) continue;
			if (a.kind === "hero" || b.kind === "hero") {
				if ((a.grace ?? 0) > S.time || (b.grace ?? 0) > S.time) continue;
				if (a.kind === "hero") SIM_HOOKS.heroContact?.(a, b);
				else SIM_HOOKS.heroContact?.(b, a);
				if (a.busy) break;
				continue;
			}
			if (a === pp || b === pp) {
				const o = a === pp ? b : a;
				if (o.ai.mode === "chase" && o.ai.target === pp.id && S.time >= nav.graceUntil && !pp.inside) {
					nav.target = null;
					nav.path = [];
					nav.waiting = false;
					emit("encounter", o, true);
					return true;
				}
				continue;
			}
			if (a.ai.mode === "chase" && a.ai.target === b.id || b.ai.mode === "chase" && b.ai.target === a.id || a.kind === "lord" && b.kind === "lord") {
				const fa = !hostile(pp, a) && hostile(pp, b), fb = !hostile(pp, b) && hostile(pp, a);
				if ((fa || fb) && !pp.inside && Math.hypot(pp.x - a.x, pp.y - a.y) < 55 && S.time >= nav.graceUntil && (a.kind === "lord" || b.kind === "lord")) {
					nav.target = null;
					nav.path = [];
					nav.waiting = false;
					emit("joinBattle", fa ? a : b, fa ? b : a);
					return true;
				}
				aiArmyBattle(a, b);
				return false;
			}
		}
	}
	return false;
}
function arrive(p) {
	const ai = p.ai;
	if (ai.path && ai.path.length) return;
	if (ai.mode === "flee" && typeof ai.target === "string") {
		const st = S.settlements[ai.target];
		if (st && st.kind !== "village" && !factionHostileToSettlement(p.faction, st) && dist$1(p.x, p.y, st.x, st.y) <= (st.isPass ? 46 : 24)) {
			p.inside = st.id;
			ai.mode = "idle";
			ai.until = S.time + randRange(6, 12);
			ai.path = [];
			return;
		}
	}
	if (ai.mode === "siege" && typeof ai.target === "string") {
		const st = S.settlements[ai.target];
		if (!st || !factionHostileToSettlement(p.faction, st)) {
			ai.mode = "idle";
			ai.nextThink = S.time;
			return;
		}
		if (dist$1(p.x, p.y, st.x, st.y) > (st.isPass ? 46 : 20)) {
			ai.nextThink = S.time;
			return;
		}
		if (!st.siege) {
			st.siege = {
				by: p.id,
				since: S.time
			};
			if (st.owner === "player" || st.faction === playerSide()) log(`${lordName(p.lordId ?? null)}率军围攻${st.name}！`, "bad");
		} else if (st.siege.by === p.id && S.time - st.siege.since > 20) {
			const pp = player();
			const friendly = st.owner === "player" || !!playerSide() && st.faction === playerSide();
			const here = pp.inside === st.id || Math.hypot(pp.x - st.x, pp.y - st.y) < 28;
			if (friendly && here && (healthy(pp.troops) > 0 || S.hero.hp >= .25) && !S.pendingDefense) {
				S.pendingDefense = {
					st: st.id,
					by: p.id
				};
				emit("defendPrompt", st, p);
				return;
			}
			if (!S.pendingDefense || S.pendingDefense.st !== st.id) armySiegeAssault(p, st);
		}
	} else if (ai.mode === "breach" && typeof ai.target === "number") {
		if (!SEGS[ai.target] || isBreached(ai.target)) {
			ai.mode = "idle";
			ai.nextThink = S.time;
			return;
		}
		if (ai.tx !== void 0 && dist$1(p.x, p.y, ai.tx, ai.ty) > 16) {
			ai.nextThink = S.time;
			return;
		}
		if (ai.until === void 0) ai.until = S.time + 10;
		else if (S.time >= ai.until) {
			breachWall(ai.target, p);
			ai.mode = "idle";
			ai.until = void 0;
			ai.nextThink = S.time;
		}
	} else if (ai.mode === "raid" && typeof ai.target === "string") {
		const v = S.settlements[ai.target];
		if (!v || dist$1(p.x, p.y, v.x, v.y) > 20) return;
		if (ai.until === void 0) ai.until = S.time + 6;
		else if (S.time >= ai.until) {
			v.lootedUntil = S.time + 96;
			v.prosperity = Math.max(5, v.prosperity - 12);
			p.gold += 150 + Math.round(v.prosperity * 3);
			for (const g of v.produce) p.goods[g] = (p.goods[g] || 0) + 3;
			if (v.owner === "player") log(`你的封地${v.name}被${lordName(p.lordId ?? null)}洗劫了！`, "bad");
			else if (dist$1(player().x, player().y, v.x, v.y) < 400) log(`${lordName(p.lordId ?? null)}洗劫了${v.name}。`, "war");
			ai.until = void 0;
			ai.mode = "idle";
			ai.nextThink = S.time;
		}
	}
}
function visibleHostiles(p, range) {
	const out = [];
	for (const o of S.parties) {
		if (o === p || o.inside || o.busy || o.hidden || (o.grace ?? 0) > S.time) continue;
		const d = dist$1(p.x, p.y, o.x, o.y);
		if (d > range) continue;
		if (!hostile(p, o)) continue;
		if (wallBetween(p.x, p.y, o.x, o.y, whoOf(p)) === 1) continue;
		out.push({
			o,
			d,
			s: partyStrength(S, o)
		});
	}
	return out.sort((a, b) => a.d - b.d);
}
/** 逃跑：优先退入友方城池，其次往友军那边撤，再次找一条真正走得通、能拉开距离的路。
*  返回 false 表示无路可逃（背水一战） */
function fleeFrom(p, o) {
	const ai = p.ai;
	const refuge = nearestSettlement(p.x, p.y, (s) => !factionHostileToSettlement(p.faction, s) && s.kind !== "village" && p.kind !== "bandit");
	if (refuge && dist$1(p.x, p.y, refuge.x, refuge.y) < 250 && dist$1(o.x, o.y, refuge.x, refuge.y) > dist$1(p.x, p.y, refuge.x, refuge.y) * .7) {
		if (goTo(p, refuge.x, refuge.y)) {
			ai.mode = "flee";
			ai.target = refuge.id;
			return true;
		}
	}
	if (p.kind === "lord") {
		const ally = S.parties.find((q) => q !== p && q.kind === "lord" && !q.inside && q.faction === p.faction && dist$1(p.x, p.y, q.x, q.y) < 320 && dist$1(p.x, p.y, q.x, q.y) > 40 && dist$1(o.x, o.y, q.x, q.y) > dist$1(p.x, p.y, q.x, q.y) * .8);
		if (ally && goTo(p, ally.x, ally.y)) {
			ai.mode = "flee";
			ai.target = o.id;
			ally.ai.nextThink = Math.min(ally.ai.nextThink, S.time + .5);
			return true;
		}
	}
	const dx = p.x - o.x, dy = p.y - o.y, base = Math.atan2(dy, dx);
	const cands = [];
	for (const off of [
		0,
		.5,
		-.5,
		1,
		-1,
		1.5,
		-1.5,
		2.1,
		-2.1
	]) for (const r of [170, 110]) {
		let tx = p.x + Math.cos(base + off) * r, ty = p.y + Math.sin(base + off) * r;
		if (!passable(tx, ty)) [tx, ty] = nearestPassable(tx, ty);
		if (dist$1(p.x, p.y, tx, ty) < 50) continue;
		const gain = dist$1(o.x, o.y, tx, ty) - dist$1(o.x, o.y, p.x, p.y);
		if (gain > 35) cands.push({
			x: tx,
			y: ty,
			gain: gain - Math.abs(off) * 12
		});
	}
	cands.sort((a, b) => b.gain - a.gain);
	for (const c of cands.slice(0, 4)) if (goTo(p, c.x, c.y)) {
		ai.mode = "flee";
		ai.target = o.id;
		return true;
	}
	return false;
}
/** 追击：只有真的走得到才追，否则暂时放弃这个目标 */
function pursue(p, o) {
	if (goTo(p, o.x, o.y)) {
		p.ai.mode = "chase";
		p.ai.target = o.id;
		return true;
	}
	markBad(p, o.id, 24);
	p.ai.mode = "idle";
	p.ai.path = [];
	return false;
}
/** 无路可逃：掉头死战 */
function standAndFight(p, o) {
	const ai = p.ai;
	ai.cornered = S.time;
	if (p.kind === "caravan" || p.kind === "villager") {
		ai.mode = "idle";
		ai.path = [];
		ai.nextThink = S.time + 1;
		return;
	}
	if (!pursue(p, o)) {
		ai.mode = "idle";
		ai.nextThink = S.time + 1;
	}
}
function think(p) {
	p.ai.nextThink = S.time + randRange(1.5, 3.5);
	if (p.kind === "bandit") return thinkBandit(p);
	if (p.kind === "caravan" || p.kind === "villager") return thinkTrader(p);
	if (p.kind === "lord") return thinkLord(p);
}
function thinkBandit(p) {
	const me = partyStrength(S, p);
	const hs = visibleHostiles(p, 170);
	const threat = hs.find((h) => h.s > me * 1.1 && h.d < 130);
	if (threat) {
		if (!fleeFrom(p, threat.o)) standAndFight(p, threat.o);
		return;
	}
	const prey = hs.find((h) => h.s < me * .85 && h.o.kind !== "lord" && !avoiding(p, h.o.id));
	if (prey && pursue(p, prey.o)) return;
	if (p.ai.mode === "chase" || p.ai.mode === "flee" || !p.ai.path?.length) {
		if (p.ai.mode === "wander" && p.ai.until && S.time < p.ai.until) return;
		const r = 120;
		const [tx, ty] = nearestPassable((p.ai.ax ?? p.x) + randRange(-120, r), (p.ai.ay ?? p.y) + randRange(-120, r));
		p.ai.mode = "wander";
		p.ai.target = void 0;
		p.ai.until = S.time + randRange(4, 12);
		goTo(p, tx, ty);
	}
}
function thinkTrader(p) {
	const me = partyStrength(S, p);
	const threat = visibleHostiles(p, 140).find((h) => h.s > me * .8 && h.d < 120);
	if (threat && p.inside) {
		p.ai.until = Math.max(p.ai.until ?? 0, S.time + 3);
		return;
	}
	if (threat) {
		if (!fleeFrom(p, threat.o)) standAndFight(p, threat.o);
		return;
	}
	if (p.inside) {
		if (p.ai.until && S.time < p.ai.until) return;
		p.inside = void 0;
	}
	if (p.ai.path?.length && p.ai.mode === "travel") return;
	if (p.ai.mode === "travel" && typeof p.ai.target === "string") {
		const st = S.settlements[p.ai.target];
		if (st && dist$1(p.x, p.y, st.x, st.y) < (st.isPass ? 50 : 24)) {
			if (p.kind === "villager" && st.id === p.home) {
				removeParty(p);
				return;
			}
			for (const g in p.goods) {
				st.stock[g] = (st.stock[g] ?? 0) + p.goods[g];
				p.gold += p.goods[g] * (GOOD[g]?.base ?? 20);
			}
			p.goods = {};
			if (p.kind === "caravan") for (const g of st.produce) p.goods[g] = randInt(3, 8);
			p.inside = st.id;
			p.ai.until = S.time + randRange(4, 8);
			p.ai.mode = "idle";
			return;
		}
	}
	let dest;
	if (p.kind === "villager") {
		const home = S.settlements[p.home];
		if (p.ai.mode === "idle" && p.ai.target && p.ai.target !== p.home) dest = home;
		else dest = home?.parent ? S.settlements[home.parent] : void 0;
		if (!dest || factionHostileToSettlement(p.faction, dest) || avoiding(p, dest.id)) dest = home;
	} else {
		const who = whoOf(p);
		const opts = settlementList().filter((s) => s.kind === "town" && s.id !== p.ai.target && !avoiding(p, s.id) && !factionHostileToSettlement(p.faction, s) && dist$1(p.x, p.y, s.x, s.y) < 900 && reachableFor(who, p.x, p.y, s.x, s.y));
		dest = opts.length ? pick(opts) : void 0;
	}
	if (!dest) {
		removeParty(p);
		return;
	}
	p.ai.mode = "travel";
	p.ai.target = dest.id;
	if (!goTo(p, dest.x, dest.y)) {
		markBad(p, dest.id);
		if (p.kind === "villager" && dest.id === p.home) {
			removeParty(p);
			return;
		}
		p.ai.mode = "idle";
		p.ai.target = void 0;
		p.ai.nextThink = S.time + .5;
	}
}
function lordDesired(p) {
	const fiefs = fiefsOf(p.lordId).length;
	return Math.min(160, 60 + fiefs * 12 + Math.floor(S.time / 24 / 10));
}
function thinkLord(p) {
	if (p.ai.mode === "follow") {
		if (thinkFollower(p, (q, x, y) => {
			goTo(q, x, y);
		})) return;
	}
	const me = partyStrength(S, p);
	const n = count(p.troops);
	const ai = p.ai;
	const hs = visibleHostiles(p, 240);
	const lordRec = S.lords[p.lordId];
	if (!p.inside && hs.length) {
		const allies = S.parties.filter((q) => q !== p && q.kind === "lord" && !q.inside && q.faction === p.faction && dist$1(p.x, p.y, q.x, q.y) < 200);
		const allyStr = allies.reduce((a, q) => a + partyStrength(S, q), 0);
		const trait = lordRec?.trait;
		let tol = trait === "brave" ? 1.85 : trait === "cautious" ? 1.05 : trait === "greedy" ? 1.2 : 1.4;
		const home = nearestSettlement(p.x, p.y, (s) => s.faction === p.faction && s.kind !== "village");
		if (home && dist$1(p.x, p.y, home.x, home.y) < 150) tol += home.owner === p.lordId ? .7 : .35;
		if (ai.cornered && S.time - ai.cornered < 12) tol += .6;
		const mine = me + allyStr * .75;
		const threat = hs.find((h) => h.d < 160 && h.s > mine * (isGrudge(lordRec, h.o) ? tol + .3 : tol));
		if (threat) {
			if (allies.length && threat.s < (me + allyStr) * 1.15) {
				for (const q of allies) pursue(q, threat.o);
				if (pursue(p, threat.o)) return;
			}
			if (!fleeFrom(p, threat.o)) standAndFight(p, threat.o);
			return;
		}
	}
	if (ai.mode === "travel" && typeof ai.target === "string") {
		const st = S.settlements[ai.target];
		if (st && dist$1(p.x, p.y, st.x, st.y) <= (st.isPass ? 46 : 22)) {
			if (st.faction === p.faction) {
				p.inside = st.id;
				ai.until = S.time + 72;
			}
			ai.mode = "idle";
			return;
		}
		if (st) {
			if (!ai.path?.length) goTo(p, st.x, st.y);
			return;
		}
		ai.mode = "idle";
	}
	if (ai.mode === "breach" && typeof ai.target === "number") {
		if (!isBreached(ai.target)) {
			if (!ai.path?.length && ai.tx !== void 0 && dist$1(p.x, p.y, ai.tx, ai.ty) > 16) goTo(p, ai.tx, ai.ty);
			return;
		}
		ai.mode = "idle";
	}
	if ((ai.mode === "siege" || ai.mode === "raid") && typeof ai.target === "string") {
		const st = S.settlements[ai.target];
		if (st && factionHostileToSettlement(p.faction, st) && !(ai.mode === "raid" && st.lootedUntil > S.time)) {
			if (!(st.siege && st.siege.by !== p.id && partyById(st.siege.by))) {
				if (!ai.path?.length && dist$1(p.x, p.y, st.x, st.y) > 20) goTo(p, st.x, st.y);
				return;
			}
		}
		ai.mode = "idle";
	}
	const prey = hs.find((h) => !avoiding(p, h.o.id) && (h.s < me * .8 || isGrudge(lordRec, h.o) && h.s < me * 1.3) && (h.o.kind !== "player" || chance(.85)));
	if (prey && !p.inside && pursue(p, prey.o)) return;
	if (p.inside) {
		if (ai.until && S.time < ai.until) return;
		p.inside = void 0;
	}
	if (n < lordDesired(p) * .45) {
		const home = nearestSettlement(p.x, p.y, (s) => s.faction === p.faction && s.kind !== "village" && !s.siege && !avoiding(p, s.id));
		if (home) {
			if (dist$1(p.x, p.y, home.x, home.y) < (home.isPass ? 50 : 24)) {
				p.inside = home.id;
				ai.mode = "recruit";
				ai.until = S.time + 24;
				return;
			}
			if (goTo(p, home.x, home.y)) {
				ai.mode = "recruit";
				ai.target = home.id;
				return;
			}
			markBad(p, home.id);
		}
	}
	if (ai.mode === "recruit" && typeof ai.target === "string" && ai.path?.length) return;
	const march = theaterMarch(p);
	if (march && !p.inside && dist$1(p.x, p.y, march.x, march.y) > 40) {
		if (ai.mode !== "patrol" || ai.target !== march.id || !ai.path?.length) {
			ai.mode = "patrol";
			ai.target = march.id;
			goTo(p, march.x, march.y);
		}
		return;
	}
	const besieged = settlementList().find((s) => s.siege && s.faction === p.faction && dist$1(p.x, p.y, s.x, s.y) < 500);
	if (besieged) {
		const enemy = partyById(besieged.siege.by);
		if (enemy && !avoiding(p, enemy.id) && partyStrength(S, enemy) < me * 1.1 && pursue(p, enemy)) return;
	}
	const enemies = MAJOR_FACTIONS.filter((f) => S.alive[f] && atWar(p.faction, f));
	if (atWar(p.faction, "player") || playerSide() && atWar(p.faction, playerSide())) enemies.push("player");
	const lord = S.lords[p.lordId];
	const aggression = lord?.trait === "brave" ? 1.3 : lord?.trait === "cautious" ? .75 : 1;
	if (enemies.length && (ai.mode !== "patrol" || !ai.path?.length || chance(.3))) {
		const who = whoOf(p);
		const allTargets = settlementList().filter((s) => s.kind !== "village" && factionHostileToSettlement(p.faction, s) && dist$1(p.x, p.y, s.x, s.y) < 750 && !avoiding(p, s.id));
		const targets = allTargets.filter((s) => (s.isPass || reachableFor(who, p.x, p.y, s.x, s.y)) && theaterAllows(p, s.x, s.y));
		const pot = me + rallyPotential(p, (o) => partyStrength(S, o));
		const viable = targets.filter((s) => partyStrengthOfGarrison(s) * fortMult(s) < pot * aggression * .95 && (!s.siege || !partyById(s.siege.by)));
		if (viable.length && chance(.7)) {
			viable.sort((a, b) => dist$1(p.x, p.y, a.x, a.y) - dist$1(p.x, p.y, b.x, b.y));
			const st = viable[0];
			if (partyStrengthOfGarrison(st) * fortMult(st) > me * aggression * .8 || chance(.35)) rallyArmy(p, st.kind === "town" ? 4 : 2);
			ai.mode = "siege";
			ai.target = st.id;
			goTo(p, st.x, st.y);
			return;
		}
		if (allTargets.filter((s) => !targets.includes(s)).length && (pot > 900 || count(p.troops) > 150) && chance(lord?.trait === "brave" ? .3 : .15)) {
			const b = pickBreachSeg(p);
			if (b) {
				if (pot > me * 1.3) rallyArmy(p, 3);
				ai.mode = "breach";
				ai.target = b.seg;
				ai.until = void 0;
				goTo(p, b.x, b.y);
				ai.tx = b.x;
				ai.ty = b.y;
				return;
			}
		}
		const vills = settlementList().filter((s) => s.kind === "village" && factionHostileToSettlement(p.faction, s) && s.lootedUntil < S.time && !avoiding(p, s.id) && dist$1(p.x, p.y, s.x, s.y) < 450 && reachableFor(who, p.x, p.y, s.x, s.y) && theaterAllows(p, s.x, s.y));
		if (vills.length && chance(lord?.trait === "honorable" ? .25 : .55)) {
			const v = pick(vills);
			ai.mode = "raid";
			ai.target = v.id;
			ai.until = void 0;
			goTo(p, v.x, v.y);
			return;
		}
	}
	if (ai.path?.length && (ai.mode === "patrol" || ai.mode === "chase")) return;
	let own = factionSettlements(p.faction).filter((s) => dist$1(p.x, p.y, s.x, s.y) < 500 && theaterAllows(p, s.x, s.y) && !avoiding(p, s.id));
	if (!own.length) {
		const n = nearestSettlement(p.x, p.y, (s) => s.faction === p.faction && !avoiding(p, s.id));
		if (n) own = [n];
	}
	for (let tries = 0; tries < 3 && own.length; tries++) {
		const t = pick(own);
		if (dist$1(p.x, p.y, t.x, t.y) < 24 && t.kind !== "village" && chance(.4)) {
			p.inside = t.id;
			ai.mode = "idle";
			ai.until = S.time + randRange(6, 16);
			return;
		}
		const [tx, ty] = nearestPassable(t.x + randRange(-40, 40), t.y + randRange(-40, 40));
		if (goTo(p, tx, ty)) {
			ai.mode = "patrol";
			ai.target = t.id;
			return;
		}
		markBad(p, t.id);
		own = own.filter((s) => s !== t);
	}
	if (enemies.length && chance(lord?.trait === "cautious" ? .25 : .45)) {
		const b = pickBreachSeg(p);
		if (b && !avoiding(p, "seg" + b.seg)) {
			if (goTo(p, b.x, b.y)) {
				ai.mode = "breach";
				ai.target = b.seg;
				ai.until = void 0;
				ai.tx = b.x;
				ai.ty = b.y;
				return;
			}
			markBad(p, "seg" + b.seg);
		}
	}
	for (let tries = 0; tries < 4; tries++) {
		const a = Math.random() * Math.PI * 2, r = randRange(60, 160);
		const [tx, ty] = nearestPassable(p.x + Math.cos(a) * r, p.y + Math.sin(a) * r);
		if (goTo(p, tx, ty)) {
			ai.mode = "patrol";
			ai.target = void 0;
			return;
		}
	}
	ai.mode = "idle";
	ai.nextThink = S.time + 2;
}
function partyStrengthOfGarrison(s) {
	let v = 0;
	for (const st of s.garrison) {
		const t = TROOPS[st.id];
		if (t) v += t.hp / 10 * ((Math.max(t.atk, (t.rng ?? 0) * .8) + t.skill * .6) / 10) * (1 + t.def / 25) * (st.n - st.w);
	}
	return v;
}
/** 玩家个人的每小时结算（单机由世界调用；联机由客户端按服务器时间调用） */
function playerHourly() {
	const inside = !!player().inside;
	S.hero.hp = Math.min(1, S.hero.hp + (inside ? .03 : .012) * (1 + partySkill(S, "surgery") * .1));
	for (const c of S.companions) if (c.wounded > 0) c.wounded = Math.max(0, c.wounded - (inside ? 2 : 1));
}
var WORLD_OPT = { personal: true };
function hourly() {
	if (WORLD_OPT.personal) playerHourly();
	guard("wallHourly", wallHourly);
	guard("unstick", () => {
		for (const p of S.parties) if (p.kind !== "player") unstick(p);
	});
	const hr = Math.floor(S.time);
	if (hr % 6 === 0) {
		if (S.parties.filter((p) => p.kind === "bandit").length < 32) spawnBandit();
		if (S.parties.filter((p) => p.kind === "villager").length < 14) {
			const vs = settlementList().filter((s) => s.kind === "village" && s.lootedUntil < S.time);
			if (vs.length) spawnVillager(pick(vs));
		}
	}
	if (hr % 12 === 0) {
		if (S.parties.filter((p) => p.kind === "caravan").length < 12) spawnCaravan();
		for (const l of Object.values(S.lords)) if (!l.dead && l.partyId === null && S.time >= l.respawnAt && S.alive[l.faction]) spawnLordParty(l);
	}
}
function daily() {
	const day = dayOf(S.time);
	S.stats.days = day;
	guard("wallDaily", wallDaily);
	guard("calendar", calendarDaily);
	if (day % 3 === 0) guard("randomEvents", randomEvents);
	if (day % 7 === 3) guard("revive", reviveFactions);
	dailyEconomy();
	if (WORLD_OPT.personal) playerDaily();
	worldDaily(day);
}
/** 玩家个人的每日结算：任务期限、粮食、士气、超编、伤兵、训练 */
function playerDaily() {
	const pp = player();
	dailyQuests();
	const need = dailyFood(S, pp);
	let eaten = 0;
	const foods = Object.keys(pp.goods).filter((g) => GOOD[g]?.food && pp.goods[g] > 0);
	for (let i = 0; i < need && foods.length; i++) {
		const g = foods[i % foods.length];
		if (pp.goods[g] > 0) {
			pp.goods[g]--;
			eaten++;
		}
		if (pp.goods[g] <= 0) {
			delete pp.goods[g];
			foods.splice(foods.indexOf(g), 1);
		}
	}
	if (eaten < need && !pp.inside) {
		S.morale = Math.max(0, S.morale - 12);
		log("部队断粮了！士气大跌，赶快购买粮食。", "bad");
	}
	const bonus = Object.keys(pp.goods).filter((g) => GOOD[g]?.food && pp.goods[g] > 0).reduce((a, g) => a + (GOOD[g].morale ?? 0) + 3, 0);
	const target = Math.max(0, Math.min(100, 45 + S.hero.skills.leadership * 6 + bonus + Math.floor(S.renown / 100) - Math.max(0, partySize(S, pp) - 20) / 3));
	S.morale += (target - S.morale) * .15;
	if (S.morale < 18 && count(pp.troops) > 0) {
		const st = pick(pp.troops);
		const k = Math.max(1, Math.round(st.n * .1));
		removeTroops(pp.troops, st.id, k);
		log(`士气低落，${k} 名${TROOPS[st.id].name}趁夜逃走了。`, "bad");
	}
	const over = count(pp.troops) + 1 + S.companions.length - partyLimit(S);
	if (over > 0 && pp.troops.length) {
		const st = pp.troops[pp.troops.length - 1];
		removeTroops(pp.troops, st.id, Math.min(over, st.n));
		log("部队超编，有人离队了。", "bad");
	}
	const heal = (.12 + partySkill(S, "surgery") * .03) * (pp.inside ? 1.5 : 1);
	for (const st of pp.troops) if (st.w > 0) st.w = Math.max(0, st.w - Math.max(1, Math.round(st.w * heal)));
	const tr = partySkill(S, "training");
	if (tr > 0) {
		for (const st of pp.troops) if ((TROOPS[st.id]?.tier ?? 9) < S.hero.level) st.xp += tr * 3 * (st.n - st.w);
	}
}
function worldDaily(day) {
	for (const p of S.parties) {
		if (p.kind !== "lord") continue;
		for (const st of p.troops) if (st.w > 0) st.w = Math.max(0, st.w - Math.ceil(st.w * .2));
		if (p.inside) {
			const s = S.settlements[p.inside];
			if (s && s.faction === p.faction) lordReinforce(p, s);
		}
		for (const st of [...p.troops]) {
			const t = TROOPS[st.id];
			if (t.upgrades.length && chance(.15)) {
				const k = Math.ceil(st.n * .1);
				removeTroops(p.troops, st.id, k);
				addTroops(p.troops, pick(t.upgrades), k);
			}
		}
		cleanStacks(p.troops);
	}
	for (const s of settlementList()) {
		if (s.kind === "village") continue;
		for (const st of s.garrison) if (st.w > 0) st.w = Math.max(0, st.w - Math.ceil(st.w * .25));
		if (s.owner !== "player" && !s.siege) {
			const cap = garrisonCap(s);
			if (count(s.garrison) < cap && chance(.7)) for (const t of genTroops(FACTION[s.faction]?.culture ?? "ming", randInt(1, 3) * Math.max(1, Math.round(cap / 110)), .5)) addTroops(s.garrison, t.id, t.n);
		}
		if (s.tavern.refresh < S.time && s.kind === "town") refreshTavern(s);
	}
	if (day % 7 === 0) weekly();
	emit("daily");
}
function weekly() {
	if (WORLD_OPT.personal) playerWeekly();
	dailyRecruits();
	for (const s of settlementList()) if (s.kind !== "village") refreshShop(s);
	diplomacy();
}
/** 玩家个人的每周结算：军饷、封地收入、守军军饷、雇佣金 */
function playerWeekly() {
	const pp = player();
	const wages = weeklyWages(S, pp);
	if (wages > 0) {
		if (pp.gold >= wages) {
			pp.gold -= wages;
			log(`支付军饷 ${wages} 两。`, "dim");
		} else {
			log(`银两不足，无法支付 ${wages} 两军饷！士气大跌。`, "bad");
			pp.gold = 0;
			S.morale = Math.max(0, S.morale - 20);
		}
	}
	let income = 0;
	for (const s of fiefsOf("player")) {
		if (s.lootedUntil > S.time || s.siege) continue;
		income += Math.round((s.kind === "town" ? 450 : s.kind === "castle" ? 160 : 90) * (.5 + s.prosperity / 100));
	}
	let gw = 0;
	for (const s of fiefsOf("player")) for (const st of s.garrison) gw += Math.round((TROOPS[st.id]?.wage ?? 2) * st.n * .5);
	if (income) {
		pp.gold += income;
		log(`封地上缴税银 ${income} 两。`, "good");
	}
	for (const t of passToll()) {
		pp.gold += t.gold;
		log(`${t.name}关税入账 ${t.gold} 两。`, "good");
	}
	if (gw) {
		pp.gold = Math.max(0, pp.gold - gw);
		log(`支付守军军饷 ${gw} 两。`, "dim");
	}
	if (S.mercOf) {
		if (S.time > S.mercUntil) {
			log(`与${FACTION[S.mercOf].name}的雇佣契约到期了。`, "quest");
			S.mercOf = null;
		} else {
			const pay = 50 + healthy(pp.troops) * 5;
			pp.gold += pay;
			log(`${FACTION[S.mercOf].name}支付雇佣金 ${pay} 两。`, "good");
		}
	}
}
function diplomacy() {
	const alive = MAJOR_FACTIONS.filter((f) => S.alive[f]);
	for (let i = 0; i < alive.length; i++) for (let j = i + 1; j < alive.length; j++) {
		const a = alive[i], b = alive[j];
		const key = [a, b].sort().join("|");
		const war = atWar(a, b);
		if ((S.truceUntil[key] ?? 0) > S.time) continue;
		const mingJin = key === "jin|ming";
		if (war && chance(mingJin ? .02 : .07)) {
			setWar(a, b, false);
			S.truceUntil[key] = S.time + 720;
			log(`${FACTION[a].name}与${FACTION[b].name}议和了。`, "war");
		} else if (!war && chance(mingJin ? .5 : .06)) {
			if (S.wars.filter((k) => k.includes(a)).length <= 2) {
				setWar(a, b, true);
				S.truceUntil[key] = S.time + 480;
				log(`${FACTION[a].name}向${FACTION[b].name}宣战！`, "war");
			}
		}
	}
}
//#endregion
//#region server/diplomacy.ts
var DIPLO = {
	allianceDays: 72,
	truceDays: 15,
	vassalDays: 108,
	cooldownDays: 20,
	betrayDays: 120,
	aiAllianceChance: .05,
	joinWarChance: .2
};
var day = () => Math.floor(S.time / 24);
var fname = (f) => FACTION[f]?.name ?? f;
function treatyBetween(a, b, type) {
	return (S.treaties ?? []).find((t) => (t.a === a && t.b === b || t.a === b && t.b === a) && (!type || t.type === type));
}
function alliesOf(f) {
	return (S.treaties ?? []).filter((t) => t.type === "alliance" && (t.a === f || t.b === f)).map((t) => t.a === f ? t.b : t.a);
}
/** 国力：城池（城镇算 3）与领主兵力 */
function power(f) {
	let p = 0;
	for (const s of settlementList()) if (s.faction === f) p += s.kind === "town" ? 3 : s.kind === "castle" ? 1.5 : .3;
	for (const pt of S.parties) if (pt.faction === f && (pt.kind === "lord" || pt.kind === "hero")) p += healthy(pt.troops) / 80;
	return p;
}
var enemiesOf = (f) => MAJOR_FACTIONS.filter((o) => o !== f && S.alive[o] && atWar(f, o));
var betrayedRecently = (f) => (S.flags?.["betray_" + f] ?? -1e9) > S.time - DIPLO.betrayDays * 24;
var cooling = (a, b) => (S.flags?.["dcool_" + warKey(a, b)] ?? 0) > S.time;
function setCool(a, b, days = DIPLO.cooldownDays) {
	S.flags ??= {};
	S.flags["dcool_" + warKey(a, b)] = S.time + days * 24;
}
function makeTreaty(a, b, type, days, why = "") {
	S.treaties ??= [];
	S.treaties = S.treaties.filter((t) => !(t.a === a && t.b === b || t.a === b && t.b === a));
	const until = S.time + days * 24;
	S.treaties.push({
		a,
		b,
		type,
		since: S.time,
		until
	});
	setWar(a, b, false);
	S.truceUntil[warKey(a, b)] = Math.max(S.truceUntil[warKey(a, b)] ?? 0, until);
	const what = type === "alliance" ? `缔结盟约（${days} 日）` : type === "truce" ? `停战 ${days} 日` : `称臣，${fname(b)}成为${fname(a)}的藩属`;
	log(`${fname(a)}与${fname(b)}${what}${why ? "——" + why : ""}。`, "event");
}
/** 背盟：一方对盟友/宗主宣战 */
function breakTreaty(by, other) {
	const t = treatyBetween(by, other);
	if (!t) return;
	S.treaties = (S.treaties ?? []).filter((x) => x !== t);
	delete S.truceUntil[warKey(by, other)];
	S.flags ??= {};
	S.flags["betray_" + by] = S.time;
	S.flags["revenge_" + other + "_" + by] = S.time + 1440;
	setCool(by, other, DIPLO.betrayDays);
	setWar(by, other, true);
	log(`${fname(by)}背弃盟约，向${fname(other)}开战！天下侧目。`, "event");
}
/** 评估提议（AI 国家决定是否接受）。返回 0~1 的意愿 */
function willingness(from, to, type) {
	if (from === to || !S.alive[to] || !S.alive[from]) return {
		w: 0,
		why: "无从谈起"
	};
	if (cooling(from, to)) return {
		w: 0,
		why: "刚谈崩不久，对方不愿再见使者"
	};
	const pf = power(from), pt = power(to);
	const ef = enemiesOf(from), et = enemiesOf(to);
	const common = ef.filter((x) => et.includes(x));
	const commonThreat = common.reduce((s, x) => s + power(x), 0);
	let w = 0, why = "";
	if (type === "alliance") {
		if (atWar(from, to)) return {
			w: 0,
			why: "两国正在交战，先议和再说"
		};
		if (day() < CFG.allianceOpenDay) return {
			w: 0,
			why: `天下初乱，各国尚无结盟之心（第 ${CFG.allianceOpenDay} 日后开放）`
		};
		w = .1 + Math.min(.6, commonThreat / Math.max(10, pf + pt) * .8);
		if (common.length) why = `同仇敌忾（共同的敌人：${common.map(fname).join("、")}）`;
		if (from === "ming" && (to === "chuang" || to === "xi") || to === "ming" && (from === "chuang" || from === "xi")) {
			w -= .25;
			why += "；官军与流寇积怨甚深";
		}
		if (from === "jin" && to === "mon" || from === "mon" && to === "jin") w += .15;
		if (betrayedRecently(from)) {
			w -= .35;
			why += "；对方记得你国背盟之事";
		}
		if (alliesOf(to).length >= 2) w -= .2;
	} else if (type === "truce" || type === "peace") {
		if (!atWar(from, to)) return {
			w: 0,
			why: "两国并未交战"
		};
		const ratio = pf / Math.max(1, pt);
		w = .15 + (ratio - 1) * .25 + Math.max(0, et.length - 1) * .15;
		if ((S.flags?.["revenge_" + to + "_" + from] ?? 0) > S.time) {
			w -= .4;
			why = "对方誓报背盟之仇";
		}
		if (type === "peace") w -= .1;
		why ||= ratio > 1.3 ? "对方畏惧我国兵威" : et.length > 1 ? "对方四面受敌" : "对方犹豫不决";
	} else if (type === "vassal") {
		const ratio = pf / Math.max(1, pt);
		w = ratio > 3 ? .2 + Math.min(.5, (ratio - 3) * .1) + (et.length > 1 ? .2 : 0) : 0;
		why = ratio > 3 ? "国力悬殊" : "对方尚不至于称臣";
	}
	return {
		w: Math.max(0, Math.min(.95, w)),
		why
	};
}
/** 玩家作为使节提议（renown 越高越有分量，礼金也有帮助） */
function propose(envoyName, envoyRenown, from, to, type, gift) {
	if (type === "war") {
		if (!S.alive[to] || from === to) return {
			ok: false,
			msg: "无从宣战"
		};
		if (atWar(from, to)) return {
			ok: false,
			msg: "已在交战"
		};
		if (envoyRenown < 800) return {
			ok: false,
			msg: "你的声望不足 800，朝廷不会因你一言而开战"
		};
		if (treatyBetween(from, to)) breakTreaty(from, to);
		else {
			setWar(from, to, true);
			log(`在${envoyName}的力主之下，${fname(from)}向${fname(to)}宣战！`, "event");
		}
		return {
			ok: true,
			msg: "宣战诏书已下"
		};
	}
	if (envoyRenown < 150) return {
		ok: false,
		msg: "你声望不足 150，对方不肯接见"
	};
	const { w, why } = willingness(from, to, type);
	const bonus = Math.min(.25, envoyRenown / 8e3) + Math.min(.2, gift / 2e4);
	if (w > 0 && Math.random() < w + bonus) {
		if (type === "alliance") makeTreaty(from, to, "alliance", DIPLO.allianceDays, `${envoyName}出使促成`);
		else if (type === "truce") makeTreaty(from, to, "truce", DIPLO.truceDays, `${envoyName}出使促成`);
		else if (type === "peace") {
			setWar(from, to, false);
			S.truceUntil[warKey(from, to)] = S.time + DIPLO.truceDays * 24;
			log(`${envoyName}奔走斡旋，${fname(from)}与${fname(to)}罢兵议和。`, "event");
		} else if (type === "vassal") makeTreaty(from, to, "vassal", DIPLO.vassalDays, `${envoyName}恩威并施`);
		return {
			ok: true,
			msg: `对方应允了。（${why}）`
		};
	}
	setCool(from, to, 6);
	return {
		ok: false,
		msg: `对方婉拒了。（${why || "时机未到"}）`
	};
}
var acc = 0;
function tickDiplomacy(realSec) {
	acc += realSec * CFG.hoursPerSec;
	if (acc < 24) return;
	acc = 0;
	S.treaties ??= [];
	for (const t of [...S.treaties]) if (t.until <= S.time) {
		S.treaties = S.treaties.filter((x) => x !== t);
		setCool(t.a, t.b);
		log(`${fname(t.a)}与${fname(t.b)}的${t.type === "alliance" ? "盟约" : t.type === "truce" ? "停战之约" : "宗藩关系"}到期了。`, "event");
	}
	for (const t of [...S.treaties]) if (!S.alive[t.a] || !S.alive[t.b]) S.treaties = S.treaties.filter((x) => x !== t);
	for (const t of S.treaties) {
		if (t.type === "truce") continue;
		const pairs = t.type === "alliance" ? [[t.a, t.b], [t.b, t.a]] : [[t.a, t.b]];
		for (const [lead, follow] of pairs) for (const x of enemiesOf(lead)) {
			if (x === follow || atWar(follow, x) || treatyBetween(follow, x)) continue;
			if (Math.random() < (t.type === "vassal" ? .5 : DIPLO.joinWarChance)) {
				setWar(follow, x, true);
				log(`${fname(follow)}应${t.type === "vassal" ? "宗主" : "盟友"}${fname(lead)}之约，对${fname(x)}宣战。`, "event");
			}
		}
	}
	if (day() < CFG.allianceOpenDay) return;
	const alive = MAJOR_FACTIONS.filter((f) => S.alive[f]);
	for (let i = 0; i < alive.length; i++) for (let j = i + 1; j < alive.length; j++) {
		const a = alive[i], b = alive[j];
		if (treatyBetween(a, b) || cooling(a, b)) continue;
		if (!atWar(a, b)) {
			const { w } = willingness(a, b, "alliance");
			if (Math.random() < w * DIPLO.aiAllianceChance) makeTreaty(a, b, "alliance", DIPLO.allianceDays);
		} else {
			const strong = power(a) > power(b) ? a : b, weak = strong === a ? b : a;
			const vw = willingness(strong, weak, "vassal").w;
			if (vw > 0 && Math.random() < vw * .03) makeTreaty(strong, weak, "vassal", DIPLO.vassalDays, `${fname(weak)}力不能支`);
		}
	}
}
//#endregion
//#region server/kingdom.ts
var INDEP = {
	renown: 300,
	troops: 50,
	fiefs: 1,
	emperorCities: 6,
	maxKingdoms: 8
};
var ANCIENT = [
	"beijing",
	"nanjing",
	"xian",
	"luoyang"
];
var BAD = [
	"习",
	"共产",
	"法轮",
	"六四",
	"台独",
	"藏独",
	"疆独"
];
/** 世界载入 / 客户端收到快照时：把玩家建立的国家写回 FACTION 表 */
function installCustomFactions(defs) {
	for (const [id, d] of Object.entries(defs ?? {})) FACTION[id] = d;
}
var fiefsOfAcct = (acct) => settlementList().filter((s) => s.owner === "P:" + acct);
function indepCheck(rec) {
	if (!rec.nation) return "你尚未效忠任何国家";
	if (rec.nation.startsWith("p_") && FACTION[rec.nation]?.ruler === rec.name) return "你已是一国之主";
	if (fiefsOfAcct(rec.name).filter((s) => s.kind !== "village").length < INDEP.fiefs) return `需要至少 ${INDEP.fiefs} 座城堡或城镇作为根基（攻下一座城即可）`;
	if (rec.renown < INDEP.renown) return `声望不足 ${INDEP.renown}，振臂一呼也无人响应`;
	const live = Object.keys(S.customFactions ?? {}).filter((id) => S.alive[id]).length;
	if (live >= INDEP.maxKingdoms) return `天下已有 ${live} 个新立之国，群雄并起已到极限（上限 ${INDEP.maxKingdoms}）`;
	const p = heroOf(rec.name);
	if (!p || healthy(p.troops) < INDEP.troops) return `麾下至少要有 ${INDEP.troops} 名可战之兵`;
	return null;
}
function declareIndependence(rec, a) {
	const why = indepCheck(rec);
	if (why) return {
		ok: false,
		err: why
	};
	const name = String(a.name ?? "").trim();
	const ch = String(a.ch ?? "").trim().slice(0, 1) || name.slice(-1);
	if (!/^[\u4e00-\u9fa5]{1,4}$/.test(name)) return {
		ok: false,
		err: "国号须为 1~4 个汉字"
	};
	if (!/^[\u4e00-\u9fa5]$/.test(ch)) return {
		ok: false,
		err: "旗字须为 1 个汉字"
	};
	if (BAD.some((w) => name.includes(w) || ch.includes(w))) return {
		ok: false,
		err: "国号不合适"
	};
	if (Object.values(FACTION).some((f) => f.name === name)) return {
		ok: false,
		err: "这个国号已经有人用了"
	};
	const color = /^#[0-9a-fA-F]{6}$/.test(a.color) ? a.color : "#d4af37";
	const fiefs = fiefsOfAcct(rec.name);
	const capital = fiefs.find((s) => s.id === a.capital && s.kind !== "village") ?? fiefs.find((s) => s.kind === "town") ?? fiefs.find((s) => s.kind !== "village");
	S.flags ??= {};
	const n = Number(S.flags.customN ?? 0) + 1;
	S.flags.customN = n;
	const id = `p_${n}`;
	const old = rec.nation;
	const def = {
		id,
		name,
		color: parseInt(color.slice(1), 16),
		css: color,
		culture: FACTION[old]?.culture ?? "ming",
		ruler: rec.name,
		rulerTitle: "王",
		capital: capital.id,
		desc: `${rec.name}于${capital.name}起兵自立，国号“${name}”${a.era ? `，建元“${String(a.era).slice(0, 4)}”` : ""}。`
	};
	S.customFactions ??= {};
	S.customFactions[id] = def;
	FACTION[id] = def;
	S.alive[id] = true;
	for (const s of fiefs) if (s.kind !== "village") setOwner(s, id, "P:" + rec.name);
	for (const s of fiefs) if (s.kind === "village") s.faction = id;
	const p = heroOf(rec.name);
	if (p) p.faction = id;
	rec.nation = id;
	rec.rank = 99;
	rec.playerRel[old] = Math.min(rec.playerRel[old] ?? 0, -40);
	setWar(id, old, true);
	for (const f of MAJOR_FACTIONS) if (f !== old && S.alive[f] && atWar(f, old) && Math.random() < .5) S.truceUntil[[f, id].sort().join("|")] = S.time + 240;
	(S.chronLog ??= []).push({
		n: `${rec.name}自立为${name}王`,
		at: S.time
	});
	log(`【天下震动】${rec.name}于${capital.name}自立为王，国号“${name}”！${FACTION[old]?.name ?? ""}兴兵讨伐。`, "event");
	OUT.broadcast({
		t: "chat",
		ch: "gm",
		who: "天下",
		text: `${rec.name}于${capital.name}自立为王，国号“${name}”！`,
		at: Date.now()
	});
	return {
		ok: true,
		data: {
			id,
			def
		}
	};
}
function proclaimEmperor(rec) {
	const f = rec.nation;
	if (!f || !f.startsWith("p_") || FACTION[f]?.ruler !== rec.name) return {
		ok: false,
		err: "须先自立为王"
	};
	if (FACTION[f].rulerTitle === "皇帝") return {
		ok: false,
		err: "你已是皇帝"
	};
	const cities = settlementList().filter((s) => s.faction === f && s.kind !== "village").length;
	if (cities < INDEP.emperorCities) return {
		ok: false,
		err: `城池须达 ${INDEP.emperorCities} 座方可称帝（现有 ${cities}）`
	};
	const legit = settlementList().filter((s) => s.faction === f && ANCIENT.includes(s.id)).map((s) => s.name);
	FACTION[f].rulerTitle = "皇帝";
	S.customFactions[f].rulerTitle = "皇帝";
	S.flags ??= {};
	S.flags["legit_" + f] = legit.length;
	(S.chronLog ??= []).push({
		n: `${rec.name}称帝，国号${FACTION[f].name}`,
		at: S.time
	});
	log(`【改天换地】${rec.name}登基称帝，国号“${FACTION[f].name}”！${legit.length ? `坐拥古都${legit.join("、")}，天下归心者众。` : ""}`, "event");
	for (const o of MAJOR_FACTIONS) if (S.alive[o] && !atWar(o, f) && Math.random() < (legit.length ? .25 : .4)) {
		setWar(o, f, true);
		delete S.truceUntil[[o, f].sort().join("|")];
		log(`${FACTION[o].name}不认新朝，对${FACTION[f].name}宣战！`, "event");
	}
	OUT.broadcast({
		t: "chat",
		ch: "gm",
		who: "天下",
		text: `${rec.name}登基称帝，国号“${FACTION[f].name}”！`,
		at: Date.now()
	});
	return { ok: true };
}
/** 国主招揽：邀请 / 接受 */
var invites = /* @__PURE__ */ new Map();
function invite(rec, target, targetRec) {
	const f = rec.nation;
	if (!f || FACTION[f]?.ruler !== rec.name) return {
		ok: false,
		err: "只有国主才能招揽"
	};
	if (!targetRec) return {
		ok: false,
		err: "对方不在线"
	};
	if (targetRec.nation === f) return {
		ok: false,
		err: "对方已是你的臣属"
	};
	invites.set(target, {
		from: rec.name,
		faction: f,
		at: Date.now()
	});
	OUT.send(target, {
		t: "gm",
		text: `INVITE|${rec.name}|${f}|${FACTION[f].name}`
	});
	return { ok: true };
}
function acceptInvite(rec) {
	const iv = invites.get(rec.name);
	if (!iv || Date.now() - iv.at > 3e5 || !S.alive[iv.faction]) return {
		ok: false,
		err: "邀请已失效"
	};
	invites.delete(rec.name);
	const old = rec.nation;
	rec.nation = iv.faction;
	const p = heroOf(rec.name);
	if (p) p.faction = iv.faction;
	for (const s of fiefsOfAcct(rec.name)) setOwner(s, iv.faction, "P:" + rec.name);
	if (old && old !== iv.faction && !old.startsWith("p_")) rec.playerRel[old] = Math.min(rec.playerRel[old] ?? 0, -20);
	log(`${rec.name}投奔${FACTION[iv.faction].name}，归于${iv.from}麾下。`, "event");
	return {
		ok: true,
		data: {
			faction: iv.faction,
			def: FACTION[iv.faction]
		}
	};
}
/** 每隔几秒：玩家国家的流亡计时（失城 → 流亡 → 光复 / 断绝） */
function kingdomTick() {
	for (const id of Object.keys(S.customFactions ?? {})) if (S.alive[id]) checkFactionAlive(id);
}
//#endregion
//#region src/art/canvas.ts
/** 可复现的伪随机 */
function srand(seed) {
	let s = seed * 2654435761 >>> 0 || 1;
	return () => {
		s ^= s << 13;
		s >>>= 0;
		s ^= s >> 17;
		s ^= s << 5;
		s >>>= 0;
		return s / 4294967296;
	};
}
var FIELD_DIMS = [
	[1800, 1150],
	[2400, 1550],
	[3e3, 1950],
	[3600, 2300],
	[4400, 2800]
];
function sizeFor(total, siege) {
	let s = total <= 90 ? 0 : total <= 220 ? 1 : total <= 420 ? 2 : total <= 680 ? 3 : 4;
	if (siege && s === 0) s = 1;
	return s;
}
var BattleField = class {
	constructor(W, H, terrain, seed, siege) {
		this.hills = [];
		this.river = null;
		this.groves = [];
		this.boxes = [];
		this.siege = null;
		this.version = 1;
		this.fields = /* @__PURE__ */ new Map();
		this.tick = 0;
		this.W = W;
		this.H = H;
		this.terrain = terrain;
		this.seed = seed;
		this.gw = Math.ceil(W / 16);
		this.gh = Math.ceil(H / 16);
		this.block = new Uint8Array(this.gw * this.gh);
		this.wood = new Uint8Array(this.gw * this.gh);
		this.slowC = new Uint8Array(this.gw * this.gh).fill(100);
		this.hasRoad = terrain !== Ter.Forest || !!siege;
		const R = srand(seed * 7 + 13);
		if (siege) this.makeSiege(siege.town, R);
		this.makeHills(R);
		if (!siege) this.makeRiver(R);
		this.makeGroves(R);
		if (!siege) this.makeHamlet(R);
		this.rasterize();
	}
	roadY(x) {
		return this.H * .5 + Math.sin(x * .0032 + this.seed) * 90 + Math.sin(x * .009) * 24;
	}
	makeHills(R) {
		const t = this.terrain;
		const n = t === Ter.Hills ? 6 : t === Ter.Mountain ? 7 : t === Ter.Plateau ? 4 : t === Ter.Desert ? 5 : t === Ter.Steppe ? 2 : t === Ter.Forest ? 2 : 3;
		const scale = this.W / 1800;
		for (let i = 0; i < n; i++) {
			const big = t === Ter.Mountain || t === Ter.Hills;
			const r = (big ? 160 + R() * 220 : 180 + R() * 260) * Math.sqrt(scale);
			const h = big ? 34 + R() * 36 : t === Ter.Desert ? 14 + R() * 16 : 16 + R() * 26;
			let x = this.W * (.12 + R() * .76), y = this.H * (.1 + R() * .8);
			if (this.siege) x = Math.min(x, this.siege.wallX - 360);
			this.hills.push({
				x,
				y,
				r,
				h
			});
		}
		if (R() < .6 && !this.siege) {
			const side = R() < .5 ? .24 : .76;
			this.hills.push({
				x: this.W * side,
				y: this.H * (.3 + R() * .4),
				r: 220 * Math.sqrt(scale),
				h: 26 + R() * 18
			});
		}
	}
	makeRiver(R) {
		const t = this.terrain;
		const p = t === Ter.Plain ? .42 : t === Ter.Hills ? .3 : t === Ter.Forest ? .25 : t === Ter.Steppe ? .2 : t === Ter.Mountain ? .22 : 0;
		if (R() >= p) return;
		const ns = R() < .6;
		const w = 46 + R() * 26;
		if (ns) {
			const c = this.W * (.47 + (R() - .5) * .1);
			const rv = {
				ns,
				c,
				w,
				a1: 50 + R() * 50,
				f1: .002 + R() * .002,
				p1: R() * 6,
				a2: 14 + R() * 12,
				f2: .009,
				p2: 0,
				fords: [],
				bridge: null
			};
			rv.fords.push({
				x: 0,
				y: this.H * (.18 + R() * .14),
				r: 58 + R() * 18
			});
			rv.fords.push({
				x: 0,
				y: this.H * (.68 + R() * .14),
				r: 58 + R() * 18
			});
			for (const f of rv.fords) f.x = this.riverPos(rv, f.y);
			if (this.hasRoad) {
				const by = this.roadY(c);
				rv.bridge = {
					x: this.riverPos(rv, by),
					y: by
				};
			} else if (R() < .5) rv.fords.push({
				x: 0,
				y: this.H * .5,
				r: 50
			});
			for (const f of rv.fords) f.x = this.riverPos(rv, f.y);
			this.river = rv;
		} else {
			const top = R() < .5;
			const c = this.H * (top ? .1 + R() * .06 : .84 + R() * .06);
			this.river = {
				ns,
				c,
				w: w + 10,
				a1: 30 + R() * 30,
				f1: .002 + R() * .002,
				p1: R() * 6,
				a2: 10,
				f2: .008,
				fords: [],
				bridge: null
			};
		}
	}
	/** 河道中心：ns 时返回给定 y 处的 x；否则返回给定 x 处的 y */
	riverPos(rv, s) {
		return rv.c + Math.sin(s * rv.f1 + rv.p1) * rv.a1 + Math.sin(s * rv.f2) * rv.a2;
	}
	/** 0 = 不在河中；1 = 深水；2 = 浅滩/桥 */
	waterAt(x, y) {
		const rv = this.river;
		if (!rv) return 0;
		if ((rv.ns ? Math.abs(x - this.riverPos(rv, y)) : Math.abs(y - this.riverPos(rv, x))) > rv.w / 2) return 0;
		for (const f of rv.fords) if (Math.hypot(x - f.x, y - f.y) < f.r) return 2;
		if (rv.bridge && Math.abs(y - rv.bridge.y) < 22 && rv.ns) return 3;
		return 1;
	}
	makeGroves(R) {
		const t = this.terrain;
		const n = t === Ter.Forest ? 11 : t === Ter.Hills ? 4 : t === Ter.Plain ? 3 : t === Ter.Mountain ? 4 : t === Ter.Steppe ? 1 : t === Ter.Plateau ? 1 : 0;
		const k = Math.round(n * (this.W * this.H) / 372e4);
		for (let i = 0; i < k; i++) for (let tries = 0; tries < 10; tries++) {
			const r = (t === Ter.Forest ? 130 : 90) + R() * 110;
			const x = this.W * (.06 + R() * .88), y = this.H * (.06 + R() * .88);
			if (Math.abs(y - this.H / 2) < this.H * .18 && (x < this.W * .3 || x > this.W * .7) && tries < 8) continue;
			if (this.siege && x > this.siege.wallX - 260) continue;
			if (this.river && this.waterAt(x, y)) continue;
			this.groves.push({
				x,
				y,
				r
			});
			break;
		}
	}
	makeHamlet(R) {
		const t = this.terrain;
		if (!(t === Ter.Plain || t === Ter.Hills || t === Ter.Steppe) || R() > .4) return;
		const cx = this.W * (.38 + R() * .24), cy = this.H * (R() < .5 ? .24 : .72);
		const n = 4 + Math.floor(R() * 4);
		for (let i = 0; i < n; i++) for (let k = 0; k < 12; k++) {
			const x = cx + (R() - .5) * 300, y = cy + (R() - .5) * 200;
			const b = {
				x,
				y,
				w: 50,
				h: 34,
				kind: 4
			};
			if (this.boxes.some((o) => Math.abs(o.x - x) < 70 && Math.abs(o.y - y) < 54)) continue;
			if (this.waterAt(x, y)) continue;
			this.boxes.push(b);
			break;
		}
	}
	makeSiege(town, R) {
		const cityW = town ? 760 : 600;
		const wallX = this.W - cityW;
		const gm = Math.round(this.H / 2);
		const g = {
			wallX,
			gateY0: gm - 56,
			gateY1: gm + 56,
			gateMid: gm,
			sections: [],
			stairs: [],
			towers: [],
			town
		};
		const hp = town ? 900 : 700;
		const L = 120;
		for (let y = 30; y + L <= g.gateY0 - 50; y += L) g.sections.push({
			y0: y,
			y1: y + L,
			hp,
			max: hp,
			broken: false
		});
		for (let y = g.gateY1 + 50; y + L <= this.H - 30; y += L) g.sections.push({
			y0: y,
			y1: y + L,
			hp,
			max: hp,
			broken: false
		});
		for (let y = 230; y < this.H - 120; y += 330) if (Math.abs(y - gm) > 140) g.stairs.push(y);
		if (g.stairs.length < 2) g.stairs = [gm - 260, gm + 260];
		for (let y = 150; y < this.H - 80; y += 280) if (Math.abs(y - gm) > 120) g.towers.push(y);
		this.siege = g;
		const n = town ? 60 : 32;
		for (let i = 0; i < n; i++) {
			const x = wallX + 110 + R() * (cityW - 150), y = 40 + R() * (this.H - 80);
			if (Math.abs(y - gm) < 110 && x < wallX + 420) continue;
			if (Math.abs(y - gm) < 60) continue;
			if (g.stairs.some((s) => Math.abs(y - s) < 70 && x < wallX + 160)) continue;
			if (x < wallX + 140) continue;
			if (this.boxes.some((o) => Math.abs(o.x - x) < 70 && Math.abs(o.y - y) < 56)) continue;
			this.boxes.push({
				x,
				y,
				w: 50,
				h: 34,
				kind: 4
			});
		}
	}
	rasterize() {
		const { gw, gh } = this;
		this.block.fill(0);
		this.slowC.fill(100);
		this.wood.fill(0);
		for (let cy = 0; cy < gh; cy++) for (let cx = 0; cx < gw; cx++) {
			const x = cx * 16 + 8, y = cy * 16 + 8, i = cy * gw + cx;
			const w = this.waterAt(x, y);
			if (w === 1) this.block[i] = 1;
			else if (w === 2) this.slowC[i] = 55;
			for (const gr of this.groves) if (Math.hypot(x - gr.x, y - gr.y) < gr.r) {
				this.wood[i] = 1;
				break;
			}
		}
		for (const b of this.boxes) this.fillRect(b.x - b.w / 2, b.y - b.h * .85, b.w, b.h * .8, b.kind);
		const sg = this.siege;
		if (sg) {
			this.fillRect(sg.wallX - 14, 0, 28, this.H, 2);
			this.fillRect(sg.wallX - 14, sg.gateY0, 28, sg.gateY1 - sg.gateY0, 3);
			for (const s of sg.sections) if (s.broken) this.openBreach(s, false);
		}
	}
	fillRect(x, y, w, h, v) {
		const x0 = Math.max(0, Math.floor(x / 16)), x1 = Math.min(this.gw - 1, Math.floor((x + w - 1) / 16));
		const y0 = Math.max(0, Math.floor(y / 16)), y1 = Math.min(this.gh - 1, Math.floor((y + h - 1) / 16));
		for (let cy = y0; cy <= y1; cy++) for (let cx = x0; cx <= x1; cx++) this.block[cy * this.gw + cx] = v;
	}
	openGate() {
		const sg = this.siege;
		const x0 = Math.floor((sg.wallX - 14) / 16), x1 = Math.floor((sg.wallX + 13) / 16);
		for (let cy = Math.floor(sg.gateY0 / 16); cy <= Math.floor((sg.gateY1 - 1) / 16); cy++) for (let cx = x0; cx <= x1; cx++) {
			const i = cy * this.gw + cx;
			if (this.block[i] === 3) {
				this.block[i] = 0;
				this.slowC[i] = 80;
			}
		}
		this.version++;
	}
	openBreach(s, bump = true) {
		const sg = this.siege;
		s.broken = true;
		const x0 = Math.floor((sg.wallX - 14) / 16), x1 = Math.floor((sg.wallX + 13) / 16);
		for (let cy = Math.floor((s.y0 + 22) / 16); cy <= Math.floor((s.y1 - 22) / 16); cy++) for (let cx = x0 - 1; cx <= x1 + 1; cx++) {
			const i = cy * this.gw + cx;
			if (i < 0 || i >= this.block.length) continue;
			if (this.block[i] === 2) this.block[i] = 0;
			this.slowC[i] = 60;
		}
		if (bump) this.version++;
	}
	gateOpen() {
		const sg = this.siege;
		if (!sg) return true;
		return this.block[Math.floor(sg.gateMid / 16) * this.gw + Math.floor(sg.wallX / 16)] !== 3;
	}
	/** 城墙上有通道（城门或缺口） */
	passages() {
		const sg = this.siege;
		if (!sg) return [];
		const out = [];
		if (this.gateOpen()) out.push({
			x: sg.wallX,
			y: sg.gateMid
		});
		for (const s of sg.sections) if (s.broken) out.push({
			x: sg.wallX,
			y: (s.y0 + s.y1) / 2
		});
		return out;
	}
	cell(x, y) {
		const cx = Math.max(0, Math.min(this.gw - 1, Math.floor(x / 16)));
		return Math.max(0, Math.min(this.gh - 1, Math.floor(y / 16))) * this.gw + cx;
	}
	blocked(x, y) {
		if (x < 0 || y < 0 || x >= this.W || y >= this.H) return true;
		return this.block[this.cell(x, y)] !== 0;
	}
	inWood(x, y) {
		return this.wood[this.cell(x, y)] === 1;
	}
	heightAt(x, y) {
		let h = 0;
		for (const hl of this.hills) {
			const dx = x - hl.x, dy = y - hl.y;
			const d2 = (dx * dx + dy * dy) / (hl.r * hl.r);
			if (d2 < 6) h += hl.h * Math.exp(-d2 * 1.6);
		}
		return h;
	}
	/** 移动速度系数 */
	speedAt(x, y, mounted) {
		const i = this.cell(x, y);
		let k = this.slowC[i] / 100;
		if (this.wood[i]) k *= mounted ? .62 : .82;
		return k;
	}
	/** 直线是否通畅（无障碍） */
	clearLine(x0, y0, x1, y1) {
		const d = Math.hypot(x1 - x0, y1 - y0);
		const n = Math.ceil(d / 8);
		for (let i = 1; i <= n; i++) {
			const t = i / n;
			if (this.block[this.cell(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)] !== 0) return false;
		}
		return true;
	}
	nearestFree(x, y) {
		if (!this.blocked(x, y)) return [x, y];
		for (let r = 16; r < 400; r += 16) for (let a = 0; a < 16; a++) {
			const px = x + Math.cos(a / 16 * Math.PI * 2) * r, py = y + Math.sin(a / 16 * Math.PI * 2) * r;
			if (!this.blocked(px, py)) return [px, py];
		}
		return [x, y];
	}
	/** 流场：返回从 (x,y) 走向 (tx,ty) 的下一个路点；不可达时返回 null */
	next(x, y, tx, ty) {
		const [gx, gy] = this.nearestFree(tx, ty);
		const gcx = Math.floor(gx / 16 / 3), gcy = Math.floor(gy / 16 / 3);
		const key = gcy * 1e3 + gcx;
		let f = this.fields.get(key);
		this.tick++;
		if (!f || f.v !== this.version) {
			f = {
				d: this.bfs(Math.min(this.gw - 1, gcx * 3 + 1), Math.min(this.gh - 1, gcy * 3 + 1), gx, gy),
				v: this.version,
				t: this.tick
			};
			this.fields.set(key, f);
			if (this.fields.size > 64) {
				let ok = -1, ot = Infinity;
				for (const [k, v] of this.fields) if (v.t < ot) {
					ot = v.t;
					ok = k;
				}
				this.fields.delete(ok);
			}
		}
		f.t = this.tick;
		const d = f.d, gw = this.gw;
		let c = this.cell(x, y);
		if (d[c] === 65535) {
			let best = -1, bd = 65535;
			const cx0 = c % gw, cy0 = c / gw | 0;
			for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
				const nx = cx0 + ox, ny = cy0 + oy;
				if (nx < 0 || ny < 0 || nx >= gw || ny >= this.gh) continue;
				const j = ny * gw + nx;
				if (d[j] < bd) {
					bd = d[j];
					best = j;
				}
			}
			if (best < 0) return null;
			c = best;
		}
		let cur = c;
		for (let step = 0; step < 4; step++) {
			const cx = cur % gw, cy = cur / gw | 0;
			let best = cur, bd = d[cur];
			for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
				if (!ox && !oy) continue;
				const nx = cx + ox, ny = cy + oy;
				if (nx < 0 || ny < 0 || nx >= gw || ny >= this.gh) continue;
				if (ox && oy && (this.block[cy * gw + nx] || this.block[ny * gw + cx])) continue;
				const j = ny * gw + nx;
				if (d[j] < bd) {
					bd = d[j];
					best = j;
				}
			}
			if (best === cur) break;
			cur = best;
		}
		if (cur === c && d[c] > 1) return null;
		return [cur % gw * 16 + 8, (cur / gw | 0) * 16 + 8];
	}
	bfs(cx, cy, gx, gy) {
		const { gw, gh } = this;
		const d = new Uint16Array(gw * gh).fill(65535);
		const q = new Int32Array(gw * gh);
		let s = this.cell(gx, gy);
		if (this.block[s]) s = cy * gw + cx;
		let qh = 0, qt = 0;
		d[s] = 0;
		q[qt++] = s;
		while (qh < qt) {
			const c = q[qh++], x = c % gw, y = c / gw | 0, nd = d[c] + 1;
			if (x > 0) {
				const j = c - 1;
				if (d[j] === 65535 && !this.block[j]) {
					d[j] = nd;
					q[qt++] = j;
				}
			}
			if (x < gw - 1) {
				const j = c + 1;
				if (d[j] === 65535 && !this.block[j]) {
					d[j] = nd;
					q[qt++] = j;
				}
			}
			if (y > 0) {
				const j = c - gw;
				if (d[j] === 65535 && !this.block[j]) {
					d[j] = nd;
					q[qt++] = j;
				}
			}
			if (y < gh - 1) {
				const j = c + gw;
				if (d[j] === 65535 && !this.block[j]) {
					d[j] = nd;
					q[qt++] = j;
				}
			}
		}
		return d;
	}
};
//#endregion
//#region src/battle/wire.ts
var Writer = class {
	constructor(n = 4096) {
		this.pos = 0;
		this.buf = new Uint8Array(n);
		this.dv = new DataView(this.buf.buffer);
	}
	reset() {
		this.pos = 0;
	}
	need(n) {
		if (this.pos + n <= this.buf.length) return;
		let m = this.buf.length * 2;
		while (m < this.pos + n) m *= 2;
		const b = new Uint8Array(m);
		b.set(this.buf);
		this.buf = b;
		this.dv = new DataView(b.buffer);
	}
	u8(v) {
		this.need(1);
		this.buf[this.pos++] = v & 255;
	}
	i8(v) {
		this.need(1);
		this.dv.setInt8(this.pos++, v);
	}
	u16(v) {
		this.need(2);
		this.dv.setUint16(this.pos, v & 65535, true);
		this.pos += 2;
	}
	setU16(at, v) {
		this.dv.setUint16(at, v & 65535, true);
	}
	u32(v) {
		this.need(4);
		this.dv.setUint32(this.pos, v >>> 0, true);
		this.pos += 4;
	}
	/** 拷贝出本帧（可安全转交给 worker/socket） */
	bytes() {
		return this.buf.slice(0, this.pos);
	}
};
//#endregion
//#region src/battle/core.ts
var SWING = .32;
var GAPS = [
	900,
	1050,
	1200,
	1350,
	1550
];
var TICK = .05;
var KIND_N = {
	bow: 0,
	xbow: 1,
	gun: 2
};
/** 单个玩家的下行状态：已发送的单位状态（增量编码）与可见区域 */
var Viewer = class {
	constructor(cmd) {
		this.cmd = cmd;
		this.lx = /* @__PURE__ */ new Int32Array(256);
		this.ly = /* @__PURE__ */ new Int32Array(256);
		this.lf = /* @__PURE__ */ new Uint8Array(256);
		this.lh = /* @__PURE__ */ new Uint8Array(256);
		this.ls = /* @__PURE__ */ new Uint8Array(256);
		this.lt = /* @__PURE__ */ new Int32Array(256);
		this.known = /* @__PURE__ */ new Uint8Array(256);
		this.bytes = 0;
		this.frames = 0;
	}
	grow(n) {
		if (n < this.lx.length) return;
		let m = this.lx.length;
		while (m <= n) m *= 2;
		const g = (a) => {
			const b = new a.constructor(m);
			b.set(a);
			return b;
		};
		this.lx = g(this.lx);
		this.ly = g(this.ly);
		this.lf = g(this.lf);
		this.lh = g(this.lh);
		this.ls = g(this.ls);
		this.lt = g(this.lt);
		this.known = g(this.known);
	}
	reset() {
		this.known.fill(0);
	}
};
var BattleCore = class {
	constructor(opts, initialTotal) {
		this.opts = opts;
		this.units = [];
		this.byUid = [];
		this.reserves = [[], []];
		this.projs = [];
		this.squads = [];
		this.aiSq = [null, null];
		this.cmds = /* @__PURE__ */ new Map();
		this.parties = /* @__PURE__ */ new Map();
		this.initial = [0, 0];
		this.down = [{}, {}];
		this.downPid = {};
		this.killsBy = {};
		this.fledPid = {};
		this.elapsed = 0;
		this.tick = 0;
		this.lastHit = 0;
		this.uidSeq = 1;
		this.sqSeq = 1;
		this.aiT = 0;
		this.reinforceT = 0;
		this.statT = 0;
		this.finished = false;
		this.result = null;
		this.baseX = [0, 0];
		this.grid = /* @__PURE__ */ new Map();
		this.foes = [[], []];
		this.evs = [];
		this.out = [];
		this.spawned = [];
		this.started = false;
		this.bandit = [false, false];
		this.wr = new Writer(8192);
		const cap = Math.max(60, Math.min(1e3, opts.cap));
		const size = sizeFor(Math.min(cap, initialTotal), false);
		[this.W, this.H] = FIELD_DIMS[size];
		this.F = new BattleField(this.W, this.H, opts.terrain, opts.seed, null);
		const gap = GAPS[size] ?? 1e3;
		this.baseX = [this.W / 2 - gap / 2, this.W / 2 + gap / 2];
	}
	/** 开场时的布阵信息（发给每个加入的玩家） */
	initMsg(acct) {
		const c = this.cmds.get(acct);
		return {
			W: this.W,
			H: this.H,
			seed: this.opts.seed,
			terrain: this.opts.terrain,
			night: this.opts.night,
			side: c?.side ?? 0,
			pid: c?.pid ?? "",
			hero: c?.hero?.uid ?? 0,
			cs: c?.corrSeq ?? 0,
			hx: c?.hero?.x ?? 0,
			hy: c?.hero?.y ?? 0,
			hammo: c?.hero?.ammo ?? 0,
			parties: [...this.parties.values()].map((p) => ({
				pid: p.pid,
				name: p.name,
				side: p.side,
				faction: p.faction,
				acct: p.acct ?? null,
				online: !!(p.acct && this.cmds.get(p.acct)?.online),
				look: p.hero?.look ?? null,
				god: p.god?.aura ? 1 : 0
			})),
			sq: c ? [
				"inf",
				"rng",
				"cav"
			].map((g) => [
				g,
				c.sq[g].order,
				c.sq[g].form,
				c.sq[g].ax,
				c.sq[g].ay
			]) : [],
			units: this.units.filter((u) => !u.dead && !u.fled).map((u) => this.spawnInfo(u)),
			t: Math.round(this.elapsed * 1e3),
			tick: this.tick
		};
	}
	spawnInfo(u) {
		return [
			u.uid,
			u.side,
			u.pid,
			u.troop ?? "",
			u.comp ?? "",
			Math.round(u.x),
			Math.round(u.y),
			(u.hero ? 1 : 0) | (u.mounted ? 2 : 0) | (u.rng > 0 ? 4 : 0),
			Math.round(u.maxHp),
			u.god,
			u.hero ? u.name : "",
			Math.round(u.range),
			u.ammo
		];
	}
	/** 开战前加入的各部（一次性布阵） */
	start(parts) {
		const ents = [[], []];
		const blocks = [[], []];
		for (const p of parts) {
			this.parties.set(p.pid, p);
			if (p.bandit) this.bandit[p.side] = true;
			const cmd = p.acct && p.hero ? this.makeCmd(p) : null;
			ents[p.side].push(...this.expand(p, cmd));
			if (cmd) blocks[p.side].push(p);
			this.initial[p.side] += this.healthyOf(p.stacks) + (p.hero ? 1 : 0) + (p.comps?.length ?? 0);
		}
		for (const s of [0, 1]) ents[s].sort((a, b) => a.k - b.k);
		const cap = Math.max(60, Math.min(1e3, this.opts.cap));
		const heroes = [0, 1].map((s) => parts.filter((p) => p.side === s).reduce((n, p) => n + (p.hero ? 1 + (p.comps?.length ?? 0) : 0), 0));
		const n0 = ents[0].length + heroes[0], n1 = ents[1].length + heroes[1];
		const cap0 = Math.min(n0, Math.max(Math.round(cap * Math.max(.3, Math.min(.7, n0 / Math.max(1, n0 + n1)))), cap - n1));
		const cap1 = Math.min(n1, cap - cap0);
		const caps = [Math.max(0, cap0 - heroes[0]), Math.max(0, cap1 - heroes[1])];
		for (const side of [0, 1]) {
			const hasAI = parts.some((p) => p.side === side && !(p.acct && p.hero));
			const humans = blocks[side];
			const slots = humans.length + (hasAI ? 1 : 0);
			const H = this.H;
			const spacing = Math.min(300, H * .7 / Math.max(1, slots));
			const oyOf = (i) => i === 0 ? 0 : (i % 2 ? -1 : 1) * Math.ceil(i / 2) * spacing;
			let i = 0;
			for (const p of humans) {
				const c = this.cmds.get(p.acct);
				this.placeCmdSquads(c, oyOf(i++));
			}
			if (hasAI) this.makeAiSquads(side, oyOf(i++), humans.length > 0);
		}
		for (const side of [0, 1]) {
			const field = ents[side].slice(0, caps[side]);
			this.reserves[side] = ents[side].slice(field.length);
			for (const e of field) this.addUnit(this.makeUnit(side, e.id, e.pid, e.cmd));
		}
		for (const c of this.cmds.values()) this.spawnHeroAndComps(c, false);
		for (const sq of this.squads) {
			this.faceEnemy(sq);
			this.computeSlots(sq);
			for (const u of sq.members) {
				u.x = u.slotX + (Math.random() - .5) * 3;
				u.y = u.slotY + (Math.random() - .5) * 3;
			}
		}
		for (const c of this.cmds.values()) if (c.hero) {
			const inf = c.sq.inf;
			c.hero.x = inf.ax + (c.side === 0 ? -50 : 50);
			c.hero.y = inf.ay;
			c.hero.face = c.side === 0 ? 0 : Math.PI;
		}
		for (const u of this.units) {
			const [x, y] = this.F.nearestFree(u.x, u.y);
			u.x = x;
			u.y = y;
		}
		for (const sq of this.squads) sq.members.sort((a, b) => a.uid - b.uid);
		this.spawned = [];
		this.started = true;
	}
	/** 战斗进行中有人加入：英雄与先头部队从本方战场边缘赶到，其余进入预备队 */
	join(p) {
		if (this.parties.has(p.pid)) return false;
		this.parties.set(p.pid, p);
		if (p.bandit) this.bandit[p.side] = true;
		const cmd = p.acct && p.hero ? this.makeCmd(p) : null;
		const ents = this.expand(p, cmd);
		this.initial[p.side] += ents.length + (p.hero ? 1 : 0) + (p.comps?.length ?? 0);
		const [ex, ey] = this.spawnPoint(p.side);
		if (cmd) {
			const dir = p.side === 0 ? 1 : -1;
			const mk = (g, dx, dy) => this.newSquad(p.side, g, null, ex + dir * dx, ey + dy);
			cmd.sq = {
				inf: mk("inf", 60, 0),
				rng: mk("rng", 130, 0),
				cav: mk("cav", 20, 120)
			};
			for (const g of [
				"inf",
				"rng",
				"cav"
			]) cmd.sq[g].owner = cmd;
			cmd.sq.cav.form = "wedge";
			this.spawnHeroAndComps(cmd, true, ex, ey);
		} else if (!this.aiSq[p.side]) this.makeAiSquads(p.side, ey - this.H / 2, true);
		const cap = Math.max(60, Math.min(1e3, this.opts.cap));
		const alive = this.units.filter((u) => u.side === p.side && !u.dead && !u.fled).length;
		const room = Math.max(0, Math.min(ents.length, Math.round(cap * .5 * 1.15) - alive, 80));
		for (let i = 0; i < room; i++) {
			const e = ents[i];
			const u = this.makeUnit(p.side, e.id, e.pid, e.cmd);
			const [sx, sy] = this.F.nearestFree(ex + (Math.random() - .5) * 80, ey + (Math.random() - .5) * 160);
			u.x = sx;
			u.y = sy;
			this.addUnit(u);
		}
		const res = this.reserves[p.side];
		for (let i = room; i < ents.length; i++) res.splice(Math.floor(Math.random() * (res.length + 1)), 0, ents[i]);
		for (const sq of this.squads) if (sq.side === p.side) {
			if (cmd && sq.owner === cmd) this.faceEnemy(sq);
			this.computeSlots(sq);
		}
		this.say(null, `${p.name}率部${cmd ? "" : ""}加入了战斗（${ents.length + (p.hero ? 1 : 0)} 人）！`);
		return true;
	}
	makeCmd(p) {
		const c = {
			acct: p.acct,
			pid: p.pid,
			side: p.side,
			name: p.name,
			hero: null,
			sq: null,
			online: !!p.online,
			left: false,
			god: p.god ?? null,
			morale: p.morale ?? 70,
			leadership: p.leadership ?? 0,
			inp: null,
			lastAtk: -1,
			lastFire: -1,
			budget: 0,
			corr: false,
			corrSeq: 0,
			corrT: 0,
			heroDown: false,
			compDown: [],
			view: {
				x: 0,
				y: 0,
				w: 1400,
				h: 900
			},
			viewer: null,
			offlineT: 0
		};
		c.viewer = new Viewer(c);
		this.cmds.set(c.acct, c);
		return c;
	}
	placeCmdSquads(c, oy) {
		const side = c.side, dir = side === 0 ? 1 : -1, bx = this.baseX[side], cy = this.H / 2 + oy;
		const inf = this.newSquad(side, "inf", c, bx, cy);
		const rng = this.newSquad(side, "rng", c, bx + dir * 70, cy);
		const cav = this.newSquad(side, "cav", c, bx - dir * 40, cy + (oy < 0 ? -1 : 1) * Math.min(260, this.H * .18));
		cav.form = "wedge";
		c.sq = {
			inf,
			rng,
			cav
		};
	}
	makeAiSquads(side, oy, withHumans) {
		const dir = side === 0 ? 1 : -1, bx = this.baseX[side] - (withHumans ? dir * 140 : 0), cy = this.H / 2;
		let ix = bx, iy = cy + oy;
		const hill = this.F.hills.filter((h) => Math.abs(h.x - bx) < this.W * .2 && h.h > 18 && Math.abs(h.y - iy) < this.H * .25).sort((a, b) => b.h - a.h)[0];
		if (hill && !withHumans) {
			ix = hill.x;
			iy = hill.y;
		}
		const inf = this.newSquad(side, "inf", null, ix, iy);
		const rng = this.newSquad(side, "rng", null, ix + dir * 70, iy);
		const cavs = [this.newSquad(side, "cav", null, bx - dir * 50, cy - 300 + oy), this.newSquad(side, "cav", null, bx - dir * 50, cy + 300 + oy)];
		cavs[0].flank = -1;
		cavs[1].flank = 1;
		inf.form = Math.random() < .4 ? "block" : "line";
		this.aiSq[side] = {
			inf,
			rng,
			cavs
		};
	}
	newSquad(side, g, owner, ax, ay) {
		const sq = {
			id: this.sqSeq++,
			side,
			ai: !owner,
			owner,
			g,
			order: "hold",
			form: g === "cav" ? "wedge" : "line",
			ax,
			ay,
			face: side === 0 ? 0 : Math.PI,
			members: [],
			phase: 0
		};
		const [fx, fy] = this.F.nearestFree(Math.max(30, Math.min(this.W - 30, ax)), Math.max(30, Math.min(this.H - 30, ay)));
		sq.ax = fx;
		sq.ay = fy;
		this.squads.push(sq);
		return sq;
	}
	healthyOf(st) {
		let n = 0;
		for (const s of st) n += Math.max(0, s.n - s.w);
		return n;
	}
	expand(p, cmd) {
		const ids = [];
		const total = this.healthyOf(p.stacks);
		let i = 0;
		for (const s of p.stacks) {
			if (!TROOPS[s.id]) continue;
			for (let k = 0; k < s.n - s.w; k++) {
				ids.push({
					id: s.id,
					pid: p.pid,
					k: (i + .5) / Math.max(1, total),
					cmd
				});
				i++;
			}
		}
		return ids;
	}
	squadFor(u) {
		if (u.cmd && !u.cmd.left) return u.cmd.sq[u.group];
		let s = this.aiSq[u.side];
		if (!s) {
			this.makeAiSquads(u.side, 0, true);
			s = this.aiSq[u.side];
		}
		return u.group === "cav" ? s.cavs[u.uid % s.cavs.length] : s[u.group];
	}
	addUnit(u) {
		u.sq = this.squadFor(u);
		u.sq.members.push(u);
		this.units.push(u);
		this.byUid[u.uid] = u;
		if (this.started) this.spawned.push(u);
	}
	godBits(g) {
		return g ? (g.buff ? 1 : 0) | (g.inv ? 2 : 0) | (g.oneHit ? 4 : 0) | (g.aura ? 8 : 0) : 0;
	}
	makeUnit(side, troop, pid, cmd) {
		const t = TROOPS[troop];
		const ranged = isRanged(t.cls);
		const kind = t.cls === "arc" || t.cls === "hca" ? "bow" : t.cls === "xbow" ? "xbow" : t.cls === "gun" ? "gun" : null;
		const speed = t.mounted ? t.cls === "hca" ? 165 : 175 : t.cls === "spear" ? 76 : t.cls === "gun" ? 76 : 82;
		const u = {
			uid: this.uidSeq++,
			side,
			troop,
			comp: null,
			name: t.name,
			pid,
			cmd,
			x: 0,
			y: 0,
			vx: 0,
			vy: 0,
			face: side ? Math.PI : 0,
			hp: t.hp,
			maxHp: t.hp,
			atk: t.atk,
			def: t.def,
			skill: t.skill,
			speed,
			mounted: t.mounted,
			cls: t.cls,
			reach: t.cls === "spear" ? 34 : t.mounted ? 28 : 24,
			antiCav: t.cls === "spear",
			rng: t.rng ?? 0,
			range: kind === "gun" ? 240 : kind === "xbow" ? 260 : t.cls === "hca" ? 230 : 275,
			reload: kind === "gun" ? 4.5 : kind === "xbow" ? 3 : t.cls === "hca" ? 2.1 : 1.8,
			ammo: ranged ? t.ammo ?? 15 : 0,
			kind,
			cd: Math.random(),
			rcd: Math.random() * 1.5,
			target: null,
			retarget: 0,
			group: t.mounted ? "cav" : ranged ? "rng" : "inf",
			dead: false,
			routed: false,
			fled: false,
			hero: false,
			disengage: 0,
			r: t.mounted ? 9 : 6,
			swing: 0,
			hitFlash: 0,
			sq: null,
			slotX: 0,
			slotY: 0,
			god: this.godBits(cmd?.god ?? this.parties.get(pid)?.god),
			meleeSpeed: 1
		};
		if (this.opts.night) u.range *= .9;
		if (u.god & 1) {
			u.speed *= cmd?.god?.speed ?? this.parties.get(pid)?.god?.speed ?? 1;
			u.ammo = Math.max(u.ammo, ranged ? 999 : 0);
		}
		return u;
	}
	spawnHeroAndComps(c, late, ex = 0, ey = 0) {
		const p = this.parties.get(c.pid);
		const h = p.hero;
		const god = this.godBits(c.god);
		const base = {
			cd: 0,
			rcd: 0,
			target: null,
			retarget: 0,
			dead: false,
			routed: false,
			fled: false,
			disengage: 0,
			swing: 0,
			hitFlash: 0,
			slotX: 0,
			slotY: 0,
			vx: 0,
			vy: 0,
			cmd: c,
			pid: c.pid,
			side: c.side,
			troop: null,
			god
		};
		const hu = {
			...base,
			uid: this.uidSeq++,
			comp: null,
			name: h.name,
			x: late ? ex : 0,
			y: late ? ey : 0,
			face: c.side ? Math.PI : 0,
			hp: Math.max(h.maxHp * .3, h.hp),
			maxHp: h.maxHp,
			atk: h.atk,
			def: h.def,
			skill: h.skill,
			speed: h.speed,
			mounted: h.mounted,
			cls: h.mounted ? "cav" : "inf",
			reach: h.reach,
			antiCav: h.antiCav,
			rng: h.rng,
			range: h.range * (this.opts.night ? .8 : 1),
			reload: h.reload,
			ammo: h.ammo,
			kind: h.kind,
			group: "inf",
			hero: true,
			r: h.mounted ? 9 : 7,
			sq: c.sq.inf,
			meleeSpeed: h.meleeSpeed
		};
		if (god & 1) {
			hu.speed *= c.god?.speed ?? 1;
			if (hu.rng) hu.ammo = 999;
		}
		c.hero = hu;
		this.units.push(hu);
		this.byUid[hu.uid] = hu;
		if (this.started) this.spawned.push(hu);
		for (const cp of p.comps ?? []) {
			const g = cp.mounted ? "cav" : cp.rng ? "rng" : "inf";
			const u = {
				...base,
				uid: this.uidSeq++,
				comp: cp.id,
				name: cp.name,
				x: late ? ex : 0,
				y: late ? ey + 20 : 0,
				face: c.side ? Math.PI : 0,
				hp: cp.hp,
				maxHp: cp.hp,
				atk: cp.atk,
				def: cp.def,
				skill: cp.skill,
				speed: cp.mounted ? 170 : 88,
				mounted: cp.mounted,
				cls: cp.rng ? cp.mounted ? "hca" : "arc" : cp.mounted ? "cav" : "inf",
				reach: 28,
				antiCav: false,
				rng: cp.rng,
				range: cp.rng ? 270 : 0,
				reload: 1.8,
				ammo: cp.rng ? 40 : 0,
				kind: cp.kind,
				group: g,
				hero: false,
				r: cp.mounted ? 9 : 7,
				sq: c.sq[g],
				meleeSpeed: 1
			};
			if (god & 1) u.speed *= c.god?.speed ?? 1;
			c.sq[g].members.push(u);
			this.units.push(u);
			this.byUid[u.uid] = u;
			if (this.started) this.spawned.push(u);
		}
	}
	faceEnemy(sq) {
		const e = this.centroid(this.units.filter((u) => u.side !== sq.side && !u.dead));
		if (e) sq.face = Math.atan2(e.y - sq.ay, e.x - sq.ax);
		const base = sq.side === 0 ? 0 : Math.PI;
		let d = sq.face - base;
		while (d > Math.PI) d -= Math.PI * 2;
		while (d < -Math.PI) d += Math.PI * 2;
		sq.face = base + Math.max(-.7, Math.min(.7, d));
	}
	centroid(us) {
		if (!us.length) return null;
		let x = 0, y = 0;
		for (const u of us) {
			x += u.x;
			y += u.y;
		}
		return {
			x: x / us.length,
			y: y / us.length
		};
	}
	computeSlots(sq) {
		const ms = sq.members.filter((u) => !u.dead && !u.fled && !u.routed);
		const n = ms.length;
		if (!n) return;
		let sp = sq.g === "cav" ? 24 : sq.g === "rng" ? 16 : 15;
		if (sq.form === "loose") sp *= 2;
		const cos = Math.cos(sq.face), sin = Math.sin(sq.face);
		const put = (u, fwd, side) => {
			u.slotX = sq.ax + cos * fwd - sin * side;
			u.slotY = sq.ay + sin * fwd + cos * side;
		};
		if (sq.form === "wedge") {
			let i = 0;
			for (let k = 0; i < n; k++) for (let j = 0; j <= 2 * k && i < n; j++, i++) put(ms[i], -k * sp, (j - k) * sp * .9);
			return;
		}
		const ranks = sq.form === "block" ? Math.max(1, Math.round(Math.sqrt(n / 1.6))) : sq.g === "inf" ? 3 : 2;
		const cols = Math.ceil(n / ranks);
		ms.forEach((u, i) => {
			const r = Math.floor(i / cols), c = i % cols, rowCount = Math.min(cols, n - r * cols);
			put(u, -r * sp * 1.1, (c - (rowCount - 1) / 2) * sp + (r % 2 ? sp * .3 : 0));
		});
	}
	order(acct, gs, o) {
		const c = this.cmds.get(acct);
		if (!c || c.left || this.finished) return;
		const ref = c.hero && !c.hero.dead ? c.hero : null;
		for (const g of gs) {
			const sq = c.sq[g];
			if (!sq) continue;
			sq.order = o;
			if (o === "hold") {
				const us = sq.members.filter((u) => !u.dead);
				if (ref) {
					const back = Math.cos(ref.face) < 0 ? 1 : -1;
					sq.ax = ref.x + (g === "rng" ? 30 : g === "cav" ? 60 : -30) * -back;
					sq.ay = ref.y + (g === "cav" ? 120 : 0);
				} else {
					const ct = this.centroid(us);
					if (ct) {
						sq.ax = ct.x;
						sq.ay = ct.y;
					}
				}
				[sq.ax, sq.ay] = this.F.nearestFree(Math.max(20, Math.min(this.W - 20, sq.ax)), Math.max(20, Math.min(this.H - 20, sq.ay)));
				this.faceEnemy(sq);
				this.computeSlots(sq);
			}
			if (o === "advance") {
				this.faceEnemy(sq);
				this.computeSlots(sq);
			}
		}
	}
	moveOrder(acct, gs, x, y) {
		const c = this.cmds.get(acct);
		if (!c || c.left || this.finished) return;
		x = Math.max(10, Math.min(this.W - 10, +x || 0));
		y = Math.max(10, Math.min(this.H - 10, +y || 0));
		const ct = this.centroid(gs.map((g) => c.sq[g]).map((s) => ({
			x: s.ax,
			y: s.ay
		})));
		for (const g of gs) {
			const sq = c.sq[g];
			const ox = gs.length > 1 && ct ? sq.ax - ct.x : 0, oy = gs.length > 1 && ct ? sq.ay - ct.y : 0;
			const [fx, fy] = this.F.nearestFree(Math.max(10, Math.min(this.W - 10, x + ox)), Math.max(10, Math.min(this.H - 10, y + oy)));
			sq.ax = fx;
			sq.ay = fy;
			sq.order = "hold";
			this.faceEnemy(sq);
			this.computeSlots(sq);
		}
	}
	setForm(acct, g, f) {
		const c = this.cmds.get(acct);
		if (!c || c.left || !c.sq[g] || ![
			"line",
			"block",
			"wedge",
			"loose"
		].includes(f)) return;
		c.sq[g].form = f;
		this.computeSlots(c.sq[g]);
	}
	input(acct, inp) {
		const c = this.cmds.get(acct);
		if (!c || c.left) return;
		c.inp = inp;
	}
	setView(acct, x, y, w, h) {
		const c = this.cmds.get(acct);
		if (!c) return;
		c.view = {
			x: +x || 0,
			y: +y || 0,
			w: Math.max(200, Math.min(6e3, +w || 1400)),
			h: Math.max(200, Math.min(4e3, +h || 900))
		};
	}
	setOnline(acct, on) {
		const c = this.cmds.get(acct);
		if (!c || c.left) return;
		c.online = on;
		c.offlineT = 0;
		c.inp = null;
		if (on) {
			c.viewer?.reset();
			c.budget = 0;
			c.lastAtk = -1;
			c.lastFire = -1;
		}
		for (const g of [
			"inf",
			"rng",
			"cav"
		]) c.sq[g].ai = !on;
		if (!on) this.say(null, `${c.name}断线了，所部由副将代为指挥。`);
		else this.say(null, `${c.name}重返战场！`);
	}
	/** 玩家撤出战场：所部（含预备队）离场，场上的兵约 15% 在撤退中倒下 */
	retreat(acct) {
		const c = this.cmds.get(acct);
		if (!c || c.left) return null;
		c.left = true;
		for (const u of this.units) {
			if (u.cmd !== c || u.dead || u.fled) continue;
			if (u.troop && Math.random() < .15) this.addDown(u);
			u.fled = true;
		}
		for (const side of [0, 1]) this.reserves[side] = this.reserves[side].filter((e) => e.cmd !== c);
		if (c.hero && !c.hero.dead) c.hero.fled = true;
		this.say(null, `${c.name}率部撤出了战场。`);
		return this.cmdResult(c, true);
	}
	cmdResult(c, retreat) {
		return {
			acct: c.acct,
			pid: c.pid,
			side: c.side,
			down: { ...this.downPid[c.pid] ?? {} },
			heroDown: c.heroDown,
			compDown: [...c.compDown],
			heroHp: c.hero && !c.hero.dead ? c.hero.hp / c.hero.maxHp : .15,
			kills: this.killsBy[c.pid] ?? 0,
			retreat
		};
	}
	say(to, text, side) {
		if (side === void 0) this.out.push({
			to,
			m: {
				t: "bmsg",
				text
			}
		});
		else for (const c of this.cmds.values()) if (c.side === side && !c.left) this.out.push({
			to: c.acct,
			m: {
				t: "bmsg",
				text
			}
		});
	}
	step(dt = TICK) {
		if (this.finished) return;
		this.evs.length = 0;
		this.tick++;
		this.elapsed += dt;
		this.aiT -= dt;
		if (this.aiT <= 0) {
			this.aiT = .5;
			this.thinkSquads();
		}
		this.buildGrid();
		for (const c of this.cmds.values()) this.updateHuman(c, dt);
		for (const u of this.units) {
			if (u.dead || u.fled) continue;
			if (u.hero && u.cmd && u.cmd.online && !u.cmd.left) continue;
			this.updateUnit(u, dt);
		}
		this.separate();
		this.updateProjs(dt);
		this.updateMorale(dt);
		this.reinforce(dt);
		this.checkEnd();
		for (const c of this.cmds.values()) if (!c.online && !c.left) c.offlineT += dt;
		if (!this.finished && (this.elapsed > (this.opts.maxSec ?? 1200) || this.elapsed - this.lastHit > 120)) this.autoFinish();
		this.statT -= dt;
		if (this.statT <= 0) {
			this.statT = .5;
			this.out.push({
				to: null,
				m: {
					t: "bstat",
					m: [Math.round(this.sideMorale(0)), Math.round(this.sideMorale(1))],
					a: [this.activeCount(0), this.activeCount(1)],
					tm: Math.round(this.elapsed)
				}
			});
		}
	}
	buildGrid() {
		const grid = this.grid;
		grid.clear();
		this.foes = [[], []];
		for (const u of this.units) {
			if (u.dead || u.fled) continue;
			if (!u.routed) this.foes[1 - u.side].push(u);
			const k = Math.floor(u.x / 40) * 1e3 + Math.floor(u.y / 40);
			let a = grid.get(k);
			if (!a) grid.set(k, a = []);
			a.push(u);
		}
	}
	near(x, y, r, fn) {
		const grid = this.grid;
		const x0 = Math.floor((x - r) / 40), x1 = Math.floor((x + r) / 40), y0 = Math.floor((y - r) / 40), y1 = Math.floor((y + r) / 40);
		for (let gx = x0; gx <= x1; gx++) for (let gy = y0; gy <= y1; gy++) {
			const a = grid.get(gx * 1e3 + gy);
			if (a) for (const u of a) fn(u);
		}
	}
	nearestEnemy(u, maxR, score) {
		const grid = this.grid;
		const cx = Math.floor(u.x / 40), cy = Math.floor(u.y / 40);
		const maxRing = Math.min(8, Math.ceil(maxR / 40));
		let best = null, bd = Infinity, foundRing = -1;
		const R = Math.min(maxR, maxRing * 40);
		for (let ring = 0; ring <= maxRing; ring++) {
			if (foundRing >= 0 && ring > foundRing + 1) break;
			for (let gx = cx - ring; gx <= cx + ring; gx++) for (let gy = cy - ring; gy <= cy + ring; gy++) {
				if (ring && gx !== cx - ring && gx !== cx + ring && gy !== cy - ring && gy !== cy + ring) continue;
				const a = grid.get(gx * 1e3 + gy);
				if (!a) continue;
				for (const o of a) {
					if (o.side === u.side || o.dead || o.fled || o.routed) continue;
					let d = Math.hypot(o.x - u.x, o.y - u.y);
					if (d > R) continue;
					if (score) d = score(o, d);
					if (d < bd) {
						bd = d;
						best = o;
						if (foundRing < 0) foundRing = ring;
					}
				}
			}
		}
		if (best || maxR <= R) return best;
		for (const o of this.foes[u.side]) {
			let d = Math.hypot(o.x - u.x, o.y - u.y);
			if (d > maxR || d <= R) continue;
			if (score) d = score(o, d);
			if (d < bd) {
				bd = d;
				best = o;
			}
		}
		return best;
	}
	thinkSquads() {
		for (const sq of this.squads) {
			const alive = sq.members.filter((u) => !u.dead && !u.fled && !u.routed);
			if (!alive.length) continue;
			const ai = sq.ai || (sq.owner?.left ?? false);
			if (sq.order === "advance" || sq.order === "hold" && !ai) {
				if (sq.order === "advance") {
					const e = this.centroid(this.foes[sq.side]);
					if (e) {
						const d = Math.hypot(e.x - sq.ax, e.y - sq.ay);
						const nearE = alive.some((u) => this.nearestEnemy(u, 90));
						if (d < 120 || nearE) {
							if (ai) sq.order = "charge";
						} else {
							const step = Math.min(d, 26);
							sq.ax += (e.x - sq.ax) / d * step;
							sq.ay += (e.y - sq.ay) / d * step;
							this.faceEnemy(sq);
						}
					}
				}
				this.computeSlots(sq);
			}
			const h = sq.owner?.hero;
			if (sq.order === "follow" && h && !h.dead && !h.fled) {
				const f = Math.cos(h.face) < 0 ? Math.PI : 0;
				const back = sq.g === "rng" ? 70 : sq.g === "cav" ? 120 : 40;
				sq.ax = h.x - Math.cos(f) * back;
				sq.ay = h.y + (sq.g === "cav" ? 60 : 0);
				sq.face = f;
				this.computeSlots(sq);
			} else if (sq.order === "follow") sq.order = "charge";
			if (!ai) continue;
			sq.phase += .5;
			const enemies = this.foes[sq.side];
			const ec = this.centroid(enemies);
			if (!ec) continue;
			const myC = this.centroid(alive);
			const dist = Math.hypot(ec.x - myC.x, ec.y - myC.y);
			const myPow = alive.length;
			let eRanged = 0;
			for (const u of enemies) if (u.rng > 0 && u.ammo > 0) eRanged++;
			const ratio = this.foes[1 - sq.side].length / Math.max(1, enemies.length);
			if (sq.g === "rng") {
				if (alive.filter((u) => u.ammo > 0).length / alive.length < .3) sq.order = "charge";
				else if (sq.order === "hold" && dist > 520 && sq.phase > 6) sq.order = "advance";
				else if (sq.order === "advance" && dist < 340) {
					sq.order = "hold";
					sq.ax = myC.x;
					sq.ay = myC.y;
					this.computeSlots(sq);
				}
			} else if (sq.g === "inf") {
				const threat = enemies.some((u) => Math.abs(u.x - sq.ax) + Math.abs(u.y - sq.ay) < 450 && Math.hypot(u.x - sq.ax, u.y - sq.ay) < 380);
				if (sq.order === "hold" && (sq.phase > 14 || threat || ratio > 1.5 || eRanged > myPow * .5)) {
					sq.order = "advance";
					this.faceEnemy(sq);
				}
				if (sq.order === "follow") sq.order = "charge";
			} else {
				const engaged = enemies.some((u) => u.swing > 0);
				if (sq.order === "hold" && (sq.phase > 10 || engaged || dist < 300)) {
					sq.order = "advance";
					sq.prefRanged = true;
					if (sq.flank) {
						sq.tx = ec.x;
						sq.ty = Math.max(40, Math.min(this.H - 40, ec.y + sq.flank * this.H * .28));
					}
				}
				if (sq.order === "advance" && sq.tx !== void 0) {
					const d = Math.hypot(sq.tx - sq.ax, sq.ty - sq.ay);
					if (d < 80) sq.order = "charge";
					else {
						const step = Math.min(d, 70);
						sq.ax += (sq.tx - sq.ax) / d * step;
						sq.ay += (sq.ty - sq.ay) / d * step;
						sq.face = Math.atan2(sq.ty - sq.ay, sq.tx - sq.ax);
						this.computeSlots(sq);
					}
					if (alive.some((u) => this.nearestEnemy(u, 110))) sq.order = "charge";
				}
				if (sq.order === "follow") sq.order = "charge";
			}
		}
	}
	/** 真人操控的主角：采用客户端上报的位置（限速校验），出招由服务器结算 */
	updateHuman(c, dt) {
		const h = c.hero;
		if (!h || h.dead || h.fled || c.left || !c.online) return;
		h.cd -= dt;
		h.rcd -= dt;
		h.swing -= dt;
		h.hitFlash -= dt;
		const inp = c.inp;
		c.budget = Math.min(c.budget + h.speed * 1.3 * dt, h.speed * .6 + 12);
		if (!inp) {
			h.vx *= .5;
			h.vy *= .5;
			return;
		}
		const x0 = h.x, y0 = h.y;
		c.corrT -= dt;
		if ((inp.cs | 0) !== c.corrSeq) {
			h.vx *= .5;
			h.vy *= .5;
		} else {
			const tx = Math.max(8, Math.min(this.W - 8, +inp.x || 0)), ty = Math.max(8, Math.min(this.H - 8, +inp.y || 0));
			const d = Math.hypot(tx - h.x, ty - h.y);
			if (d > .01) {
				if (this.F.blocked(tx, ty)) c.corr = true;
				else if (d <= c.budget + 2) {
					h.x = tx;
					h.y = ty;
					c.budget = Math.max(0, c.budget - d);
				} else {
					const k = c.budget / d;
					const nx = h.x + (tx - h.x) * k, ny = h.y + (ty - h.y) * k;
					if (!this.F.blocked(nx, ny)) {
						h.x = nx;
						h.y = ny;
					}
					if (d - c.budget > 28) c.corr = true;
					c.budget = 0;
				}
			}
			if (c.corr && c.corrT > 0) c.corr = false;
			if (c.corr) {
				c.corrSeq = c.corrSeq + 1 & 65535;
				c.corrT = .3;
				c.inp = {
					...inp,
					x: h.x,
					y: h.y,
					cs: c.corrSeq
				};
				this.out.push({
					to: c.acct,
					m: {
						t: "bcorr",
						x: Math.round(h.x * 10) / 10,
						y: Math.round(h.y * 10) / 10,
						cs: c.corrSeq
					}
				});
				c.corr = false;
			}
		}
		h.vx = (h.x - x0) / dt;
		h.vy = (h.y - y0) / dt;
		h.face = +inp.face || 0;
		h.ranged = inp.mode === 1 && h.rng > 0;
		h.aiming = !!h.ranged;
		if (inp.atk !== c.lastAtk) {
			c.lastAtk = inp.atk;
			if (h.cd <= .12) this.heroSwing(h, +inp.atkA || 0);
		}
		if (inp.fire !== c.lastFire) {
			c.lastFire = inp.fire;
			if (h.rng > 0 && h.ammo > 0 && h.rcd <= .15) {
				this.fire(h, +inp.fireA || 0, Math.max(40, Math.min(h.range * 1.2, +inp.fireD || 200)));
				h.rcd = h.reload;
				h.ammo--;
				h.firedT = .25;
			}
		}
	}
	heroSwing(h, aim) {
		h.cd = h.meleeSpeed || .8;
		h.swing = SWING;
		const speedNow = Math.hypot(h.vx, h.vy);
		let hits = 0;
		const slack = 8;
		this.near(h.x, h.y, h.reach + 20 + slack, (u) => {
			if (hits >= 2 || u.side === h.side || u.dead || u.fled) return;
			if (Math.hypot(u.x - h.x, u.y - h.y) > h.reach + u.r + 4 + slack) return;
			let da = Math.abs(Math.atan2(u.y - h.y, u.x - h.x) - aim);
			if (da > Math.PI) da = Math.PI * 2 - da;
			if (da > 1) return;
			const charge = h.mounted && speedNow > h.speed * .6 ? 1 + speedNow / h.speed * .6 : 1;
			this.damage(h, u, h.atk * charge * (h.antiCav && u.mounted ? 1.4 : 1), .95);
			hits++;
		});
	}
	moveUnit(u, dx, dy) {
		const F = this.F;
		let nx = Math.max(8, Math.min(this.W - 8, u.x + dx)), ny = Math.max(8, Math.min(this.H - 8, u.y + dy));
		if (F.blocked(nx, ny)) {
			if (!F.blocked(nx, u.y)) ny = u.y;
			else if (!F.blocked(u.x, ny)) nx = u.x;
			else if (F.blocked(u.x, u.y)) {
				const [fx, fy] = F.nearestFree(u.x, u.y);
				nx = u.x + Math.sign(fx - u.x) * Math.min(4, Math.abs(fx - u.x));
				ny = u.y + Math.sign(fy - u.y) * Math.min(4, Math.abs(fy - u.y));
			} else return;
		}
		u.x = nx;
		u.y = ny;
	}
	waypoint(u, tx, ty) {
		const F = this.F;
		if ((u.navT ?? 0) > this.elapsed) {
			if (u.navX === void 0) return [tx, ty];
			if (Math.hypot(u.navX - u.x, u.navY - u.y) > 6) return [u.navX, u.navY];
		}
		if (F.clearLine(u.x, u.y, tx, ty)) {
			u.navT = this.elapsed + .25 + Math.random() * .15;
			u.navX = void 0;
			return [tx, ty];
		}
		const nx = F.next(u.x, u.y, tx, ty);
		u.navT = this.elapsed + .3 + Math.random() * .2;
		if (!nx) {
			u.navX = tx;
			u.navY = ty;
			return [tx, ty];
		}
		u.navX = nx[0];
		u.navY = nx[1];
		return nx;
	}
	terrainK(u) {
		if ((u.terrT ?? 0) > this.elapsed) return u.slopeK ?? 1;
		u.terrT = this.elapsed + .3 + Math.random() * .1;
		const F = this.F;
		u.hgt = F.heightAt(u.x, u.y);
		const a = u.face, e = 14;
		const s = (F.heightAt(u.x + Math.cos(a) * e, u.y + Math.sin(a) * e) - u.hgt) / e;
		u.slopeK = F.speedAt(u.x, u.y, u.mounted) * (1 - Math.max(-.1, Math.min(.38, s * 5)));
		return u.slopeK;
	}
	steer(u, tx, ty, dt, mult = 1) {
		[tx, ty] = this.waypoint(u, tx, ty);
		const a = Math.atan2(ty - u.y, tx - u.x);
		const sp = u.speed * mult * this.terrainK(u);
		if (u.mounted) {
			u.vx += (Math.cos(a) * sp - u.vx) * Math.min(1, 2.5 * dt);
			u.vy += (Math.sin(a) * sp - u.vy) * Math.min(1, 2.5 * dt);
		} else {
			u.vx = Math.cos(a) * sp;
			u.vy = Math.sin(a) * sp;
		}
		u.face = Math.atan2(u.vy, u.vx);
		this.moveUnit(u, u.vx * dt, u.vy * dt);
	}
	findTarget(u) {
		if (u.rng > 0 && u.ammo > 0) return this.nearestEnemy(u, 3e3, (o, d) => d * (o.hero ? .9 : 1));
		const pref = u.sq?.prefRanged;
		return this.nearestEnemy(u, 4e3, (o, d) => d * (o.hero ? .9 : 1) * (pref && o.rng > 0 ? .5 : 1));
	}
	orderOf(u) {
		return u.sq ? u.sq.order : "charge";
	}
	updateUnit(u, dt) {
		u.cd -= dt;
		u.rcd -= dt;
		u.swing -= dt;
		u.hitFlash -= dt;
		if (u.firedT) u.firedT -= dt;
		if (u.routed) {
			const ex = u.side === 0 ? -20 : this.W + 20;
			const [wx, wy] = this.waypoint(u, ex, u.y);
			const a = Math.atan2(wy - u.y, wx - u.x);
			u.face = a;
			u.vx = Math.cos(a) * u.speed * 1.05;
			u.vy = Math.sin(a) * u.speed * 1.05;
			this.moveUnit(u, u.vx * dt, u.vy * dt);
			if (u.x <= 12 || u.x >= this.W - 12) {
				u.fled = true;
				this.fledPid[u.pid] = (this.fledPid[u.pid] ?? 0) + 1;
			}
			return;
		}
		u.retarget -= dt;
		if (u.retarget <= 0 || !u.target || u.target.dead || u.target.fled || u.target.routed) {
			u.target = this.findTarget(u);
			u.retarget = (u.target ? Math.abs(u.target.x - u.x) + Math.abs(u.target.y - u.y) : 9999) > 500 ? 1.1 + Math.random() * .8 : .4 + Math.random() * .4;
		}
		const t = u.target;
		let order = this.orderOf(u);
		if (u.hero) order = "charge";
		const ranged = u.rng > 0 && u.ammo > 0;
		if (!t) {
			if (order === "charge" || !u.sq) {
				u.vx *= .8;
				u.vy *= .8;
				return;
			}
			if (Math.hypot(u.slotX - u.x, u.slotY - u.y) > 8) this.steer(u, u.slotX, u.slotY, dt, .8);
			else {
				u.vx = u.vy = 0;
				u.face = u.sq.face;
			}
			return;
		}
		const d = Math.hypot(t.x - u.x, t.y - u.y);
		u.aiming = false;
		if (ranged) {
			const hb = Math.max(-.1, Math.min(.3, ((u.hgt ?? 0) - (t.hgt ?? 0)) / 80));
			if (d < u.range * (1 + hb) && d > 40) {
				u.aiming = u.cls !== "hca" || Math.hypot(u.vx, u.vy) < 30;
				if (u.rcd <= 0) {
					const lead = d / (u.kind === "gun" ? 900 : 520);
					const ax = t.x + t.vx * lead, ay = t.y + t.vy * lead;
					const spread = Math.max(.025, .13 - u.skill * .008) + (this.opts.night ? .04 : 0);
					this.fire(u, Math.atan2(ay - u.y, ax - u.x) + (Math.random() - .5) * spread * 2, d);
					u.rcd = u.reload * (.85 + Math.random() * .3);
					u.ammo--;
					u.firedT = .25;
				}
				u.face = Math.atan2(t.y - u.y, t.x - u.x);
				if (u.cls === "hca" && d < 150) {
					const a = Math.atan2(u.y - t.y, u.x - t.x) + .6;
					this.steer(u, u.x + Math.cos(a) * 100, u.y + Math.sin(a) * 100, dt);
				} else if (u.cls === "hca" && order === "charge") {
					this.steer(u, t.x, t.y, dt, .5);
					if (d < 200) {
						u.vx *= .3;
						u.vy *= .3;
					}
				} else {
					u.vx *= .8;
					u.vy *= .8;
				}
				return;
			}
			if (order !== "charge" && order !== "follow") {
				if (Math.hypot(u.slotX - u.x, u.slotY - u.y) > 10) this.steer(u, u.slotX, u.slotY, dt, .8);
				else {
					u.vx = u.vy = 0;
					u.face = Math.atan2(t.y - u.y, t.x - u.x);
				}
				return;
			}
		}
		if (d < u.reach + t.r + 2 && u.disengage <= 0) {
			u.face = Math.atan2(t.y - u.y, t.x - u.x);
			this.meleeHit(u, t);
			if (!u.mounted) {
				u.vx *= .5;
				u.vy *= .5;
				return;
			}
		}
		if (u.disengage > 0) {
			u.disengage -= dt;
			const a = Math.atan2(u.vy, u.vx) || u.face;
			this.steer(u, u.x + Math.cos(a) * 120, u.y + Math.sin(a) * 120, dt);
			return;
		}
		const fh = u.sq?.owner?.hero;
		if (order === "charge" || ranged) this.steer(u, t.x, t.y, dt);
		else if (order === "follow" && fh && !fh.dead) {
			if (d < 70) this.steer(u, t.x, t.y, dt);
			else if (Math.hypot(u.slotX - u.x, u.slotY - u.y) > 14) this.steer(u, u.slotX, u.slotY, dt);
			else {
				u.vx *= .7;
				u.vy *= .7;
			}
		} else {
			const engage = order === "advance" ? 110 : u.sq.form === "block" ? 55 : 75;
			const sd = Math.hypot(u.slotX - u.x, u.slotY - u.y);
			if (d < engage && sd < 140) this.steer(u, t.x, t.y, dt);
			else if (sd > 6) this.steer(u, u.slotX, u.slotY, dt, order === "advance" ? .6 : .8);
			else {
				u.vx = u.vy = 0;
				u.face = Math.atan2(t.y - u.y, t.x - u.x);
			}
		}
		u.inForm = (order === "hold" || order === "advance") && Math.hypot(u.slotX - u.x, u.slotY - u.y) < 16;
	}
	meleeHit(u, t) {
		if (u.cd > 0) return;
		const speedNow = Math.hypot(u.vx, u.vy);
		let dmg = u.atk;
		if (u.mounted && speedNow > u.speed * .55) dmg *= u.sq?.form === "wedge" ? 1.95 : 1.7;
		if (u.antiCav && t.mounted) dmg *= 1.5;
		if (u.mounted && t.antiCav && !(u.god & 2)) u.hp -= 2;
		if (u.sq?.form === "wedge" && !u.mounted) dmg *= 1.08;
		dmg *= 1 + Math.max(-.15, Math.min(.2, ((u.hgt ?? 0) - (t.hgt ?? 0)) / 60));
		this.damage(u, t, dmg, .55 + (u.skill - t.skill) * .025);
		u.cd = (u.hero ? u.meleeSpeed || .8 : u.mounted ? 1.1 : 1.15) + Math.random() * .35;
		u.swing = SWING;
		if (u.mounted && u.cls === "cav" && !u.hero) u.disengage = 1.2 + Math.random() * .6;
	}
	separate() {
		const grid = this.grid;
		for (const u of this.units) {
			if (u.dead || u.fled) continue;
			if (u.hero && u.cmd?.online && !u.cmd.left) continue;
			const x0 = Math.floor((u.x - 20) / 40), x1 = Math.floor((u.x + 20) / 40), y0 = Math.floor((u.y - 20) / 40), y1 = Math.floor((u.y + 20) / 40);
			for (let gx = x0; gx <= x1; gx++) for (let gy = y0; gy <= y1; gy++) {
				const a = grid.get(gx * 1e3 + gy);
				if (!a) continue;
				for (let k = 0; k < a.length; k++) {
					const o = a[k];
					if (o === u || o.dead) continue;
					const dx = u.x - o.x, dy = u.y - o.y;
					const md = u.r + o.r;
					const d2 = dx * dx + dy * dy;
					if (d2 < md * md && d2 > .01) {
						const d = Math.sqrt(d2);
						const push = (md - d) * (u.hero ? .25 : .5) * (o.mounted && !u.mounted ? 1.4 : 1);
						this.moveUnit(u, dx / d * push, dy / d * push);
					}
				}
			}
		}
	}
	fire(u, a, dist = 200) {
		const kind = u.kind ?? "bow";
		const sp = kind === "gun" ? 900 : kind === "xbow" ? 620 : 520;
		const dd = Math.max(40, Math.min(dist, u.range * 1.2));
		const p = {
			x: u.x + Math.cos(a) * 10,
			y: u.y + Math.sin(a) * 10,
			vx: Math.cos(a) * sp,
			vy: Math.sin(a) * sp,
			dmg: u.rng,
			side: u.side,
			life: u.range * 1.4 / sp,
			kind,
			from: u,
			sx: u.x,
			sy: u.y,
			dist: dd
		};
		this.projs.push(p);
		this.evs.push({
			k: 1,
			x: u.x,
			y: u.y,
			a,
			b: dd,
			c: KIND_N[kind],
			d: u.range,
			e: u.mounted ? 1 : 0,
			f: 0,
			from: u.uid,
			to: 0
		});
	}
	updateProjs(dt) {
		for (let i = this.projs.length - 1; i >= 0; i--) {
			const p = this.projs[i];
			const steps = p.kind === "gun" ? 3 : 2;
			let hit = false;
			for (let s = 0; s < steps && !hit; s++) {
				p.x += p.vx * dt / steps;
				p.y += p.vy * dt / steps;
				const trav = Math.hypot(p.x - p.sx, p.y - p.sy);
				if (p.kind === "bow" && trav < p.dist * .7) continue;
				this.near(p.x, p.y, 12, (u) => {
					if (hit || u.side === p.side || u.dead || u.fled) return;
					if (Math.hypot(u.x - p.x, u.y - p.y) < u.r + 2) {
						hit = true;
						if (this.F.inWood(u.x, u.y) && Math.random() < .3) return;
						if (u.sq?.form === "loose" && u.inForm && Math.random() < .3) return;
						const ap = p.kind === "gun" ? .2 : p.kind === "xbow" ? .35 : .5;
						this.damage(p.from, u, p.dmg * (.85 + Math.random() * .3), 1, ap, p.kind === "gun" ? 2 : 1);
					}
				});
			}
			p.life -= dt;
			if (!hit && p.kind !== "gun" && Math.hypot(p.x - p.sx, p.y - p.sy) > p.dist * 1.08) {
				this.projs.splice(i, 1);
				continue;
			}
			if (hit || p.life <= 0 || p.x < 0 || p.x > this.W || p.y < 0 || p.y > this.H) this.projs.splice(i, 1);
		}
	}
	/** src：0 近战 1 箭 2 铳 */
	damage(a, t, raw, hitChance, armorFactor = .45, src = 0) {
		if (t.dead || t.fled) return;
		if (t.god & 2) {
			t.hp = t.maxHp;
			this.hitEv(t, a, 0, 5);
			return;
		}
		if (a.god & 1) {
			raw = raw * 2.2 + 12;
			hitChance += .3;
			armorFactor *= .4;
		}
		if (a.god & 4) {
			raw = t.maxHp * 4 + t.def * 2;
			hitChance = 9;
		}
		if (src === 0 && t.inForm && t.sq?.form === "block") {
			if (a.mounted) raw *= .72;
			hitChance -= .06;
		}
		if (Math.random() > Math.max(.15, Math.min(.95, hitChance))) {
			this.hitEv(t, a, 0, src === 0 ? 3 : 4);
			return;
		}
		const dmg = Math.max(2, raw * (.8 + Math.random() * .4) - t.def * armorFactor);
		t.hp -= dmg;
		t.hitFlash = .12;
		this.lastHit = this.elapsed;
		if (t.mounted && !t.hero) {
			t.vx *= .6;
			t.vy *= .6;
		}
		this.hitEv(t, a, dmg, src === 0 ? 0 : src === 1 ? 1 : 2);
		if (t.hp <= 0) this.kill(t, a);
	}
	hitEv(t, a, dmg, kind) {
		this.evs.push({
			k: 2,
			x: t.x,
			y: t.y,
			a: 0,
			b: dmg,
			c: kind,
			d: 0,
			e: 0,
			f: 0,
			from: a.uid,
			to: t.uid
		});
	}
	addDown(u) {
		if (!u.troop) return;
		const sd = this.down[u.side];
		sd[u.troop] = (sd[u.troop] || 0) + 1;
		const pd = this.downPid[u.pid] ||= {};
		pd[u.troop] = (pd[u.troop] || 0) + 1;
	}
	kill(u, by) {
		if (u.dead) return;
		if (u.god & 2) {
			u.hp = u.maxHp;
			return;
		}
		u.dead = true;
		u.hp = 0;
		this.addDown(u);
		if (by) this.killsBy[by.pid] = (this.killsBy[by.pid] ?? 0) + 1;
		const c = u.cmd;
		if (u.comp && c) {
			c.compDown.push(u.comp);
			this.say(c.acct, `${u.name}负伤倒地！`);
		}
		if (u.hero && c) {
			c.heroDown = true;
			this.say(c.acct, "你被击倒了！部下们继续作战……");
			this.say(null, `${c.name}被${by?.hero ? by.name : "乱军"}击倒了！`);
		}
		if (by?.hero && by.cmd && (u.troop || u.hero)) this.say(by.cmd.acct, `你击倒了${u.name}。`);
	}
	sideMorale(side) {
		const init = this.initial[side];
		let lost = 0;
		for (const k in this.down[side]) lost += this.down[side][k];
		let bonus = 0, humans = false;
		for (const c of this.cmds.values()) if (c.side === side && !c.left) {
			humans = true;
			lost += c.compDown.length + (c.heroDown ? 3 : 0);
			bonus = Math.max(bonus, (c.morale - 50) * .4 + c.leadership * 3);
		}
		let m = 100 - lost / Math.max(1, init) * 140 + bonus;
		if (!humans && this.bandit[side]) m -= 10;
		return m;
	}
	updateMorale(dt) {
		for (const side of [0, 1]) {
			const m = this.sideMorale(side);
			if (m > 40) continue;
			for (const u of this.units) {
				if (u.side !== side || u.dead || u.routed || u.fled || u.hero || u.comp || u.god & 2) continue;
				const p = (m < 10 ? .25 : m < 25 ? .06 : .015) * (u.hp / u.maxHp < .5 ? 2 : 1) * dt;
				if (Math.random() < p) {
					u.routed = true;
					u.target = null;
				}
			}
		}
	}
	spawnPoint(side) {
		const x = side === 0 ? 24 + Math.random() * 30 : this.W - 24 - Math.random() * 30;
		const y = this.H / 2 + (Math.random() - .5) * this.H * .5;
		return this.F.nearestFree(x, y);
	}
	reinforce(dt) {
		this.reinforceT -= dt;
		if (this.reinforceT > 0) return;
		this.reinforceT = 2.5;
		const cap = Math.max(60, Math.min(1e3, this.opts.cap));
		for (const side of [0, 1]) {
			const res = this.reserves[side];
			if (!res.length) continue;
			let alive = 0;
			for (const u of this.units) if (u.side === side && !u.dead && !u.fled) alive++;
			const capSide = Math.round(cap * .5 * 1.15);
			if (alive >= capSide * .8) continue;
			const n = Math.min(16, capSide - alive);
			let spawned = 0;
			const byCmd = /* @__PURE__ */ new Map();
			for (let i = 0; i < n && res.length; i++) {
				const e = res.shift();
				if (e.cmd?.left) {
					i--;
					continue;
				}
				const u = this.makeUnit(side, e.id, e.pid, e.cmd);
				[u.x, u.y] = this.spawnPoint(side);
				this.addUnit(u);
				spawned++;
				byCmd.set(e.cmd, (byCmd.get(e.cmd) ?? 0) + 1);
			}
			if (spawned) {
				for (const c of this.cmds.values()) {
					if (c.left) continue;
					const mine = byCmd.get(c) ?? 0;
					if (c.side === side) this.say(c.acct, mine ? `我军 ${mine} 名援兵赶到。` : `友军 ${spawned} 人赶到战场。`);
					else this.say(c.acct, `敌军 ${spawned} 名援兵赶到！`);
				}
				for (const sq of this.squads) if (sq.side === side) this.computeSlots(sq);
			}
		}
	}
	activeCount(side) {
		let n = 0;
		for (const u of this.units) if (u.side === side && !u.dead && !u.routed && !u.fled) n++;
		return n + this.reserves[side].length;
	}
	checkEnd() {
		if (!this.started) return;
		const a = this.activeCount(0), b = this.activeCount(1);
		if (b === 0 && a === 0) this.finish(-1);
		else if (b === 0) this.finish(0);
		else if (a === 0) this.finish(1);
	}
	finish(winner, auto = false) {
		if (this.finished) return;
		this.finished = true;
		if (winner >= 0) {
			for (const u of this.units) if (u.side !== winner && !u.dead && u.troop && !u.cmd?.left && Math.random() < .3) this.addDown(u);
		}
		const cmds = [];
		for (const c of this.cmds.values()) if (!c.left) cmds.push(this.cmdResult(c, false));
		this.result = {
			winner,
			downPid: JSON.parse(JSON.stringify(this.downPid)),
			killsBy: { ...this.killsBy },
			cmds,
			dur: Math.round(this.elapsed),
			auto
		};
	}
	/** 超时/无人值守：按剩余兵力强弱估算结果 */
	autoFinish() {
		if (this.finished) return;
		const pow = (u) => u.maxHp / 10 * ((u.atk + u.skill * .6) / 10) * (1 + u.def / 25);
		const P = [0, 0];
		const alive = [[], []];
		for (const u of this.units) if (!u.dead && !u.fled && !u.routed) {
			P[u.side] += pow(u) * (u.god & 2 ? 1e3 : 1);
			alive[u.side].push(u);
		}
		for (const s of [0, 1]) for (const e of this.reserves[s]) {
			const t = TROOPS[e.id];
			P[s] += pow({
				maxHp: t.hp,
				atk: t.atk,
				skill: t.skill,
				def: t.def
			});
		}
		const w = P[0] * (.85 + Math.random() * .3) >= P[1] * (.85 + Math.random() * .3) ? 0 : 1;
		const l = 1 - w;
		const ratio = Math.min(1, P[l] / Math.max(1, P[w]));
		for (const u of alive[w]) if (u.troop && !(u.god & 2) && Math.random() < ratio * .45) {
			u.dead = true;
			this.addDown(u);
		}
		for (const u of alive[l]) if (u.troop && Math.random() < .6) {
			u.dead = true;
			this.addDown(u);
		}
		for (const e of this.reserves[l]) if (Math.random() < .5) {
			const t = {
				troop: e.id,
				pid: e.pid,
				side: l
			};
			this.addDown(t);
		}
		for (const e of this.reserves[w]) if (Math.random() < ratio * .3) {
			const t = {
				troop: e.id,
				pid: e.pid,
				side: w
			};
			this.addDown(t);
		}
		this.reserves = [[], []];
		for (const u of alive[l]) u.routed = true;
		this.finish(w, true);
	}
	/** 生成某玩家本 tick 的二进制帧（无内容时返回 null） */
	frameFor(c) {
		const v = c.viewer;
		const w = this.wr;
		w.reset();
		v.grow(this.uidSeq + 1);
		const tick = this.tick;
		const vw = c.view, mx = 140;
		const x0 = vw.x - mx, x1 = vw.x + vw.w + mx, y0 = vw.y - mx, y1 = vw.y + vw.h + mx;
		const fx = c.hero && !c.hero.dead && !c.hero.fled ? c.hero.x : vw.x + vw.w / 2, fy = c.hero && !c.hero.dead && !c.hero.fled ? c.hero.y : vw.y + vw.h / 2;
		w.u8(1);
		w.u32(tick);
		w.u32(Math.round(this.elapsed * 1e3));
		const nPos = w.pos;
		w.u16(0);
		let n = 0;
		for (const u of this.units) {
			const id = u.uid;
			const known = v.known[id];
			if (known === 2) continue;
			const st = (u.dead ? 1 : 0) | (u.routed ? 2 : 0) | (u.fled ? 4 : 0) | (u.aiming ? 8 : 0) | (u.swing > 0 ? 16 : 0) | (u.ranged ? 32 : 0);
			const own = u === c.hero && c.online;
			const qx = Math.round(u.x * 4), qy = Math.round(u.y * 4);
			const qf = Math.round(u.face / (Math.PI * 2) * 256) & 255;
			const qh = u.dead ? 0 : Math.max(1, Math.min(255, Math.ceil(u.hp / u.maxHp * 255)));
			let mask = 0;
			if (!known) mask = 29;
			else {
				const stCh = st !== v.ls[id];
				if (!stCh) {
					const interval = u.x > x0 && u.x < x1 && u.y > y0 && u.y < y1 ? Math.abs(u.x - fx) + Math.abs(u.y - fy) < 520 ? 1 : 2 : 8;
					if (tick - v.lt[id] < interval) continue;
				}
				const dx = qx - v.lx[id], dy = qy - v.ly[id];
				if (!own && (dx > 1 || dx < -1 || dy > 1 || dy < -1)) mask |= dx >= -127 && dx <= 127 && dy >= -127 && dy <= 127 ? 2 : 1;
				let df = qf - v.lf[id];
				if (df < 0) df = -df;
				if (df > 128) df = 256 - df;
				if (df >= 3 && !own) mask |= 4;
				if (qh !== v.lh[id]) mask |= 8;
				if (stCh) mask |= 16;
				if (!mask) continue;
			}
			if (own) mask &= -4;
			w.u16(id);
			w.u8(mask);
			if (mask & 1) {
				w.u16(qx);
				w.u16(qy);
				v.lx[id] = qx;
				v.ly[id] = qy;
			} else if (mask & 2) {
				w.i8(qx - v.lx[id]);
				w.i8(qy - v.ly[id]);
				v.lx[id] = qx;
				v.ly[id] = qy;
			}
			if (mask & 4) {
				w.u8(qf);
				v.lf[id] = qf;
			}
			if (mask & 8) {
				w.u8(qh);
				v.lh[id] = qh;
			}
			if (mask & 16) {
				w.u8(st);
				v.ls[id] = st;
			}
			v.lt[id] = tick;
			v.known[id] = u.dead || u.fled ? 2 : 1;
			n++;
		}
		w.setU16(nPos, n);
		const ePos = w.pos;
		w.u16(0);
		let ne = 0;
		const em = 320;
		const myUid = c.hero?.uid ?? -1;
		for (const e of this.evs) if (e.k === 1) {
			if (e.from === myUid && c.online) continue;
			const ex = e.x + Math.cos(e.a) * e.b, ey = e.y + Math.sin(e.a) * e.b;
			if (!(e.x > x0 - em && e.x < x1 + em && e.y > y0 - em && e.y < y1 + em || ex > x0 && ex < x1 && ey > y0 && ey < y1)) continue;
			w.u8(1);
			w.u8(e.c | e.e << 4);
			w.u16(e.from);
			w.u16(Math.round(e.x * 2));
			w.u16(Math.round(e.y * 2));
			w.u16(Math.round((e.a % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) / (Math.PI * 2) * 65535));
			w.u16(Math.round(e.b));
			w.u16(Math.round(e.d));
			ne++;
		} else {
			if (!(e.to === myUid || e.from === myUid) && !(e.x > x0 && e.x < x1 && e.y > y0 && e.y < y1)) continue;
			let kind = e.c;
			if (kind === 5) {
				const tu = this.byUid[e.to];
				if (tu && tu.cmd !== c && !(tu.god & 8)) kind = 3;
			}
			w.u8(2);
			w.u16(e.to);
			w.u16(e.from);
			w.u8(Math.min(255, Math.round(e.b)));
			w.u8(kind);
			ne++;
		}
		w.setU16(ePos, ne);
		if (!n && !ne && tick % 10) return null;
		v.frames++;
		v.bytes += w.pos;
		return w.bytes();
	}
	/** 本 tick 结束：取出新出生单位的静态信息与待发消息（事件留给 frameFor，下一步开始时清空） */
	endTick() {
		const sp = this.spawned;
		this.spawned = [];
		const out = this.out;
		this.out = [];
		return {
			spawned: sp.map((u) => this.spawnInfo(u)),
			out
		};
	}
};
//#endregion
//#region server/battleRunner.ts
var BattleRunner = class {
	emit;
	cores = /* @__PURE__ */ new Map();
	timer = null;
	last = 0;
	acc = 0;
	statT = 0;
	costMs = /* @__PURE__ */ new Map();
	constructor(emit) {
		this.emit = emit;
	}
	handle(m, out = []) {
		if (m.k === "new") {
			const core = new BattleCore(m.opts, m.total);
			core.start(m.parts);
			this.cores.set(m.bid, core);
			for (const c of core.cmds.values()) if (c.online) out.push({
				k: "json",
				bid: m.bid,
				to: [c.acct],
				m: {
					t: "bstart",
					bid: m.bid,
					init: core.initMsg(c.acct)
				}
			});
			this.ensureTimer();
			return out;
		}
		const core = this.cores.get(m.bid);
		if (!core) return out;
		switch (m.k) {
			case "join": {
				if (!core.join(m.part)) break;
				const sp = core.endTick();
				this.flushOut(m.bid, core, sp, out);
				if (m.part.acct && m.part.online) out.push({
					k: "json",
					bid: m.bid,
					to: [m.part.acct],
					m: {
						t: "bstart",
						bid: m.bid,
						init: core.initMsg(m.part.acct),
						joined: true
					}
				});
				break;
			}
			case "in":
				core.input(m.acct, m.inp);
				break;
			case "cmd": {
				const c = m.c;
				const gs = (c.gs ?? [
					"inf",
					"rng",
					"cav"
				]).filter((g) => g === "inf" || g === "rng" || g === "cav");
				if (c.o) core.order(m.acct, gs, c.o);
				else if (c.mv) core.moveOrder(m.acct, gs, c.mv[0], c.mv[1]);
				else if (c.f && c.g) core.setForm(m.acct, c.g, c.f);
				break;
			}
			case "view":
				core.setView(m.acct, m.v[0], m.v[1], m.v[2], m.v[3]);
				break;
			case "online":
				core.setOnline(m.acct, m.on);
				if (m.on) out.push({
					k: "json",
					bid: m.bid,
					to: [m.acct],
					m: {
						t: "bstart",
						bid: m.bid,
						init: core.initMsg(m.acct),
						resume: true
					}
				});
				break;
			case "resync":
				core.cmds.get(m.acct)?.viewer?.reset();
				out.push({
					k: "json",
					bid: m.bid,
					to: [m.acct],
					m: {
						t: "bstart",
						bid: m.bid,
						init: core.initMsg(m.acct),
						resume: true
					}
				});
				break;
			case "retreat": {
				const r = core.retreat(m.acct);
				if (r) out.push({
					k: "left",
					bid: m.bid,
					res: r
				});
				core.checkEnd();
				this.checkDone(m.bid, core, out);
				break;
			}
			case "abort":
				core.autoFinish();
				this.checkDone(m.bid, core, out);
		}
		return out;
	}
	ensureTimer() {
		if (this.timer) return;
		this.last = performance.now();
		this.acc = 0;
		this.timer = setInterval(() => this.loop(), 25);
	}
	loop() {
		const now = performance.now();
		this.acc += Math.min(.25, (now - this.last) / 1e3);
		this.last = now;
		if (this.acc < .05) return;
		const out = [];
		let steps = 0;
		while (this.acc >= .05 && steps < 3) {
			this.acc -= TICK;
			steps++;
			for (const [bid, core] of this.cores) {
				const a = performance.now();
				core.step(TICK);
				const sp = core.endTick();
				this.flushOut(bid, core, sp, out);
				for (const c of core.cmds.values()) {
					if (!c.online || c.left) continue;
					const f = core.frameFor(c);
					if (f) out.push({
						k: "bin",
						bid,
						acct: c.acct,
						buf: f
					});
				}
				this.costMs.set(bid, (this.costMs.get(bid) ?? 0) * .9 + (performance.now() - a) * .1);
				this.checkDone(bid, core, out);
			}
		}
		if (this.acc > .05 * 3) this.acc = 0;
		this.statT -= steps * TICK;
		if (this.statT <= 0) {
			this.statT = 2;
			for (const [bid, core] of this.cores) {
				let units = 0;
				for (const u of core.units) if (!u.dead && !u.fled) units++;
				let bytes = 0;
				for (const c of core.cmds.values()) {
					bytes += c.viewer?.bytes ?? 0;
					if (c.viewer) c.viewer.bytes = 0;
				}
				out.push({
					k: "stat",
					bid,
					n: [core.activeCount(0), core.activeCount(1)],
					ms: +(this.costMs.get(bid) ?? 0).toFixed(2),
					units,
					bytes
				});
			}
		}
		if (out.length) this.emit(out);
		if (!this.cores.size && this.timer) {
			clearInterval(this.timer);
			this.timer = null;
		}
	}
	flushOut(bid, core, sp, out) {
		const live = [...core.cmds.values()].filter((c) => c.online && !c.left).map((c) => c.acct);
		if (sp.spawned.length && live.length) out.push({
			k: "json",
			bid,
			to: live,
			m: {
				t: "bspawn",
				u: sp.spawned
			}
		});
		for (const o of sp.out) {
			const to = o.to === null ? live : live.includes(o.to) ? [o.to] : [];
			if (to.length) out.push({
				k: "json",
				bid,
				to,
				m: o.m
			});
		}
	}
	checkDone(bid, core, out) {
		if (!core.finished || !core.result) return;
		const sp = core.endTick();
		this.flushOut(bid, core, sp, out);
		out.push({
			k: "end",
			bid,
			res: core.result
		});
		this.cores.delete(bid);
		this.costMs.delete(bid);
	}
};
//#endregion
//#region src/battle/heroStats.ts
function meleeWeaponOf(h) {
	const m = h.equip.melee ? ITEMS[h.equip.melee] : null;
	if (!m) return "club";
	const b = m.base ?? m.id;
	if ([
		"w_jian",
		"w_club",
		"w_tiebian",
		"w_langya",
		"w_guduo",
		"w_jingua",
		"w_meteor",
		"w_tiechi"
	].includes(b)) return "club";
	if (b === "w_miaodao" || b === "w_taidao") return "katana";
	if (m.antiCav || (m.reach ?? 0) >= 40) return "spear";
	return "sabre";
}
function lookOf(h, color) {
	const r = h.equip.ranged ? ITEMS[h.equip.ranged] : null;
	const t = (h.equip.armor ? ITEMS[h.equip.armor] : null)?.tier ?? 0;
	return {
		w: meleeWeaponOf(h),
		wr: r ? r.kind === "gun" ? "gun" : r.kind === "xbow" ? "xbow" : "bow" : null,
		a: t <= 1 ? 1 : t <= 3 ? 2 : 3,
		c: color
	};
}
function heroIn(h, color) {
	const melee = h.equip.melee ? ITEMS[h.equip.melee] : null;
	const ranged = h.equip.ranged ? ITEMS[h.equip.ranged] : null;
	const mounted = !!h.equip.horse && !!ITEMS[h.equip.horse] && h.skills.riding >= horseRidingReq(h.equip.horse);
	const horse = mounted ? ITEMS[h.equip.horse] : null;
	const maxHp = heroMaxHp(h);
	return {
		name: h.name,
		maxHp,
		hp: Math.max(maxHp * .3, maxHp * (h.hp ?? 1)),
		atk: (melee?.dmg ?? 6) * (1 + h.skills.powerstrike * .08) * (1 + h.attrs.str * .012),
		def: heroArmor(h) + (horse?.horseArmor ?? 0) * .5,
		skill: 8 + h.level * .6 + h.attrs.agi * .3,
		speed: mounted ? 92 * (horse.horseSpeed ?? 1.4) * (1 + h.skills.riding * .04) : 92 + h.attrs.agi * 2.5,
		mounted,
		reach: melee?.reach ?? 24,
		antiCav: !!melee?.antiCav,
		rng: ranged ? (ranged.dmg ?? 10) * (1 + h.skills.archery * .07) : 0,
		range: ranged?.range ?? 0,
		reload: (ranged?.reload ?? 2) * (1 - h.skills.archery * .03),
		ammo: ranged?.ammo ?? 0,
		kind: ranged?.kind ?? null,
		meleeSpeed: melee?.speed ?? .8,
		look: lookOf(h, color)
	};
}
function compsIn(cs) {
	const out = [];
	for (const c of cs ?? []) {
		if (c.wounded > 0) continue;
		const d = COMPANIONS.find((x) => x.id === c.id);
		if (!d) continue;
		out.push({
			id: d.id,
			name: d.name,
			hp: d.hp,
			atk: d.atk,
			def: d.def,
			skill: d.skill,
			mounted: d.mounted,
			rng: d.rng ?? 0,
			kind: d.rng ? d.id === "c_tang" ? "gun" : "bow" : null
		});
	}
	return out;
}
//#endregion
//#region server/battles.ts
/** 实时战斗设置（GM 可调） */
var BCFG = {
	on: true,
	cap: 600,
	maxSec: 1200,
	joinRange: 90
};
var battles = /* @__PURE__ */ new Map();
var acctBattle = /* @__PURE__ */ new Map();
var nextBid = 1;
var hosts = [];
var PERF = {
	frames: 0,
	bytes: 0,
	since: Date.now()
};
/** 网络层注入：把二进制帧/JSON 发给某个玩家 */
var BOUT = {
	bin: (_acct, _buf) => {},
	json: (_acct, _m) => {}
};
function initBattles() {
	const want = process.env.BATTLE_WORKERS !== void 0 ? Number(process.env.BATTLE_WORKERS) : Math.max(1, Math.min(4, cpus().length - 1));
	const self = fileURLToPath(import.meta.url);
	if (want > 0 && self.endsWith(".mjs")) for (let i = 0; i < want; i++) try {
		const w = new Worker(self, { workerData: { battleWorker: true } });
		const h = {
			post: (m) => w.postMessage(m),
			battles: 0,
			ms: 0,
			name: "w" + i,
			close: () => {
				w.terminate();
			}
		};
		w.on("message", (batch) => onOut(batch));
		w.on("error", (e) => console.error("[battle] worker error", e));
		w.on("exit", (code) => {
			if (code) console.error("[battle] worker exited", code);
			hosts = hosts.filter((x) => x !== h);
			failHost(h);
		});
		hosts.push(h);
	} catch (e) {
		console.error("[battle] worker start failed", e);
	}
	if (!hosts.length) {
		const runner = new BattleRunner((b) => onOut(b));
		hosts.push({
			post: (m) => {
				const out = runner.handle(m);
				if (out.length) onOut(out);
			},
			battles: 0,
			ms: 0,
			name: "main"
		});
	}
	console.log(`[battle] 实时战斗线程：${hosts.map((h) => h.name).join(", ")}`);
}
/** worker 线程入口 */
function runBattleWorker(port) {
	const post = (batch) => {
		const tr = [];
		for (const o of batch) if (o.k === "bin") tr.push(o.buf.buffer);
		port.postMessage(batch, tr);
	};
	const runner = new BattleRunner(post);
	port.on("message", (m) => {
		try {
			const out = runner.handle(m);
			if (out.length) post(out);
		} catch (e) {
			console.error("[battle-worker]", e);
		}
	});
}
function failHost(h) {
	for (const b of battles.values()) if (b.host === h && !b.ended) {
		console.error(`[battle] #${b.bid} 所在线程崩溃，释放参战部队`);
		releaseAll(b);
	}
}
function pickHost() {
	return hosts.reduce((a, h) => h.battles * 10 + h.ms < a.battles * 10 + a.ms ? h : a, hosts[0]);
}
var inBattle = (acct) => acctBattle.has(acct);
function battleOf(acct) {
	const id = acctBattle.get(acct);
	return id ? battles.get(id) : void 0;
}
function battleList() {
	const out = [];
	for (const b of battles.values()) {
		if (b.ended || b.hidden) continue;
		const side = (s) => [...b.parts.values()].filter((p) => p.side === s && !p.left);
		const nm = (s) => {
			const ps = side(s);
			return ps.length ? ps.length > 1 ? `${ps[0].name}等${ps.length}部` : ps[0].name : "";
		};
		out.push({
			bid: b.bid,
			x: Math.round(b.x),
			y: Math.round(b.y),
			n: b.n,
			f: [side(0)[0]?.faction ?? "", side(1)[0]?.faction ?? ""],
			names: [nm(0), nm(1)]
		});
	}
	return out;
}
function battleStats() {
	const dt = (Date.now() - PERF.since) / 1e3;
	return {
		battles: [...battles.values()].filter((b) => !b.ended).map((b) => ({
			bid: b.bid,
			n: b.n,
			units: b.units,
			ms: b.ms,
			kbps: +(b.bytes / 2 / 1024).toFixed(1),
			players: [...b.parts.values()].filter((p) => p.acct && !p.left).map((p) => p.acct)
		})),
		threads: hosts.map((h) => ({
			name: h.name,
			battles: h.battles,
			ms: +h.ms.toFixed(2)
		})),
		framesPerSec: +(PERF.frames / Math.max(1, dt)).toFixed(1)
	};
}
function godFx(p) {
	const g = godOf(p);
	if (!g) return null;
	return {
		buff: true,
		inv: g.invincible,
		oneHit: g.oneHit,
		speed: g.battleSpeed,
		aura: g.aura && g.reveal
	};
}
function partyIn(p, side) {
	const base = {
		pid: String(p.id),
		side,
		name: partyLabel(p),
		faction: p.faction,
		stacks: p.troops.map((s) => ({ ...s })),
		bandit: p.faction === "bandit"
	};
	if (p.kind === "hero" && p.acct) {
		const rec = OUT.rec(p.acct);
		base.acct = p.acct;
		base.online = OUT.online(p.acct);
		base.god = godFx(p);
		if (rec?.hero) {
			const color = FACTION[p.faction]?.color ?? 13938487;
			base.hero = heroIn({
				...rec.hero,
				hp: Math.max(.3, rec.hero.hp ?? 1)
			}, color);
			base.comps = compsIn(rec.companions ?? []);
			base.morale = rec.morale ?? 70;
			base.leadership = rec.hero.skills?.leadership ?? 0;
			base.name = p.name;
		} else {
			delete base.acct;
			base.online = false;
		}
	}
	return base;
}
/**
* 开一场实时战斗。a/b 两方的第一支为主角；附近的领主/玩家按敌我自动加入。
* 返回战斗编号；条件不满足返回 0（调用方改用自动结算）。
*/
function startRT(a, b, why) {
	if (!BCFG.on || !hosts.length) return 0;
	const A = [a], B = [b];
	for (const p of S.parties) {
		if (p === a || p === b || p.inside || p.busy || p.hidden || p.kind !== "lord" && p.kind !== "hero") continue;
		if (Math.hypot(p.x - a.x, p.y - a.y) > 60) continue;
		if (p.kind === "hero" && p.acct && OUT.online(p.acct)) continue;
		const ha = hostile(p, a), hb = hostile(p, b);
		if (hb && !ha && A.length < 8) A.push(p);
		else if (ha && !hb && B.length < 8) B.push(p);
	}
	const bid = nextBid++;
	const parts = [...A.map((p) => partyIn(p, 0)), ...B.map((p) => partyIn(p, 1))];
	if (!parts.some((p) => p.acct && p.online)) return 0;
	let ter = terAtXY(a.x, a.y);
	if (ter === Ter.Sea || ter === Ter.Plateau) ter = Ter.Plain;
	const host = pickHost();
	const rec = {
		bid,
		host,
		x: (a.x + b.x) / 2,
		y: (a.y + b.y) / 2,
		started: Date.now(),
		parts: /* @__PURE__ */ new Map(),
		n: [0, 0],
		ms: 0,
		units: 0,
		bytes: 0,
		hidden: [...A, ...B].some((p) => godHidden(p)),
		ended: false
	};
	battles.set(bid, rec);
	host.battles++;
	for (const [ps, side] of [[A, 0], [B, 1]]) for (const p of ps) enlist(rec, p, side);
	const total = parts.reduce((n, p) => n + p.stacks.reduce((m, s) => m + Math.max(0, s.n - s.w), 0) + (p.hero ? 1 : 0), 0);
	host.post({
		k: "new",
		bid,
		opts: {
			terrain: ter,
			seed: Math.floor(Math.random() * 1e9),
			night: isNight(),
			cap: BCFG.cap,
			maxSec: BCFG.maxSec
		},
		parts,
		total
	});
	const nm = (xs) => xs.length > 1 ? `${partyLabel(xs[0])}等${xs.length}路兵马` : partyLabel(xs[0]);
	log(`${why}${nm(A)}与${nm(B)}在${placeName(rec.x, rec.y)}展开激战！`, A.concat(B).some((p) => p.kind === "hero") ? "war" : "dim");
	return bid;
}
function enlist(b, p, side) {
	for (const [eid, e] of encounters) if (e.hero === p.id || e.enemy === p.id) encounters.delete(eid);
	p.busy = -b.bid;
	heroNav.delete(p.id);
	p.ai.path = [];
	b.parts.set(String(p.id), {
		id: p.id,
		side,
		acct: p.kind === "hero" ? p.acct : void 0,
		name: partyLabel(p),
		faction: p.faction,
		kind: p.kind
	});
	if (p.kind === "hero" && p.acct) acctBattle.set(p.acct, b.bid);
}
function placeName(x, y) {
	let best = "", bd = Infinity;
	for (const s of settlementList()) {
		const d = Math.hypot(s.x - x, s.y - y);
		if (d < bd) {
			bd = d;
			best = s.name;
		}
	}
	return best ? `${best}附近` : "野外";
}
/** 玩家加入进行中的战斗（地图上的⚔）。side 省略时按敌我自动判断 */
function joinRT(acct, bid, side) {
	const b = battles.get(bid);
	const p = heroOf(acct);
	if (!b || b.ended) return {
		ok: false,
		err: "这场战斗已经结束了"
	};
	if (!p) return {
		ok: false,
		err: "你不在世界中"
	};
	if (p.busy) return {
		ok: false,
		err: "你正忙着"
	};
	if (p.inside) return {
		ok: false,
		err: "先出城"
	};
	if (Math.hypot(p.x - b.x, p.y - b.y) > BCFG.joinRange) return {
		ok: false,
		err: "离战场太远了，靠近些再加入"
	};
	const god = godOf(p);
	const others = (s) => [...b.parts.values()].filter((x) => x.side === s && !x.left).map((x) => partyById(x.id)).filter((x) => !!x);
	const can = (s) => {
		if (god?.any) return true;
		const mine = others(s), foes = others(1 - s);
		return mine.every((x) => !hostile(p, x)) && foes.some((x) => hostile(p, x));
	};
	let sd = side === 0 || side === 1 ? side : null;
	if (sd === null) sd = can(0) ? 0 : can(1) ? 1 : null;
	if (sd === null || !can(sd)) return {
		ok: false,
		err: "你与交战双方都不是敌人，或者与两边都有仇——无法加入"
	};
	enlist(b, p, sd);
	b.host.post({
		k: "join",
		bid,
		part: partyIn(p, sd)
	});
	return {
		ok: true,
		side: sd
	};
}
function onClientMsg(acct, m) {
	const bid = acctBattle.get(acct);
	const b = bid ? battles.get(bid) : void 0;
	if (!b || b.ended) {
		if (m?.t === "bi" || m?.t === "bc") BOUT.json(acct, {
			t: "bgone",
			bid: m.bid ?? 0
		});
		return;
	}
	switch (m.t) {
		case "bi": {
			const d = m.d;
			if (!Array.isArray(d) || d.length < 11) return;
			b.host.post({
				k: "in",
				bid: b.bid,
				acct,
				inp: {
					x: +d[0] / 10,
					y: +d[1] / 10,
					face: +d[2] / 1e3,
					mode: d[3] | 0,
					atk: d[4] | 0,
					atkA: +d[5] / 1e3,
					fire: d[6] | 0,
					fireA: +d[7] / 1e3,
					fireD: +d[8],
					cs: d[9] | 0
				}
			});
			const v = d[10];
			if (Array.isArray(v) && v.length === 4) b.host.post({
				k: "view",
				bid: b.bid,
				acct,
				v: [
					+v[0],
					+v[1],
					+v[2],
					+v[3]
				]
			});
			return;
		}
		case "bc":
			b.host.post({
				k: "cmd",
				bid: b.bid,
				acct,
				c: {
					o: m.o,
					f: m.f,
					g: m.g,
					gs: Array.isArray(m.gs) ? m.gs : void 0,
					mv: Array.isArray(m.mv) ? [+m.mv[0], +m.mv[1]] : void 0
				}
			});
			return;
		case "bleave":
			b.host.post({
				k: "retreat",
				bid: b.bid,
				acct
			});
			return;
		case "bsync":
			b.host.post({
				k: "resync",
				bid: b.bid,
				acct
			});
			return;
	}
}
/** 断线/重连 */
function onPresence(acct, on) {
	const b = battleOf(acct);
	if (!b || b.ended) return;
	b.host.post({
		k: "online",
		bid: b.bid,
		acct,
		on
	});
}
function onOut(batch) {
	for (const o of batch) switch (o.k) {
		case "bin":
			BOUT.bin(o.acct, o.buf);
			PERF.frames++;
			PERF.bytes += o.buf.byteLength;
			break;
		case "json":
			for (const a of o.to) BOUT.json(a, o.m);
			break;
		case "left": {
			const b = battles.get(o.bid);
			if (b) applyLeft(b, o.res);
			break;
		}
		case "end": {
			const b = battles.get(o.bid);
			if (b) try {
				applyEnd(b, o.res);
			} catch (e) {
				console.error("[battle] applyEnd", e);
				releaseAll(b);
			}
			break;
		}
		case "stat": {
			const b = battles.get(o.bid);
			if (!b) break;
			b.n = o.n;
			b.ms = o.ms;
			b.units = o.units;
			b.bytes = o.bytes;
			b.host.ms = [...battles.values()].filter((x) => x.host === b.host && !x.ended).reduce((s, x) => s + x.ms, 0);
			break;
		}
	}
}
var casPow = (c) => {
	let s = 0;
	for (const id in c) s += c[id] * (TROOPS[id]?.tier ?? 1) * 1.2;
	return s;
};
/** 玩家部队折损：倒下者约七成阵亡（医术可救回一些），其余负伤 */
function heroLosses(p, down, rec) {
	if (!down) return {
		killed: 0,
		wounded: 0
	};
	const surg = rec?.hero?.skills?.surgery ?? 0;
	const pDie = Math.max(.35, .7 - surg * .05);
	let killed = 0, wounded = 0;
	for (const id in down) {
		const n = down[id];
		let k = 0;
		for (let i = 0; i < n; i++) if (Math.random() < pDie) k++;
		removeTroops(p.troops, id, k);
		const st = p.troops.find((s) => s.id === id);
		if (st) st.w = Math.min(st.n, st.w + (n - k));
		killed += k;
		wounded += n - k;
	}
	cleanStacks(p.troops);
	return {
		killed,
		wounded
	};
}
function syncRec(p) {
	const rec = p.acct ? OUT.rec(p.acct) : void 0;
	if (rec) {
		rec.troops = p.troops;
		rec.gold = p.gold;
	}
}
function applyLeft(b, r) {
	const meta = b.parts.get(r.pid);
	if (!meta) return;
	meta.left = true;
	const p = partyById(meta.id);
	acctBattle.delete(r.acct);
	if (!p) return;
	const rec = OUT.rec(r.acct);
	const ls = heroLosses(p, r.down, rec);
	p.busy = void 0;
	p.grace = S.time + 2;
	if (rec?.hero) rec.hero.hp = Math.min(rec.hero.hp, Math.max(.05, r.heroHp));
	syncRec(p);
	OUT.send(r.acct, {
		t: "patch",
		data: {
			troops: p.troops,
			hp: rec?.hero?.hp
		},
		why: "battle"
	});
	BOUT.json(r.acct, {
		t: "bend",
		bid: b.bid,
		win: false,
		retreat: true,
		out: outcomeFor(r, false, {}, true),
		lines: [`你率部撤出了战场。`, ls.killed + ls.wounded ? `我军阵亡 ${ls.killed} 人，负伤 ${ls.wounded} 人。` : ""].filter(Boolean),
		gold: 0
	});
}
function outcomeFor(r, win, enemyDown, retreat) {
	return {
		win,
		ourDown: r.down,
		enemyDown,
		heroDown: r.heroDown,
		compDown: r.compDown,
		retreat,
		manual: true,
		kills: r.kills
	};
}
function applyEnd(b, res) {
	b.ended = true;
	battles.delete(b.bid);
	b.host.battles = Math.max(0, b.host.battles - 1);
	const W0 = res.winner;
	const all = [...b.parts.values()].filter((m) => !m.left);
	const side = (s) => all.filter((m) => m.side === s);
	const enemyDownOf = (s) => {
		const c = {};
		for (const m of all) if (m.side !== s) for (const id in res.downPid[String(m.id)] ?? {}) c[id] = (c[id] ?? 0) + res.downPid[String(m.id)][id];
		return c;
	};
	const winners = W0 >= 0 ? side(W0) : [];
	const losers = W0 >= 0 ? side(1 - W0) : [];
	let loot = 0;
	const taken = /* @__PURE__ */ new Map();
	for (const m of losers) {
		const p = partyById(m.id);
		if (!p) continue;
		const g = Math.round(p.gold * (p.kind === "hero" ? .25 : .5));
		loot += g;
		p.gold -= g;
		taken.set(p.id, g);
	}
	if (W0 >= 0) loot += Math.round(casPow(enemyDownOf(W0)) * 3);
	const winHeroes = winners.filter((m) => m.kind === "hero");
	const wsum = winHeroes.reduce((s, m) => s + (res.killsBy[String(m.id)] ?? 0) + 1, 0);
	const topLord = winners.find((m) => m.kind === "lord");
	const topHero = [...winHeroes].sort((x, y) => (res.killsBy[String(y.id)] ?? 0) - (res.killsBy[String(x.id)] ?? 0))[0];
	const title = (() => {
		const nm = (ms) => ms.length > 1 ? `${ms[0].name}等${ms.length}部` : ms[0]?.name ?? "";
		if (W0 < 0) return "两败俱伤";
		return `${nm(winners)}击败了${nm(losers)}`;
	})();
	log(`${title}（${placeName(b.x, b.y)}，鏖战 ${Math.max(1, Math.round(res.dur / 60))} 分钟）。`, all.some((m) => m.kind === "hero") ? "war" : "dim");
	for (const m of all) {
		const p = partyById(m.id);
		if (m.acct) acctBattle.delete(m.acct);
		if (!p) continue;
		p.busy = void 0;
		const down = res.downPid[String(m.id)];
		const won = W0 === m.side;
		if (p.kind === "hero" && p.acct) {
			const rec = OUT.rec(p.acct);
			const cr = res.cmds.find((c) => c.pid === String(m.id));
			const ls = heroLosses(p, down, rec);
			const lines = [`${title}。`];
			if (ls.killed + ls.wounded) lines.push(`我军阵亡 ${ls.killed} 人，负伤 ${ls.wounded} 人。`);
			const kills = res.killsBy[String(m.id)] ?? 0;
			if (kills) lines.push(`你部共击倒敌军 ${kills} 人。`);
			let gold = 0;
			if (won) {
				gold = wsum ? Math.floor(loot * (kills + 1) / wsum) : 0;
				p.gold += gold;
				if (gold) lines.push(`分得战利品 ${gold} 两银子。`);
				p.grace = S.time + 1.5;
			} else if (W0 >= 0) {
				const tg = taken.get(p.id) ?? 0;
				gold = -tg;
				if (tg) lines.push(`你丢失了 ${tg} 两银子。`);
				let cap = 0;
				for (const st of [...p.troops]) {
					const k = Math.round((st.n - st.w) * .3);
					if (k > 0) {
						removeTroops(p.troops, st.id, k);
						cap += k;
					}
				}
				cleanStacks(p.troops);
				if (cap) lines.push(`溃散中又有 ${cap} 人被俘。`);
				const refuge = nearestFriendlyTown$1(p);
				if (refuge) {
					p.x = refuge.x + 6;
					p.y = refuge.y + 6;
					lines.push(`你退到了${refuge.name}。`);
				}
				heroNav.delete(p.id);
				p.grace = S.time + 6;
			} else p.grace = S.time + 2;
			const hp = cr ? cr.heroDown ? .15 : Math.max(.05, cr.heroHp) : rec?.hero?.hp ?? 1;
			if (rec?.hero) rec.hero.hp = Math.min(rec.hero.hp ?? 1, hp);
			p.hp = rec?.hero?.hp;
			syncRec(p);
			OUT.send(p.acct, {
				t: "patch",
				data: {
					troops: p.troops,
					addGold: gold,
					hp: p.hp,
					...won || W0 < 0 ? {} : {
						x: p.x,
						y: p.y
					}
				},
				why: "battle"
			});
			if (OUT.online(p.acct)) BOUT.json(p.acct, {
				t: "bend",
				bid: b.bid,
				win: won,
				retreat: false,
				out: outcomeFor(cr ?? {
					acct: p.acct,
					pid: String(p.id),
					side: m.side,
					down: down ?? {},
					heroDown: false,
					compDown: [],
					heroHp: 1,
					kills,
					retreat: false
				}, won, enemyDownOf(m.side), false),
				lines,
				gold
			});
			else OUT.send(p.acct, {
				t: "report",
				title: won ? "胜利" : "战败",
				lines
			});
		} else {
			applyPartyLosses(p, down);
			cleanStacks(p.troops);
			if (!won && W0 >= 0) {
				if (p.lordId && S.lords[p.lordId]) S.lords[p.lordId].grudge = topHero?.acct ? "P:" + topHero.acct : topLord ? partyById(topLord.id)?.lordId : void 0;
				removeParty(p);
			} else if (healthy(p.troops) <= 0) removeParty(p);
			else {
				p.ai.mode = "idle";
				p.ai.path = [];
				p.ai.nextThink = S.time + 1;
				p.grace = S.time + 1;
			}
		}
	}
}
function nearestFriendlyTown$1(p) {
	let best = null, bd = Infinity;
	for (const s of settlementList()) {
		if (s.kind === "village" || factionHostileToSettlement(p.faction, s)) continue;
		const d = Math.hypot(p.x - s.x, p.y - s.y);
		if (d < bd) {
			bd = d;
			best = s;
		}
	}
	return best;
}
/** 异常时释放所有参战部队（不结算） */
function releaseAll(b) {
	b.ended = true;
	battles.delete(b.bid);
	b.host.battles = Math.max(0, b.host.battles - 1);
	for (const m of b.parts.values()) {
		const p = partyById(m.id);
		if (p && p.busy === -b.bid) {
			p.busy = void 0;
			p.grace = S.time + 1;
		}
		if (m.acct) {
			acctBattle.delete(m.acct);
			BOUT.json(m.acct, {
				t: "bgone",
				bid: b.bid
			});
		}
	}
}
/** GM：强制结束（自动结算） */
function abortBattle(bid) {
	const b = battles.get(bid);
	if (!b) return false;
	b.host.post({
		k: "abort",
		bid
	});
	return true;
}
function abortAll() {
	for (const b of battles.values()) b.host.post({
		k: "abort",
		bid: b.bid
	});
}
//#endregion
//#region server/world.ts
var CFG = {
	hoursPerSec: .4,
	allianceOpenDay: 36,
	pvp: true,
	motd: "欢迎来到《铁血大明》联机世界！"
};
/** 发给某个玩家（由网络层注入） */
var OUT = {
	send: () => {},
	broadcast: () => {},
	online: () => false,
	rec: () => void 0,
	gmLevel: () => 0
};
function godOf(p) {
	if (!p || p.kind !== "hero" || !p.acct) return null;
	const r = OUT.rec(p.acct);
	if (!r?.god?.on || OUT.gmLevel(p.acct) < 2) return null;
	return r.god;
}
var godHidden = (p) => p.kind === "hero" && !!godOf(p)?.hidden;
var godAny = (p) => !!godOf(p)?.any;
/** 天命状态变化后：同步部队上的隐身标记 */
function refreshGod(acct) {
	const p = heroOf(acct);
	if (!p) return;
	p.hidden = !!godOf(p)?.hidden || void 0;
	if (p.hidden) {
		for (const q of S.parties) if (q.ai.mode === "chase" && q.ai.target === p.id) {
			q.ai.mode = "idle";
			q.ai.path = [];
			q.ai.nextThink = S.time + .5;
		}
	}
}
/** 玩家截击玩家前的新手保护检查：返回 true 表示可以开战 */
function pvpAllowed(att, def) {
	const left = newbieLeft(OUT.rec(def.acct));
	if (left > 0) {
		OUT.send(att.acct, {
			t: "report",
			title: "新手保护",
			lines: [`${def.name}初出茅庐（新手保护还剩 ${Math.ceil(left / 6e4)} 分钟），此时不能截击。`]
		});
		return false;
	}
	const ar = OUT.rec(att.acct);
	if (ar && !ar.pvpOptIn) {
		if (newbieLeft(ar) > 0) OUT.send(att.acct, {
			t: "log",
			msg: "你主动截击他人，新手保护就此解除。",
			cls: "bad"
		});
		ar.pvpOptIn = true;
	}
	return true;
}
var heroNav = /* @__PURE__ */ new Map();
var encounters = /* @__PURE__ */ new Map();
var nextEid = 1;
var dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);
function heroOf(acct) {
	return S.parties.find((p) => p.kind === "hero" && p.acct === acct);
}
function initWorld(saved) {
	buildGrid();
	WORLD_OPT.personal = false;
	RECRUIT.realtime = true;
	if (saved) {
		const st = JSON.parse(saved);
		st.pendingDefense = null;
		setState(st);
		ensureWorld(st);
		for (const p of [...S.parties]) if (p.kind === "hero") removeParty(p);
		for (const p of S.parties) p.busy = void 0;
		console.log(`[world] loaded: ${Object.keys(S.settlements).length} settlements, ${S.parties.length} parties, day ${Math.floor(S.time / 24)}`);
	} else {
		newGame("天下", "soldier");
		console.log("[world] new world created");
	}
	S.treaties ??= [];
	installCustomFactions(S.customFactions);
	applyRenames();
	const dummy = S.parties.find((p) => p.id === S.playerId);
	dummy.troops = [];
	dummy.gold = 0;
	dummy.goods = {};
	dummy.hidden = true;
	dummy.inside = Object.values(S.settlements).find((s) => s.kind === "town").id;
	S.playerFaction = null;
	S.mercOf = null;
	installHooks();
}
function worldJSON() {
	return JSON.stringify(S);
}
var lastLogLen = 0;
function tick(realSec) {
	const dummy = S.parties.find((p) => p.id === S.playerId);
	if (dummy) {
		dummy.troops = [];
		dummy.x = S.settlements[dummy.inside ?? ""]?.x ?? dummy.x;
	}
	if (CFG.paused) {
		for (const p of S.parties) if (p.kind === "hero" && !p.inside && godOf(p)) guard("godMove", () => heroMove(p, realSec * .4, false));
		guard("encounters", checkEncounterTimeouts);
	} else {
		const hours = realSec * CFG.hoursPerSec;
		guard("simulate", () => {
			simulate(hours);
		});
		guard("recruits", () => tickRecruits(realSec));
		guard("encounters", checkEncounterTimeouts);
		guard("sieges", checkHeroSieges);
		guard("diplomacy", () => tickDiplomacy(realSec));
	}
	if (S.log.length !== lastLogLen) {
		const fresh = S.log.slice(Math.max(0, lastLogLen > S.log.length ? S.log.length - 5 : lastLogLen));
		for (const e of fresh) if (e.cls === "war" || e.cls === "gold" || e.cls === "event") OUT.broadcast({
			t: "log",
			msg: e.msg,
			cls: e.cls
		});
		lastLogLen = S.log.length;
	}
}
function installHooks() {
	SIM_HOOKS.heroMove = heroMove;
	SIM_HOOKS.heroContact = heroContact;
	on("daily", () => {});
}
function nationStart(f) {
	const own = settlementList().filter((s) => s.faction === f && s.kind === "town");
	const alt = settlementList().filter((s) => s.faction === f && s.kind !== "village");
	const pool = own.length ? own : alt.length ? alt : settlementList().filter((s) => s.kind === "town");
	return pool[Math.floor(Math.random() * pool.length)];
}
/** 新建玩家档案（复用单机的出身设定） */
function createRec(name, nation, bg) {
	const saveHero = S.hero, savePid = S.playerId;
	const tmp = makeParty("hero", name, nation, 0, 0, []);
	S.hero = newHero(name);
	S.playerId = tmp.id;
	const b = BACKGROUNDS.find((x) => x.id === bg) ?? BACKGROUNDS[0];
	try {
		b.apply(S);
	} catch (e) {
		console.error("[world] background", e);
	}
	const hero = S.hero;
	const culture = FACTION[nation].culture;
	const rec = {
		name,
		nation,
		bg: b.id,
		hero,
		troops: tmp.troops.map((s) => ({
			...s,
			id: s.id === "ming_recruit" ? RECRUIT_OF[culture] ?? s.id : s.id
		})),
		prisoners: [],
		gold: tmp.gold,
		goods: {
			...tmp.goods,
			grain: (tmp.goods.grain ?? 0) + 6
		},
		renown: 20,
		honor: 0,
		morale: 70,
		companions: [],
		quests: [],
		stats: {
			kills: 0,
			won: 0,
			lost: 0,
			days: 0
		},
		playerRel: { [nation]: 20 },
		created: Date.now(),
		rank: 0
	};
	removeParty(tmp);
	S.hero = saveHero;
	S.playerId = savePid;
	if (count(rec.troops) < 5) addTroops(rec.troops, RECRUIT_OF[culture] ?? "ming_recruit", 5 - count(rec.troops));
	const st = nationStart(nation);
	rec.x = st.x + 6;
	rec.y = st.y + 6;
	return rec;
}
function spawnHero(rec) {
	const old = heroOf(rec.name);
	if (old) {
		if (rec.nation) old.faction = rec.nation;
		return old;
	}
	let x = rec.x ?? 0, y = rec.y ?? 0;
	if (!rec.x || !findPath(x, y, x + 1, y + 1)) {
		const st = nationStart(rec.nation ?? "ming");
		x = st.x + 6;
		y = st.y + 6;
	}
	const p = makeParty("hero", rec.name, rec.nation ?? "ming", x, y, rec.troops, {
		acct: rec.name,
		gold: rec.gold,
		goods: rec.goods,
		prisoners: rec.prisoners
	});
	p.ai.nextThink = Infinity;
	p.hp = rec.hero.hp;
	p.lvl = rec.hero.level;
	p.grace = S.time + 1;
	p.hidden = !!godOf(p)?.hidden || void 0;
	return p;
}
function despawnHero(acct, rec) {
	const p = heroOf(acct);
	if (!p) return;
	rec.x = p.x;
	rec.y = p.y;
	rec.troops = p.troops;
	rec.gold = p.gold;
	rec.goods = p.goods;
	rec.prisoners = p.prisoners;
	const home = settlementList().filter((s) => s.kind !== "village" && !factionHostileToSettlement(p.faction, s)).sort((a, b) => dist(a.x, a.y, p.x, p.y) - dist(b.x, b.y, p.x, p.y))[0];
	if (home) {
		rec.x = home.x + 6;
		rec.y = home.y + 6;
	}
	for (const [eid, e] of encounters) if (e.hero === p.id) endEncounter(eid);
	heroNav.delete(p.id);
	for (const s of settlementList()) if (s.siege && s.siege.by === p.id) s.siege = null;
	removeParty(p);
}
/** 客户端上传的私有数据：合理性检查后写入 */
function applySync(rec, data) {
	const p = heroOf(rec.name);
	let warn = null;
	for (const k of PRIVATE_KEYS) if (k in data) rec[k] = data[k];
	if (data.troops) {
		const n = count(data.troops);
		if (n > 2500 && !(rec.god?.on && OUT.gmLevel(rec.name) >= 2)) {
			warn = `兵力异常 ${n}`;
			rec.troops = rec.troops.slice(0, 20);
		}
		rec.troops = rec.troops.filter((s) => TROOPS[s.id] && s.n > 0).map((s) => ({
			id: s.id,
			n: Math.floor(s.n),
			w: Math.max(0, Math.min(s.n, Math.floor(s.w))),
			xp: s.xp || 0
		}));
	}
	if (typeof data.gold === "number" && p && data.gold - p.gold > 5e4 && !godOf(p)) warn = `银两暴涨 ${p.gold} → ${data.gold}`;
	if (p) {
		p.troops = rec.troops;
		p.gold = rec.gold;
		p.goods = rec.goods;
		p.prisoners = rec.prisoners;
		p.hp = rec.hero.hp;
		p.lvl = rec.hero.level;
	}
	return warn;
}
function setHeroNav(p, kind, x, y, id) {
	p.inside = void 0;
	let tx, ty;
	if (kind === "point") {
		tx = x;
		ty = y;
	} else if (kind === "settlement") {
		const st = S.settlements[String(id)];
		if (!st) return false;
		tx = st.x;
		ty = st.y;
	} else {
		const t = partyById(Number(id));
		if (!t || t === p) return false;
		tx = t.x;
		ty = t.y;
	}
	const path = findPath(p.x, p.y, tx, ty, whoOf(p));
	if (!path) {
		heroNav.delete(p.id);
		return false;
	}
	heroNav.set(p.id, {
		kind,
		id,
		x: tx,
		y: ty,
		path,
		lastPathAt: S.time
	});
	return true;
}
function stopHero(p) {
	heroNav.delete(p.id);
}
function heroMove(p, h, night) {
	const nv = heroNav.get(p.id);
	if (!nv) return;
	if (nv.kind === "party") {
		const tp = partyById(Number(nv.id));
		if (!tp || tp.inside) {
			heroNav.delete(p.id);
			OUT.send(p.acct, { t: "navEnd" });
			return;
		}
		if (dist(p.x, p.y, tp.x, tp.y) < 100 && !wallBetween(p.x, p.y, tp.x, tp.y, whoOf(p))) nv.path = [[tp.x, tp.y]];
		else if (S.time - nv.lastPathAt > 1.5) {
			nv.path = findPath(p.x, p.y, tp.x, tp.y, whoOf(p)) ?? nv.path;
			nv.lastPathAt = S.time;
		}
	}
	const g = godOf(p);
	moveAlong(p, nv.path, mapSpeed(S, p, night) * h * (g ? g.mapSpeed : 1));
	if (nv.kind === "settlement") {
		const st = S.settlements[String(nv.id)];
		if (!st) {
			heroNav.delete(p.id);
			return;
		}
		if (dist(p.x, p.y, st.x, st.y) < (st.isPass ? 40 : 10) || !nv.path.length) {
			heroNav.delete(p.id);
			OUT.send(p.acct, {
				t: "arrive",
				st: st.id
			});
		}
	} else if (nv.kind === "party") {
		const tp = partyById(Number(nv.id));
		if (tp && dist(p.x, p.y, tp.x, tp.y) < 12) {
			heroNav.delete(p.id);
			if (tp.kind === "hero" && g?.any && !tp.busy) startEncounter(p, tp, false);
			else if (tp.kind === "hero") {
				if (hostile(p, tp) && CFG.pvp && !tp.busy) {
					if (pvpAllowed(p, tp) && !startRT(p, tp, `${p.name}截击了${tp.name}：`)) heroBattle(p, tp, "你截住了");
				} else OUT.send(p.acct, {
					t: "report",
					title: "相遇",
					lines: [`你遇到了${FACTION[tp.faction]?.name ?? ""}的${tp.name}（${healthy(tp.troops)} 人）。`]
				});
			} else if ((hostile(p, tp) || g?.any) && !tp.busy) startEncounter(p, tp, false);
			else OUT.send(p.acct, {
				t: "encounter",
				enemy: tp.id,
				forced: false,
				eid: 0
			});
		}
	} else if (!nv.path.length) {
		heroNav.delete(p.id);
		OUT.send(p.acct, { t: "navEnd" });
	}
}
function heroContact(hero, other) {
	if (hero.busy || other.busy) return;
	if (godHidden(hero) || other.kind === "hero" && godHidden(other)) return;
	if (other.kind === "hero") {
		if (!CFG.pvp || !hostile(hero, other)) return;
		const navA = heroNav.get(hero.id), navB = heroNav.get(other.id);
		const aChases = navA?.kind === "party" && Number(navA.id) === other.id;
		const bChases = navB?.kind === "party" && Number(navB.id) === hero.id;
		if (!aChases && !bChases) return;
		const [att, def] = aChases ? [hero, other] : [other, hero];
		if (!godOf(att) && !pvpAllowed(att, def)) {
			heroNav.delete(att.id);
			OUT.send(att.acct, { t: "navEnd" });
			return;
		}
		if (!startRT(att, def, `${att.name}截击了${def.name}：`)) heroBattle(hero, other, "两军相遇：");
		return;
	}
	const chased = other.ai.mode === "chase" && other.ai.target === hero.id;
	const nv = heroNav.get(hero.id);
	const mine = nv?.kind === "party" && Number(nv.id) === other.id;
	if (!chased && !mine) return;
	if (!OUT.online(hero.acct)) {
		heroBattle(other, hero, "");
		return;
	}
	startEncounter(hero, other, chased && !mine);
}
function startEncounter(hero, enemy, forced) {
	const eid = nextEid++;
	encounters.set(eid, {
		eid,
		acct: hero.acct,
		hero: hero.id,
		enemy: enemy.id,
		started: Date.now(),
		forced
	});
	hero.busy = eid;
	enemy.busy = eid;
	heroNav.delete(hero.id);
	enemy.ai.path = [];
	OUT.send(hero.acct, {
		t: "encounter",
		enemy: enemy.id,
		forced,
		eid
	});
}
function endEncounter(eid, graceH = 1.5) {
	const e = encounters.get(eid);
	if (!e) return;
	encounters.delete(eid);
	const h = partyById(e.hero), en = partyById(e.enemy);
	if (h) {
		h.busy = void 0;
		h.grace = S.time + graceH;
	}
	if (en) {
		en.busy = void 0;
		en.ai.mode = "idle";
		en.ai.path = [];
		en.ai.nextThink = S.time + 2;
	}
}
var ENC_TIMEOUT_MS = 9e5;
function checkEncounterTimeouts() {
	const now = Date.now();
	for (const [eid, e] of encounters) {
		const h = partyById(e.hero), en = partyById(e.enemy);
		if (!h || !en) {
			endEncounter(eid);
			continue;
		}
		if (!e.fighting && now - e.started > 9e4 && OUT.online(e.acct)) {
			endEncounter(eid, .5);
			continue;
		}
		const tooLong = now - e.started > ENC_TIMEOUT_MS;
		const gone = !OUT.online(e.acct) && now - e.started > 2e4;
		if (tooLong || gone) {
			endEncounter(eid, 0);
			heroBattle(en, h, "（自动结算）");
		}
	}
}
/** 服务器自动结算：玩家对玩家、离线/超时的玩家对 AI。附近的领主与玩家会按敌我自动加入（三方混战） */
function heroBattle(a, b, prefix) {
	const A = [a], B = [b];
	for (const p of S.parties) {
		if (p === a || p === b || p.inside || p.busy || p.kind !== "lord" && p.kind !== "hero" || p.hidden) continue;
		if (dist(p.x, p.y, a.x, a.y) > 60) continue;
		const ha = hostile(p, a), hb = hostile(p, b);
		if (hb && !ha && A.length < 8) A.push(p);
		else if (ha && !hb && B.length < 8) B.push(p);
	}
	const pa = A.map((p) => ({
		pid: String(p.id),
		stacks: p.troops
	})), pb = B.map((p) => ({
		pid: String(p.id),
		stacks: p.troops
	}));
	const lead = (xs) => xs.reduce((s, p) => s + (p.kind === "lord" ? 8 : p.kind === "hero" ? 6 + (p.lvl ?? 1) : 0), 0);
	const mult = (xs) => xs.some((p) => p.kind === "lord" || p.kind === "hero") ? 1.1 : 1;
	const r = autoResolve(mergeStacks(pa), mergeStacks(pb), mult(A), mult(B), lead(A), lead(B));
	const godA = A.some((p) => godOf(p)?.invincible);
	if (godA !== B.some((p) => godOf(p)?.invincible)) {
		const allDown = (xs) => {
			const c = {};
			for (const s of xs) c[s.id] = (c[s.id] ?? 0) + s.n - s.w;
			return c;
		};
		if (godA) {
			r.aWin = true;
			r.aDown = {};
			r.bDown = allDown(mergeStacks(pb));
		} else {
			r.aWin = false;
			r.bDown = {};
			r.aDown = allDown(mergeStacks(pa));
		}
	}
	const da = splitDown(r.aDown, pa), db = splitDown(r.bDown, pb);
	const lossA = /* @__PURE__ */ new Map(), lossB = /* @__PURE__ */ new Map();
	for (const p of A) lossA.set(p, applyPartyLosses(p, da[String(p.id)]));
	for (const p of B) lossB.set(p, applyPartyLosses(p, db[String(p.id)]));
	const win = r.aWin ? A : B, lose = r.aWin ? B : A;
	const nm = (xs) => xs.length > 1 ? `${partyLabel(xs[0])}等${xs.length}路兵马` : partyLabel(xs[0]);
	const title = `${nm(win)}击败了${nm(lose)}`;
	log(`${prefix}${title}。`, win.some((p) => p.kind === "hero") || lose.some((p) => p.kind === "hero") ? "war" : "dim");
	let lootGold = 0;
	for (const p of lose) lootGold += Math.round(p.gold * (p.kind === "hero" ? .25 : .5));
	const winHeroes = win.filter((p) => p.kind === "hero");
	const share = winHeroes.length ? Math.floor(lootGold / winHeroes.length) : 0;
	for (const p of win) {
		cleanStacks(p.troops);
		if (p.kind === "hero") {
			p.gold += share;
			OUT.send(p.acct, {
				t: "patch",
				data: {
					troops: p.troops,
					addGold: share
				},
				why: "battle"
			});
			OUT.send(p.acct, {
				t: "report",
				title: "胜利",
				lines: [
					`${title}。`,
					`我军损失 ${(r.aWin ? lossA : lossB).get(p) ?? 0} 人。`,
					share ? `缴获 ${share} 两银子。` : ""
				].filter(Boolean)
			});
			p.grace = S.time + 1;
		} else if (healthy(p.troops) <= 0) removeParty(p);
		else {
			p.ai.mode = "idle";
			p.ai.nextThink = S.time + 1;
		}
	}
	for (const p of lose) if (p.kind === "hero") heroDefeated(p, title);
	else {
		if (p.lordId && S.lords[p.lordId]) S.lords[p.lordId].grudge = win.find((w) => w.lordId)?.lordId;
		removeParty(p);
	}
}
/** 玩家战败：折损、失银、退回最近的本国城镇，短暂免战 */
function heroDefeated(p, why) {
	const lostGold = Math.round(p.gold * .3);
	p.gold -= lostGold;
	for (const st of [...p.troops]) st.n -= Math.round(st.n * .5);
	cleanStacks(p.troops);
	for (const st of p.troops) st.w = Math.min(st.w, st.n);
	const refuge = nearestFriendlyTown(p);
	if (refuge) {
		p.x = refuge.x + 6;
		p.y = refuge.y + 6;
	}
	heroNav.delete(p.id);
	p.grace = S.time + 6;
	p.hp = .2;
	OUT.send(p.acct, {
		t: "patch",
		data: {
			troops: p.troops,
			addGold: -lostGold,
			x: p.x,
			y: p.y,
			hp: .2
		},
		why: "defeat"
	});
	OUT.send(p.acct, {
		t: "report",
		title: "战败",
		lines: [
			`${why}。`,
			`你兵败溃走，损失 ${lostGold} 两银子，残部只剩 ${healthy(p.troops)} 人。`,
			refuge ? `你退到了${refuge.name}。` : ""
		].filter(Boolean)
	});
}
function nearestFriendlyTown(p) {
	let best = null, bd = Infinity;
	for (const s of settlementList()) {
		if (s.kind === "village" || factionHostileToSettlement(p.faction, s)) continue;
		const d = dist(p.x, p.y, s.x, s.y);
		if (d < bd) {
			bd = d;
			best = s;
		}
	}
	return best;
}
function checkHeroSieges() {
	for (const s of settlementList()) {
		if (!s.siege) continue;
		const p = partyById(s.siege.by);
		if (!p) {
			s.siege = null;
			continue;
		}
		if (p.kind === "hero" && dist(p.x, p.y, s.x, s.y) > 60) s.siege = null;
	}
}
var near = (p, st, r = 45) => p.inside === st.id || dist(p.x, p.y, st.x, st.y) < (st.isPass ? 60 : r);
function handleReq(rec, op, a) {
	const p = heroOf(rec.name);
	if (!p) return {
		ok: false,
		err: "你不在世界中"
	};
	const st = a?.st ? S.settlements[a.st] : void 0;
	switch (op) {
		case "recruit": {
			if (!st || !near(p, st)) return {
				ok: false,
				err: "离得太远"
			};
			const n = Math.max(0, Math.min(Math.floor(a.n), Math.floor(st.recruits)));
			if (n <= 0) return {
				ok: false,
				err: "这里已经没有人愿意从军了"
			};
			st.recruits -= n;
			return {
				ok: true,
				data: {
					n,
					troop: recruitTroopOf(st),
					left: Math.floor(st.recruits)
				}
			};
		}
		case "buyItem": {
			if (!st || !near(p, st)) return {
				ok: false,
				err: "离得太远"
			};
			const i = st.shop.indexOf(a.id);
			if (i < 0) return {
				ok: false,
				err: "这件货已经被别人买走了"
			};
			st.shop.splice(i, 1);
			return { ok: true };
		}
		case "sellItem":
			if (!st || !near(p, st)) return {
				ok: false,
				err: "离得太远"
			};
			if (st.shop.length < 80) st.shop.push(a.id);
			return { ok: true };
		case "trade": {
			if (!st || !near(p, st)) return {
				ok: false,
				err: "离得太远"
			};
			const g = String(a.g), n = Math.floor(a.n);
			const have = st.stock[g] ?? 0;
			if (n > 0 && have < n) return {
				ok: false,
				err: "存货不足",
				data: { stock: have }
			};
			st.stock[g] = Math.max(0, have - n);
			return {
				ok: true,
				data: { stock: st.stock[g] }
			};
		}
		case "mercs": {
			if (!st || !near(p, st)) return {
				ok: false,
				err: "离得太远"
			};
			const m = st.tavern.mercs;
			if (!m) return {
				ok: false,
				err: "佣兵已经被别人雇走了"
			};
			st.tavern.mercs = null;
			return {
				ok: true,
				data: m
			};
		}
		case "companion":
			if (!st || !near(p, st)) return {
				ok: false,
				err: "离得太远"
			};
			if (!st.tavern.companion) return {
				ok: false,
				err: "那人已经跟别人走了"
			};
			st.tavern.companion = null;
			return { ok: true };
		case "raid":
			if (!st || st.kind !== "village" || !near(p, st, 30)) return {
				ok: false,
				err: "离得太远"
			};
			if (st.lootedUntil > S.time) return {
				ok: false,
				err: "这里刚被洗劫过"
			};
			st.lootedUntil = S.time + 96;
			st.prosperity = Math.max(5, st.prosperity - 15);
			st.recruits = 0;
			log(`${p.name}洗劫了${FACTION[st.faction]?.name ?? ""}的${st.name}！`, "war");
			return { ok: true };
		case "siege":
			if (!st || st.kind === "village" || !near(p, st, 40)) return {
				ok: false,
				err: "离得太远"
			};
			if (!factionHostileToSettlement(p.faction, st) && !godAny(p) && st.owner !== "P:" + rec.name) return {
				ok: false,
				err: "这不是敌城"
			};
			if (!factionHostileToSettlement(p.faction, st) && st.owner === "P:" + rec.name) return {
				ok: false,
				err: "这是你自己的封地"
			};
			if (st.siege && st.siege.by !== p.id) {
				const by = partyById(st.siege.by);
				if (by && !hostile(by, p)) return {
					ok: true,
					data: { joined: true }
				};
			}
			st.siege = {
				by: p.id,
				since: S.time
			};
			log(`${p.name}率军围攻${st.name}！`, "war");
			return { ok: true };
		case "siegeEnd":
			if (st && st.siege?.by === p.id) st.siege = null;
			return { ok: true };
		case "enc": {
			const e = encounters.get(Number(a.eid));
			if (e && e.acct === rec.name) {
				if (a.fight) {
					e.fighting = true;
					e.started = Date.now();
				} else endEncounter(e.eid, a.flee ? 1.5 : .5);
			}
			return { ok: true };
		}
		case "battle": return applyBattle(rec, p, a);
		case "bfight": {
			const e = encounters.get(Number(a?.eid));
			if (!e || e.acct !== rec.name) return {
				ok: false,
				err: "遭遇已经结束"
			};
			const en = partyById(e.enemy);
			if (!en) {
				endEncounter(e.eid);
				return {
					ok: false,
					err: "对方已经离开"
				};
			}
			p.busy = void 0;
			en.busy = void 0;
			const bid = startRT(p, en, "");
			if (!bid) {
				p.busy = e.eid;
				en.busy = e.eid;
				return {
					ok: false,
					err: "无法开启实时战斗"
				};
			}
			return {
				ok: true,
				data: { bid }
			};
		}
		case "garrison":
			if (!st || st.owner !== "P:" + rec.name) return {
				ok: false,
				err: "这不是你的封地"
			};
			st.garrison = a.garrison.filter((s) => TROOPS[s.id] && s.n > 0);
			return { ok: true };
		case "cannon":
		case "noop": return { ok: true };
	}
	return {
		ok: false,
		err: "未知操作 " + op
	};
}
/** 客户端打完一场实时战斗后上报结果（PvE / 攻城） */
function applyBattle(rec, p, a) {
	const e = a.eid ? encounters.get(a.eid) : void 0;
	const fix = (pt, rep) => {
		if (!rep) return;
		const before = healthy(pt.troops);
		if (rep.filter((s) => TROOPS[s.id]).reduce((n, s) => n + s.n - s.w, 0) <= before) pt.troops = rep.filter((s) => TROOPS[s.id] && s.n > 0).map((s) => ({
			id: s.id,
			n: s.n,
			w: s.w,
			xp: s.xp ?? 0
		}));
	};
	const ids = [a.enemy, ...a.extras ?? []].filter((x) => typeof x === "number");
	for (const id of ids) {
		const en = partyById(id);
		if (!en || dist(en.x, en.y, p.x, p.y) > 120) continue;
		if (en.kind === "hero") {
			if (!godOf(p)?.any) continue;
			fix(en, a.left?.[String(id)]);
			cleanStacks(en.troops);
			if (a.win || healthy(en.troops) <= 0) heroDefeated(en, `${p.name}击溃了你的军队`);
			else {
				OUT.send(en.acct, {
					t: "patch",
					data: { troops: en.troops },
					why: "battle"
				});
				en.grace = S.time + 2;
			}
			continue;
		}
		fix(en, a.left?.[String(id)]);
		if (a.win || healthy(en.troops) <= 0) {
			if (en.lordId && S.lords[en.lordId]) {
				S.lords[en.lordId].grudge = "P:" + rec.name;
				log(`${p.name}击败了${FACTION[en.faction]?.name ?? ""}的${S.lords[en.lordId].name}！`, "war");
			}
			removeParty(en);
		} else {
			en.busy = void 0;
			en.ai.mode = "idle";
			en.ai.path = [];
			en.ai.nextThink = S.time + 3;
		}
	}
	if (e) endEncounter(e.eid, 2);
	let captured = false;
	if (a.siege) {
		const st = S.settlements[a.siege];
		if (st && near(p, st, 60) && (factionHostileToSettlement(p.faction, st) || godAny(p))) {
			if (a.win) {
				const old = st.faction;
				setOwner(st, p.faction, "P:" + rec.name);
				st.garrison = (a.captureGarrison ?? []).filter((s) => TROOPS[s.id] && s.n > 0).slice(0, 12);
				log(`${FACTION[p.faction]?.name ?? ""}的${p.name}攻占了${st.name}！`, "war");
				checkFactionAlive(old);
				captured = true;
			} else if (a.garrisonLeft) {
				const before = healthy(st.garrison);
				if (a.garrisonLeft.reduce((n, s) => n + s.n - s.w, 0) <= before) st.garrison = a.garrisonLeft.filter((s) => TROOPS[s.id] && s.n > 0);
				st.siege = null;
			}
		}
	}
	if (!a.win && !a.retreat) {
		const refuge = nearestFriendlyTown(p);
		if (refuge) {
			p.x = refuge.x + 6;
			p.y = refuge.y + 6;
		}
		p.grace = S.time + 6;
		heroNav.delete(p.id);
		return {
			ok: true,
			data: {
				x: p.x,
				y: p.y
			}
		};
	}
	p.grace = S.time + 2;
	return {
		ok: true,
		data: { captured }
	};
}
/** 未显圣的天命之主：广播给别人的兵种换成本国同类精兵，免得一看“金甲天骑”就露馅（自己的真实兵马走 rec，不受影响） */
var disguiseCache = /* @__PURE__ */ new Map();
function disguiseId(id, faction) {
	const key = id + "|" + faction;
	let r = disguiseCache.get(key);
	if (!r) {
		const want = TROOPS[id], culture = FACTION[faction]?.culture ?? "ming";
		const pool = Object.values(TROOPS).filter((t) => t.culture === culture);
		const score = (t) => (t.cls === want.cls ? 100 : t.mounted === want.mounted ? 50 : 0) + (!!t.rng === !!want.rng ? 20 : 0) + t.tier;
		r = pool.sort((x, y) => score(y) - score(x))[0]?.id ?? RECRUIT_OF.ming;
		disguiseCache.set(key, r);
	}
	return r;
}
function publicTroops(p) {
	if (p.kind !== "hero" || !p.troops.some((st) => TROOPS[st.id]?.culture === "god") || godOf(p)?.reveal) return p.troops;
	const out = [];
	for (const st of p.troops) {
		const id = TROOPS[st.id]?.culture === "god" ? disguiseId(st.id, p.faction) : st.id;
		const o = out.find((x) => x.id === id);
		if (o) {
			o.n += st.n;
			o.w += st.w;
		} else out.push({
			...st,
			id
		});
	}
	return out;
}
function netParty(p) {
	return {
		id: p.id,
		kind: p.kind,
		name: p.name,
		faction: p.faction,
		x: Math.round(p.x * 10) / 10,
		y: Math.round(p.y * 10) / 10,
		troops: publicTroops(p),
		gold: p.gold,
		goods: p.goods,
		lordId: p.lordId,
		home: p.home,
		inside: p.inside,
		questId: void 0,
		hidden: p.hidden,
		acct: p.acct,
		busy: p.busy,
		grace: p.grace,
		hp: p.hp,
		lvl: p.lvl,
		ai: {
			mode: p.ai.mode,
			target: p.ai.target
		},
		...p.kind === "hero" && godOf(p)?.reveal && godOf(p)?.aura ? { god: 1 } : {}
	};
}
/** 广播用：去掉虚拟玩家与隐身的天命之主；me = 自己的账号（自己总是看得见自己） */
function visibleParties(me) {
	return S.parties.filter((p) => p.id !== S.playerId && (!p.hidden || p.kind !== "hero" || p.acct === me));
}
/** 隐身的天命之主：单独把自己的位置发给自己 */
function hiddenSelfPos() {
	const out = [];
	for (const p of S.parties) if (p.kind === "hero" && p.hidden && p.acct && !p.inside) out.push({
		acct: p.acct,
		m: {
			t: "pos",
			time: S.time,
			a: [
				p.id,
				Math.round(p.x * 10),
				Math.round(p.y * 10),
				p.busy ? 1 : 0
			]
		}
	});
	return out;
}
function worldSnap() {
	return {
		version: S.version,
		seed: S.seed,
		time: S.time,
		nextId: S.nextId,
		settlements: S.settlements,
		lords: S.lords,
		wars: S.wars,
		truceUntil: S.truceUntil,
		alive: S.alive,
		wallHp: S.wallHp,
		beacons: S.beacons,
		calendarDone: S.calendarDone,
		chronLog: S.chronLog,
		flags: S.flags,
		treaties: S.treaties ?? [],
		customFactions: S.customFactions
	};
}
/** 差量：只发生变化的城池/领主/部队 */
var lastStF = /* @__PURE__ */ new Map();
var lastLord = /* @__PURE__ */ new Map();
var lastParty = /* @__PURE__ */ new Map();
var lastMisc = "";
function worldDelta(full = false) {
	const sts = [], lords = [];
	for (const s of settlementList()) {
		let prev = lastStF.get(s.id);
		if (!prev) {
			prev = {};
			lastStF.set(s.id, prev);
		}
		const patch = { id: s.id };
		let n = 0;
		for (const k of Object.keys(s)) {
			if (k === "racc" || k === "id") continue;
			const v = k === "recruits" ? Math.floor(s.recruits) : s[k];
			const j = typeof v === "object" && v !== null ? JSON.stringify(v) : String(v);
			if (full || prev[k] !== j) {
				prev[k] = j;
				patch[k] = v;
				n++;
			}
		}
		if (n) sts.push(patch);
	}
	for (const l of Object.values(S.lords)) {
		const j = JSON.stringify(l);
		if (full || lastLord.get(l.id) !== j) {
			lastLord.set(l.id, j);
			lords.push(l);
		}
	}
	const fnames = Object.fromEntries(Object.entries(S.flags ?? {}).filter(([k]) => k.startsWith("fname:")));
	const misc = JSON.stringify([
		S.wars,
		S.alive,
		S.truceUntil,
		S.treaties,
		S.customFactions,
		S.chronLog?.length,
		(S.wallHp ?? []).filter((h) => h <= 0).length,
		S.beacons?.length,
		fnames
	]);
	const m = {
		t: "world",
		time: S.time
	};
	if (sts.length) m.settlements = sts;
	if (lords.length) m.lords = lords;
	if (full || misc !== lastMisc) {
		lastMisc = misc;
		Object.assign(m, {
			wars: S.wars,
			alive: S.alive,
			truceUntil: S.truceUntil,
			treaties: S.treaties,
			customFactions: S.customFactions,
			wallHp: S.wallHp,
			beacons: S.beacons,
			chronLog: S.chronLog,
			fnames
		});
	}
	return m;
}
function partiesDelta() {
	const up = [], seen = /* @__PURE__ */ new Set();
	for (const p of visibleParties()) {
		seen.add(p.id);
		const np = netParty(p);
		const j = JSON.stringify([
			np.kind,
			np.name,
			np.faction,
			np.troops,
			np.gold,
			np.inside,
			np.busy,
			np.ai.mode,
			np.ai.target,
			np.hp,
			np.lvl,
			np.hidden,
			np.lordId,
			np.god
		]);
		if (lastParty.get(p.id) !== j) {
			lastParty.set(p.id, j);
			up.push(np);
		}
	}
	const gone = [];
	for (const id of lastParty.keys()) if (!seen.has(id)) {
		gone.push(id);
		lastParty.delete(id);
	}
	return {
		t: "parties",
		up,
		gone
	};
}
var lastPos = /* @__PURE__ */ new Map();
var posFrame = 0;
function posPacket(heroesOnly = false) {
	const a = [];
	const full = !heroesOnly && posFrame++ % 12 === 0;
	for (const p of visibleParties()) {
		if (p.inside) continue;
		if (heroesOnly && p.kind !== "hero") continue;
		const x = Math.round(p.x * 10), y = Math.round(p.y * 10), f = p.busy ? 1 : 0;
		const key = (x * 4e4 + y) * 2 + f;
		if (!full && lastPos.get(p.id) === key) continue;
		a.push(p.id, x, y, f, key);
	}
	if (heroesOnly && a.length > 600) a.length = 0;
	const out = [];
	for (let i = 0; i < a.length; i += 5) {
		lastPos.set(a[i], a[i + 4]);
		out.push(a[i], a[i + 1], a[i + 2], a[i + 3]);
	}
	if (full) {
		for (const id of lastPos.keys()) if (!partyById(id)) lastPos.delete(id);
	}
	return heroesOnly ? {
		t: "pos",
		time: S.time,
		a: out,
		full: false
	} : {
		t: "pos",
		time: S.time,
		a: out
	};
}
function gmSpawnArmy(f, stId, n, troop) {
	const st = S.settlements[stId];
	if (!st) return null;
	const culture = FACTION[f]?.culture ?? "ming";
	const troops = [];
	if (troop && TROOPS[troop]) addTroops(troops, troop, n);
	else {
		const pool = Object.values(TROOPS).filter((t) => t.culture === culture && t.tier >= 2);
		for (let i = 0; i < n; i++) {
			const t = pool[Math.floor(Math.random() * pool.length)];
			addTroops(troops, t.id, 1);
		}
	}
	const [x, y] = nearestPassable(st.x + 10, st.y + 10);
	return makeParty("lord", `${FACTION[f].name}${[
		"勤王",
		"援",
		"义",
		"新"
	][Math.floor(Math.random() * 4)]}军`, f, x, y, troops, { gold: 500 });
}
/** GM 改过的国号（存在 S.flags 里，随世界存档） */
function applyRenames() {
	for (const [k, v] of Object.entries(S.flags ?? {})) if (k.startsWith("fname:") && FACTION[k.slice(6)] && typeof v === "string") FACTION[k.slice(6)].name = v;
}
//#endregion
//#region server/gm.ts
var GM_HELP = `GM 指令（“我”可代指自己）：
【概况】status｜players｜plist｜online｜save｜backup｜audit｜motd <文字>｜say <文字>
【时间规则】speed <时/秒>｜pause｜resume｜time <+小时>｜pvp on/off｜allianceday <日>｜protect <小时>
  rtbattle on/off（野战改为多人实时战斗）｜battlecap <人数≤1000>｜battles（进行中的战斗）｜battleend <编号|all>
  recruit <每秒> <上限>｜speedcfg <玩家max> <玩家min> <AImax> <AImin>｜indepcfg <声望> <兵力> <称帝城数> <国家上限>
【玩家】gold/setgold <玩家> <数>｜renown/setrenown｜honor｜level <玩家> <级>｜attr <玩家> <str|agi|int|cha> <数>
  skill <玩家> <技能id> <级>｜maxhero <玩家>｜gear <玩家>｜heal <玩家>｜troops <玩家> <兵种id> <数>（可为负）
  settroops <玩家> <兵种id> <数>｜cleartroops <玩家>｜nation <玩家> <势力>｜tp <玩家> <城>｜tpme <玩家>｜goto <玩家>
  noprotect <玩家>｜reprotect <玩家>｜mute <玩家> <分钟>｜unmute｜kick｜ban｜unban｜pass <玩家> <新密码>
【天下】owner <城> <势力> [玩家]｜garrison <城> <数> [兵种id]｜cleargarrison <城>｜prosperity <城> <数>｜strecruits <城> <数>
  spawn <势力> <城> <人数> [兵种id]｜smite <部队id>｜partytp <部队id> <城|me>
  war/peace <甲> <乙>｜ally/truce <甲> <乙> [日]｜vassal <宗主> <藩属>｜betray <甲> <乙>｜rename <势力> <新名>
  lordkill/lordrevive <领主>｜lordfaction <领主> <势力>｜lordtp <领主> <城>
【天命·仅天命之主】god｜god <项> <值>（on invincible oneHit mapSpeed battleSpeed aura reveal hidden any eye）
  godarmy <人数> [cav|guard|gun|bow|mix]｜tpxy <x> <y>｜setgm <玩家> on/off｜newkey｜resetworld confirm`;
/** 只有天命之主（gm=2）能用的指令 */
var OWNER_ONLY = /* @__PURE__ */ new Set([
	"god",
	"godarmy",
	"tpxy",
	"setgm",
	"newkey",
	"resetworld",
	"pass"
]);
function findSt(q) {
	return S.settlements[q] ?? settlementList().find((x) => x.name === q);
}
function findFaction(q) {
	if (!q) return null;
	if (FACTION[q]) return q;
	const alias = {
		明: "ming",
		大明: "ming",
		明朝: "ming",
		清: "jin",
		大清: "jin",
		后金: "jin",
		金: "jin",
		闯: "chuang",
		闯军: "chuang",
		大顺: "chuang",
		西: "xi",
		西营: "xi",
		大西: "xi",
		蒙: "mon",
		蒙古: "mon",
		察哈尔: "mon",
		匪: "bandit"
	};
	if (alias[q]) return alias[q];
	const f = Object.entries(FACTION).find(([, v]) => v.name === q || v.name.includes(q));
	return f ? f[0] : null;
}
function findLord(q) {
	return S.lords[q] ?? Object.values(S.lords).find((l) => l.name === q);
}
function tgt(me, q) {
	const name = q === "我" || q === "me" || !q ? me.acct : q;
	const s = byAcct.get(name);
	if (s?.rec) return {
		name,
		rec: s.rec,
		sess: s,
		party: heroOf(name),
		online: !!s.entered
	};
	const u = NETX.db.user(name);
	if (!u) return null;
	return {
		name,
		rec: JSON.parse(u.rec),
		online: false
	};
}
function patch(t, data) {
	if (t.online) OUT.send(t.name, {
		t: "patch",
		data
	});
}
function saveT(t) {
	NETX.db.saveRec(t.name, t.rec);
}
/** 兵力：在线玩家以部队为准 */
function troopsOf(t) {
	return t.party ? t.party.troops : t.rec.troops ??= [];
}
function setTroopsT(t, troops) {
	cleanStacks(troops);
	if (t.party) t.party.troops = troops;
	t.rec.troops = troops;
	patch(t, { troops });
}
function goldT(t, v) {
	v = Math.max(0, Math.round(v));
	const d = v - (t.party ? t.party.gold : t.rec.gold);
	if (t.party) t.party.gold = v;
	t.rec.gold = v;
	patch(t, { addGold: d });
}
function heroT(t, fn) {
	if (!t.rec.hero) return false;
	fn(t.rec.hero);
	if (t.party) {
		t.party.lvl = t.rec.hero.level;
		t.party.hp = t.rec.hero.hp;
	}
	patch(t, { hero: t.rec.hero });
	return true;
}
function bestGear() {
	const eq = {
		melee: null,
		ranged: null,
		armor: null,
		helm: null,
		horse: null
	};
	for (const slot of Object.keys(eq)) eq[slot] = ITEM_LIST.filter((i) => i.slot === slot).sort((a, b) => b.price - a.price)[0]?.id ?? null;
	return eq;
}
function moveParty(p, x, y) {
	if (!passable(x, y)) [x, y] = nearestPassable(x, y);
	p.x = x;
	p.y = y;
	p.inside = void 0;
	if (p.kind === "hero") {
		stopHero(p);
		OUT.send(p.acct, {
			t: "patch",
			data: {
				x,
				y
			}
		});
	} else {
		p.ai.path = [];
		p.ai.mode = "idle";
		p.ai.nextThink = S.time + 1;
	}
}
function plist() {
	return NETX.db.allUsers().slice(0, 300).map((u) => {
		const r = JSON.parse(u.rec);
		const s = byAcct.get(u.name);
		const live = s?.rec ?? r;
		const p = heroOf(u.name);
		return {
			name: u.name,
			online: !!s?.entered,
			nation: live.nation,
			lvl: live.hero?.level ?? 0,
			gold: p ? p.gold : live.gold ?? 0,
			renown: live.renown ?? 0,
			troops: count(p ? p.troops : live.troops ?? []),
			gm: u.gm,
			banned: !!u.banned,
			muted: Math.max(0, Math.ceil(((live.mutedUntil ?? 0) - Date.now()) / 6e4)),
			protect: Math.ceil(newbieLeft(live) / 6e4),
			x: p ? Math.round(p.x) : null,
			y: p ? Math.round(p.y) : null,
			last: u.last
		};
	});
}
function godSet(s, k, v) {
	const rec = s.rec;
	const g = normGod(rec.god ?? {
		...GOD_DEFAULT,
		on: false
	});
	const key = [
		"on",
		"invincible",
		"oneHit",
		"mapSpeed",
		"battleSpeed",
		"aura",
		"reveal",
		"hidden",
		"any",
		"eye"
	].find((x) => x.toLowerCase() === k.toLowerCase());
	if (!key) return false;
	if (key === "mapSpeed" || key === "battleSpeed") g[key] = Number(v);
	else g[key] = !(v === "off" || v === "0" || v === "false");
	rec.god = normGod(g);
	NETX.db.saveRec(s.acct, rec);
	sendGod(s);
	refreshGod(s.acct);
	pushOnline(true);
	return true;
}
function gm(s, cmd, a) {
	const reply = (text, data) => send(s, {
		t: "gm",
		text,
		data
	});
	const num = (x, d = 0) => x !== void 0 && x !== "" && Number.isFinite(Number(x)) ? Number(x) : d;
	cmd = (cmd ?? "").trim();
	if (cmd !== "plist" && cmd !== "god" || a.length) NETX.db.audit(s.acct, `gm ${cmd} ${a.join(" ")}`.slice(0, 300));
	if (OWNER_ONLY.has(cmd) && s.gm < 2) return reply("这条指令只有天命之主能用。");
	const cfgOut = () => OUT.broadcast({
		t: "cfg",
		cfg: CFG
	});
	switch (cmd) {
		case "help":
		case "": return reply(GM_HELP);
		case "status": return reply(`在线 ${[...byAcct.values()].filter((x) => x.entered).length} 人｜部队 ${S.parties.length}｜第 ${Math.floor(S.time / 24)} 日｜流速 ${CFG.hoursPerSec} 时/秒${CFG.paused ? "（已暂停）" : ""}｜PvP ${CFG.pvp ? "开" : "关"}｜结盟开放日 ${CFG.allianceOpenDay}｜新手保护 ${NEWBIE.ms / 36e5} 小时｜交战中 ${encounters.size}｜战争 ${S.wars.join(" ")}｜条约 ${(S.treaties ?? []).map((t) => `${t.a}-${t.b}:${t.type}`).join(" ") || "无"}`, {
			kind: "status",
			cfg: CFG,
			recruit: RECRUIT,
			speed: SPEED,
			indep: INDEP,
			newbieHours: NEWBIE.ms / 36e5
		});
		case "players": return reply(plist().slice(0, 80).map((u) => `${u.name}${u.gm ? `[GM${u.gm}]` : ""}${u.banned ? "[封]" : ""}${u.muted ? "[禁言]" : ""} ${u.nation ? FACTION[u.nation]?.name : "未选"} Lv${u.lvl || "-"} 银${u.gold} 兵${u.troops} ${u.online ? "在线" : ""}`).join("\n"));
		case "plist": return reply("", {
			kind: "plist",
			list: plist()
		});
		case "online":
			pushOnline(true);
			return reply([...byAcct.values()].filter((x) => x.entered).map((x) => x.acct).join("、") || "无人在线");
		case "save":
			saveAll();
			return reply("已保存");
		case "backup":
			saveAll();
			NETX.db.backup();
			return reply("已备份（DATA_DIR/backup-日期.db，保留 7 天）");
		case "audit": return reply(NETX.db.recentAudit(60).map((x) => `${new Date(x.at).toLocaleString("zh-CN")} ${x.who}: ${x.what}`).join("\n"));
		case "motd":
			CFG.motd = a.join(" ");
			cfgOut();
			return reply("公告已更新");
		case "say":
			if (!a.length) return reply("用法：say 文字");
			OUT.broadcast({
				t: "chat",
				ch: "gm",
				who: "天意",
				text: a.join(" ").slice(0, 300),
				at: Date.now()
			});
			return reply("已发布");
		case "speed":
			CFG.hoursPerSec = Math.max(.05, Math.min(10, num(a[0], .4)));
			CFG.paused = false;
			cfgOut();
			return reply(`时间流速 = ${CFG.hoursPerSec} 游戏小时/秒`);
		case "pause":
			CFG.paused = true;
			cfgOut();
			return reply("天下静止：除你之外万物停顿（再点“继续”恢复）");
		case "resume":
			CFG.paused = false;
			cfgOut();
			return reply("时间恢复流动");
		case "time":
			S.time += Math.max(0, Math.min(8760, num(a[0], 24)));
			return reply(`时间推进到第 ${Math.floor(S.time / 24)} 日`);
		case "rtbattle":
			BCFG.on = a[0] !== "off";
			return reply(`多人实时战斗 ${BCFG.on ? "开启：野战在服务器上实时进行，附近玩家可加入" : "关闭：PvP 自动结算，遭遇战在各自浏览器里打"}`);
		case "battlecap":
			BCFG.cap = Math.max(60, Math.min(1e3, num(a[0], 600)));
			return reply(`实时战场同时在场上限 = ${BCFG.cap} 人（双方合计）`);
		case "battles": {
			const st = battleStats();
			return reply(st.battles.length ? st.battles.map((b) => `#${b.bid} 在场 ${b.units} 人（${b.n[0]} 对 ${b.n[1]}）每步 ${b.ms} 毫秒｜玩家：${b.players.join("、") || "无"}`).join("\n") + `\n线程：${st.threads.map((t) => `${t.name} ${t.battles} 场 ${t.ms} 毫秒`).join("｜")}｜帧/秒 ${st.framesPerSec}` : "当前没有进行中的实时战斗");
		}
		case "battleend":
			if (a[0] === "all") {
				abortAll();
				return reply("所有实时战斗已按兵力强弱结算");
			}
			return reply(abortBattle(num(a[0], 0)) ? "该战斗已按兵力强弱结算" : "没有这场战斗");
		case "pvp":
			CFG.pvp = a[0] !== "off";
			cfgOut();
			return reply(`PvP ${CFG.pvp ? "开启" : "关闭"}`);
		case "allianceday":
			CFG.allianceOpenDay = Math.max(0, num(a[0], 36));
			cfgOut();
			return reply(`结盟开放：第 ${CFG.allianceOpenDay} 日`);
		case "protect":
			CFG.newbieHours = Math.max(0, Math.min(240, num(a[0], 2)));
			NEWBIE.ms = CFG.newbieHours * 36e5;
			cfgOut();
			return reply(`新手保护 = ${CFG.newbieHours} 小时`);
		case "recruit":
			RECRUIT.perSec = Math.max(0, num(a[0], RECRUIT.perSec));
			RECRUIT.cap = Math.max(1, num(a[1], RECRUIT.cap));
			return reply(`村庄兵源：每秒 ${RECRUIT.perSec}，上限 ${RECRUIT.cap}`);
		case "speedcfg":
			SPEED.player.max = num(a[0], SPEED.player.max);
			SPEED.player.min = num(a[1], SPEED.player.min);
			SPEED.ai.max = num(a[2], SPEED.ai.max);
			SPEED.ai.min = num(a[3], SPEED.ai.min);
			return reply(`速度：玩家 ${SPEED.player.min}~${SPEED.player.max}，AI ${SPEED.ai.min}~${SPEED.ai.max}`);
		case "indepcfg":
			if (a.length) {
				INDEP.renown = num(a[0], INDEP.renown);
				INDEP.troops = num(a[1], INDEP.troops);
				INDEP.emperorCities = num(a[2], INDEP.emperorCities);
				INDEP.maxKingdoms = num(a[3], INDEP.maxKingdoms);
			}
			return reply(`自立：声望 ${INDEP.renown}｜兵力 ${INDEP.troops}｜称帝城数 ${INDEP.emperorCities}｜玩家国家上限 ${INDEP.maxKingdoms}`);
		case "gold":
		case "setgold":
		case "renown":
		case "setrenown":
		case "honor":
		case "level":
		case "attr":
		case "skill":
		case "maxhero":
		case "gear":
		case "heal":
		case "troops":
		case "settroops":
		case "cleartroops":
		case "nation":
		case "tp":
		case "tpme":
		case "goto":
		case "noprotect":
		case "reprotect":
		case "mute":
		case "unmute": {
			const t = tgt(s, a[0] ?? "");
			if (!t) return reply("找不到这个玩家");
			if (!t.rec.nation && ![
				"noprotect",
				"reprotect",
				"mute",
				"unmute"
			].includes(cmd)) return reply("该玩家还没建角色");
			switch (cmd) {
				case "gold":
					goldT(t, (t.party ? t.party.gold : t.rec.gold) + num(a[1]));
					break;
				case "setgold":
					goldT(t, num(a[1]));
					break;
				case "renown":
				case "setrenown":
					t.rec.renown = Math.max(0, cmd === "renown" ? (t.rec.renown ?? 0) + num(a[1]) : num(a[1]));
					patch(t, { renown: t.rec.renown });
					break;
				case "honor":
					t.rec.honor = num(a[1]);
					patch(t, { honor: t.rec.honor });
					break;
				case "level":
					heroT(t, (h) => {
						h.level = Math.max(1, Math.min(99, num(a[1], h.level)));
					});
					break;
				case "attr": {
					const k = a[1];
					if (![
						"str",
						"agi",
						"int",
						"cha"
					].includes(k)) return reply("属性：str agi int cha");
					heroT(t, (h) => {
						h.attrs[k] = Math.max(1, Math.min(60, num(a[2], h.attrs[k])));
					});
					break;
				}
				case "skill": {
					const k = a[1];
					if (!(k in (t.rec.hero?.skills ?? {}))) return reply("技能 id：" + SKILLS.map((x) => x.id).join(" "));
					heroT(t, (h) => {
						h.skills[k] = Math.max(0, Math.min(10, num(a[2], h.skills[k])));
					});
					break;
				}
				case "maxhero":
					heroT(t, (h) => {
						h.level = Math.max(h.level, 40);
						for (const k of Object.keys(h.attrs)) h.attrs[k] = 30;
						for (const k of Object.keys(h.skills)) h.skills[k] = 10;
						h.hp = 1;
					});
					break;
				case "gear":
					heroT(t, (h) => {
						const eq = bestGear();
						for (const v of Object.values(h.equip)) if (v && !h.inventory.includes(v)) h.inventory.push(v);
						Object.assign(h.equip, eq);
						h.inventory = h.inventory.filter((i) => !Object.values(eq).includes(i)).slice(-60);
					});
					break;
				case "heal": {
					const tr = troopsOf(t);
					for (const x of tr) x.w = 0;
					heroT(t, (h) => {
						h.hp = 1;
					});
					setTroopsT(t, tr);
					break;
				}
				case "troops": {
					if (!TROOPS[a[1]]) return reply("兵种 id 不存在。例：ming_musket jin_bayara mon_hca god_cav");
					const tr = troopsOf(t);
					const n = Math.trunc(num(a[2], 10));
					if (n >= 0) addTroops(tr, a[1], Math.min(2e4, n));
					else {
						const st = tr.find((x) => x.id === a[1]);
						if (st) {
							st.n = Math.max(0, st.n + n);
							st.w = Math.min(st.w, st.n);
						}
					}
					setTroopsT(t, tr);
					break;
				}
				case "settroops": {
					if (!TROOPS[a[1]]) return reply("兵种 id 不存在");
					const tr = troopsOf(t).filter((x) => x.id !== a[1]);
					const n = Math.max(0, Math.min(2e4, Math.trunc(num(a[2]))));
					if (n) tr.push({
						id: a[1],
						n,
						w: 0,
						xp: 0
					});
					setTroopsT(t, tr);
					break;
				}
				case "cleartroops":
					setTroopsT(t, []);
					break;
				case "nation": {
					const f = findFaction(a[1] ?? "");
					if (!f || !S.alive[f]) return reply("势力不存在或已灭亡");
					t.rec.nation = f;
					t.rec.playerRel ??= {};
					t.rec.playerRel[f] = Math.max(t.rec.playerRel[f] ?? 0, 10);
					if (t.party) t.party.faction = f;
					patch(t, { faction: f });
					break;
				}
				case "tp": {
					const st = findSt(a[1] ?? "");
					if (!st) return reply("找不到此城");
					if (t.party) moveParty(t.party, st.x + 6, st.y + 6);
					else {
						t.rec.x = st.x + 6;
						t.rec.y = st.y + 6;
					}
					break;
				}
				case "tpme": {
					const me = heroOf(s.acct);
					if (!me || !t.party) return reply("双方都要在世界中");
					moveParty(t.party, me.x + 8, me.y + 4);
					break;
				}
				case "goto": {
					const me = heroOf(s.acct);
					if (!me || !t.party) return reply("双方都要在世界中");
					moveParty(me, t.party.x + 8, t.party.y + 4);
					break;
				}
				case "noprotect":
					t.rec.pvpOptIn = true;
					break;
				case "reprotect":
					t.rec.pvpOptIn = false;
					t.rec.created = Date.now();
					break;
				case "mute":
					t.rec.mutedUntil = Date.now() + Math.max(1, num(a[1], 30)) * 6e4;
					break;
				case "unmute": t.rec.mutedUntil = 0;
			}
			saveT(t);
			return reply(`${t.name}：${cmd} 完成`);
		}
		case "kick":
		case "ban":
		case "unban":
		case "pass":
		case "setgm": if (a[0] === "我" || a[0] === "me") a[0] = s.acct;
	}
	switch (cmd) {
		case "kick":
		case "ban": {
			if (!NETX.db.user(a[0] ?? "")) return reply("找不到这个玩家");
			if (a[0] === s.acct) return reply("不能对自己这么做");
			if (cmd === "ban") NETX.db.setFlag(a[0], "banned", 1);
			const t = byAcct.get(a[0]);
			if (t) {
				send(t, {
					t: "kick",
					why: cmd === "ban" ? "此账号已被封禁" : "你被请出了服务器"
				});
				try {
					t.ws.close();
				} catch {}
			}
			return reply(`${a[0]}：${cmd === "ban" ? "已封禁" : "已踢出"}`);
		}
		case "unban":
			if (!NETX.db.user(a[0] ?? "")) return reply("找不到这个玩家");
			NETX.db.setFlag(a[0], "banned", 0);
			return reply("已解封");
		case "pass":
			if (!NETX.db.user(a[0] ?? "") || (a[1] ?? "").length < 4) return reply("用法：pass 名号 新密码（至少 4 位）");
			NETX.db.setPass(a[0], a[1]);
			return reply("密码已重置（该玩家需用新密码重新登录）");
		case "setgm": {
			if (!NETX.db.user(a[0] ?? "")) return reply("找不到这个玩家");
			if (a[0] === s.acct) return reply("不能改自己的权限");
			const lv = a[1] === "off" ? 0 : a[1] === "owner" ? 2 : 1;
			NETX.db.setFlag(a[0], "gm", lv);
			const t = byAcct.get(a[0]);
			if (t) {
				t.gm = lv;
				if (lv < 2 && t.rec?.god) {
					delete t.rec.god;
					refreshGod(a[0]);
				}
				send(t, {
					t: "god",
					god: lv >= 2 ? t.rec?.god ?? null : null,
					level: lv
				});
			}
			return reply(`${a[0]}：${lv === 2 ? "天命之主" : lv === 1 ? "助手 GM（不能开上帝模式）" : "已收回 GM"}`);
		}
		case "newkey": {
			const k = NETX.key.renew();
			return reply(`新的天命令牌：${k}\n（已写入服务器 GM_KEY.txt；旧令牌立即作废。已认领的 GM 不受影响）`, {
				kind: "key",
				key: k
			});
		}
		case "resetworld":
			if (a[0] !== "confirm") return reply("危险！确认请输入：resetworld confirm");
			NETX.db.set("world_prev", worldJSON());
			NETX.db.del("world");
			for (const x of [...sessions]) {
				send(x, {
					t: "kick",
					why: "天地重开，请重新登录"
				});
				try {
					x.ws.close();
				} catch {}
			}
			setTimeout(() => process.exit(0), 500);
			return reply("世界将重置");
		case "spawn": {
			const f = findFaction(a[0] ?? "");
			const st = findSt(a[1] ?? "");
			if (!f || !st || !FACTION[f]) return reply("用法：spawn 大清 沈阳 300 [兵种id]");
			if (a[3] && !TROOPS[a[3]]) return reply("兵种 id 不存在");
			const p = gmSpawnArmy(f, st.id, Math.max(1, Math.min(3e3, num(a[2], 200))), a[3]);
			return reply(p ? `已在${st.name}召出${p.name}（${healthy(p.troops)} 人，部队 #${p.id}）` : "失败");
		}
		case "smite":
		case "partytp": {
			const p = partyById(num(a[0], -1));
			if (!p || p.id === S.playerId) return reply("找不到这支部队（用部队 id）");
			if (cmd === "smite") {
				if (p.kind === "hero") {
					if (godOfSafe(p)) return reply("不能对天命之主出手");
					p.troops = [];
					OUT.send(p.acct, {
						t: "patch",
						data: { troops: [] }
					});
					OUT.send(p.acct, {
						t: "report",
						title: "天降灾殃",
						lines: ["一场突如其来的瘟疫与山洪，你的军队一夜之间荡然无存。"]
					});
					return reply(`${p.name}的军队已化为乌有`);
				}
				removeParty(p);
				return reply(`${p.name}（#${p.id}）已从世上抹去`);
			}
			const me = heroOf(s.acct);
			if (a[1] === "me" || a[1] === "我") {
				if (!me) return reply("你不在世界中");
				moveParty(p, me.x + 10, me.y + 6);
			} else {
				const st = findSt(a[1] ?? "");
				if (!st) return reply("找不到此城");
				moveParty(p, st.x + 8, st.y + 8);
			}
			return reply(`${p.name} 已移走`);
		}
		case "owner": {
			const st = findSt(a[0] ?? "");
			const f = findFaction(a[1] ?? "");
			if (!st || !f || !FACTION[f]) return reply("用法：owner 北京 大清 [玩家]");
			const who = a[2] ? NETX.db.user(a[2]) ? "P:" + a[2] : null : null;
			if (a[2] && !who) return reply("找不到这个玩家");
			const old = st.faction;
			st.siege = null;
			setOwner(st, f, who);
			checkFactionAlive(old);
			if (old !== f) log(`${st.name}易帜，归于${FACTION[f].name}。`, "event");
			return reply(`${st.name} → ${FACTION[f].name}${who ? `（${a[2]}的封地）` : ""}`);
		}
		case "garrison":
		case "cleargarrison":
		case "prosperity":
		case "strecruits": {
			const st = findSt(a[0] ?? "");
			if (!st) return reply("找不到此城");
			if (cmd === "cleargarrison") st.garrison = [];
			if (cmd === "prosperity") st.prosperity = Math.max(0, Math.min(100, num(a[1], st.prosperity)));
			if (cmd === "strecruits") st.recruits = Math.max(0, Math.min(500, num(a[1], st.recruits)));
			if (cmd === "garrison") {
				const n = Math.max(-5e3, Math.min(5e3, Math.trunc(num(a[1], 100))));
				if (a[2] && !TROOPS[a[2]]) return reply("兵种 id 不存在");
				if (n < 0) {
					let left = -n;
					for (const g of [...st.garrison].reverse()) {
						const k = Math.min(left, g.n);
						g.n -= k;
						g.w = Math.min(g.w, g.n);
						left -= k;
						if (!left) break;
					}
					cleanStacks(st.garrison);
				} else if (a[2]) addTroops(st.garrison, a[2], n);
				else {
					const cul = FACTION[st.faction]?.culture ?? "ming";
					const pool = Object.values(TROOPS).filter((t) => t.culture === cul);
					for (let i = 0; i < n; i++) addTroops(st.garrison, pool[Math.floor(Math.random() * pool.length)].id, 1);
				}
			}
			return reply(`${st.name}：守军 ${healthy(st.garrison)}｜繁荣 ${Math.round(st.prosperity)}｜兵源 ${Math.floor(st.recruits)}`);
		}
		case "war":
		case "peace":
		case "ally":
		case "truce":
		case "vassal":
		case "betray": {
			const x = findFaction(a[0] ?? ""), y = findFaction(a[1] ?? "");
			if (!x || !y || x === y || !FACTION[x] || !FACTION[y]) return reply("用法：war 大明 大清");
			if (cmd === "war") {
				setWar(x, y, true);
				delete S.truceUntil[[x, y].sort().join("|")];
				S.treaties = (S.treaties ?? []).filter((t) => !(t.a === x && t.b === y || t.a === y && t.b === x));
				log(`${FACTION[x].name}与${FACTION[y].name}兵戎相见！`, "event");
			}
			if (cmd === "peace") {
				setWar(x, y, false);
				S.treaties = (S.treaties ?? []).filter((t) => !(t.a === x && t.b === y || t.a === y && t.b === x));
				log(`${FACTION[x].name}与${FACTION[y].name}罢兵言和。`, "event");
			}
			if (cmd === "ally") makeTreaty(x, y, "alliance", num(a[2], DIPLO.allianceDays), "");
			if (cmd === "truce") makeTreaty(x, y, "truce", num(a[2], DIPLO.truceDays), "");
			if (cmd === "vassal") makeTreaty(x, y, "vassal", num(a[2], DIPLO.vassalDays), "");
			if (cmd === "betray") breakTreaty(x, y);
			return reply(`${FACTION[x].name} ↔ ${FACTION[y].name}：${cmd} 完成`);
		}
		case "rename": {
			const f = findFaction(a[0] ?? "");
			const nm = (a[1] ?? "").slice(0, 8);
			if (!f || !FACTION[f] || !nm) return reply("用法：rename 大明 大汉");
			const old = FACTION[f].name;
			FACTION[f].name = nm;
			if (S.customFactions?.[f]) S.customFactions[f].name = nm;
			S.flags ??= {};
			S.flags["fname:" + f] = nm;
			log(`${old}改国号为${nm}。`, "event");
			return reply(`${old} → ${nm}`);
		}
		case "lordkill":
		case "lordrevive":
		case "lordfaction":
		case "lordtp": {
			const l = findLord(a[0] ?? "");
			if (!l) return reply("找不到这位领主（名字或 id）");
			const p = l.partyId ? partyById(l.partyId) : void 0;
			if (cmd === "lordkill") {
				if (p) removeParty(p);
				l.dead = true;
				l.partyId = null;
				log(`${FACTION[l.faction]?.name ?? ""}的${l.name}暴卒。`, "event");
				return reply(`${l.name} 已死`);
			}
			if (cmd === "lordrevive") {
				l.dead = false;
				if (!p) {
					l.respawnAt = S.time;
					spawnLordParty(l);
				}
				return reply(`${l.name} 已复生${l.partyId ? `（部队 #${l.partyId}）` : "（其势力无城可归，等有城再出）"}`);
			}
			if (cmd === "lordfaction") {
				const f = findFaction(a[1] ?? "");
				if (!f || !FACTION[f] || !S.alive[f]) return reply("势力不存在或已灭亡");
				const old = l.faction;
				l.faction = f;
				if (p) p.faction = f;
				if (old !== f) log(`${l.name}改投${FACTION[f].name}。`, "event");
				return reply(`${l.name} → ${FACTION[f].name}`);
			}
			const st = findSt(a[1] ?? "");
			if (!st || !p) return reply("找不到此城，或该领主不在野外");
			moveParty(p, st.x + 8, st.y + 8);
			return reply(`${l.name} 已移到${st.name}`);
		}
		case "god": {
			if (a.length >= 2 && !godSet(s, a[0], a[1])) return reply("项：on invincible oneHit mapSpeed battleSpeed aura reveal hidden any eye");
			if (a.length === 1 && (a[0] === "on" || a[0] === "off")) godSet(s, "on", a[0]);
			const g = s.rec.god ?? {
				...GOD_DEFAULT,
				on: false
			};
			return reply(a.length ? "" : `天命：${g.on ? "开" : "关"}｜金身 ${g.invincible ? "开" : "关"}｜一击必杀 ${g.oneHit ? "开" : "关"}｜神行 ×${g.mapSpeed}｜战场 ×${g.battleSpeed}｜金光 ${g.aura ? "开" : "关"}｜显圣 ${g.reveal ? "开" : "关"}｜隐身 ${g.hidden ? "开" : "关"}｜无视敌我 ${g.any ? "开" : "关"}｜天眼 ${g.eye ? "开" : "关"}`, {
				kind: "god",
				god: g
			});
		}
		case "godarmy": {
			const me = tgt(s, "我");
			if (!me?.rec.nation) return reply("先建角色");
			const n = Math.max(1, Math.min(5e3, Math.trunc(num(a[0], 300))));
			const kind = a[1] ?? "mix";
			const tr = troopsOf(me);
			const pick = (i) => kind === "cav" ? "god_cav" : kind === "guard" ? "god_guard" : kind === "gun" ? "god_gun" : kind === "bow" ? "god_bow" : GOD_TROOPS[[
				0,
				0,
				1,
				1,
				2,
				3
			][i % 6]];
			const add = {};
			for (let i = 0; i < n; i++) {
				const id = pick(i);
				add[id] = (add[id] ?? 0) + 1;
			}
			for (const [id, k] of Object.entries(add)) addTroops(tr, id, k);
			setTroopsT(me, tr);
			saveT(me);
			return reply(`天兵 ${n} 人已归入麾下（现有 ${count(tr)} 人）`);
		}
		case "tpxy": {
			const me = heroOf(s.acct);
			if (!me) return reply("你不在世界中");
			const x = num(a[0], NaN), y = num(a[1], NaN);
			if (!Number.isFinite(x) || !Number.isFinite(y)) return reply("用法：tpxy x y");
			moveParty(me, x, y);
			return reply("");
		}
	}
	reply("未知指令。输入 help 查看。");
}
function godOfSafe(p) {
	return !!godOf(p);
}
//#endregion
//#region server/net.ts
var sessions = /* @__PURE__ */ new Set();
var byAcct = /* @__PURE__ */ new Map();
/** 供 gm.ts 使用 */
var NETX = {
	db: null,
	key: null
};
var leaving = /* @__PURE__ */ new Map();
var patchSeq = /* @__PURE__ */ new Map();
var db;
function initNet(d, key) {
	db = d;
	NETX.db = d;
	NETX.key = key;
	OUT.send = (acct, m) => {
		if (m.t === "patch") {
			const q = (patchSeq.get(acct) ?? 0) + 1;
			patchSeq.set(acct, q);
			m.seq = q;
		}
		const s = byAcct.get(acct);
		if (s) send(s, m);
	};
	OUT.broadcast = (m, filter) => {
		const raw = JSON.stringify(m);
		for (const s of sessions) if (s.entered && (!filter || filter(s.acct))) raw0(s, raw);
	};
	OUT.online = (acct) => byAcct.has(acct) && byAcct.get(acct).entered;
	OUT.rec = (acct) => byAcct.get(acct)?.rec;
	OUT.gmLevel = (acct) => byAcct.get(acct)?.gm ?? 0;
	BOUT.bin = (acct, buf) => {
		const s = byAcct.get(acct);
		if (s?.entered && s.ws.readyState === 1) try {
			s.ws.send(buf, { binary: true });
		} catch {}
	};
	BOUT.json = (acct, m) => {
		const s = byAcct.get(acct);
		if (s?.entered) send(s, m);
	};
}
function raw0(s, raw) {
	if (s.ws.readyState === 1) try {
		s.ws.send(raw);
	} catch {}
}
function send(s, m) {
	raw0(s, JSON.stringify(m));
}
var sysMsg = (s, text) => send(s, {
	t: "chat",
	ch: "gm",
	who: "系统",
	text,
	at: Date.now()
});
/** 把天命状态（只）发给 GM 本人 */
function sendGod(s) {
	if (s.gm) send(s, {
		t: "god",
		god: s.gm >= 2 ? s.rec?.god ?? null : null,
		level: s.gm
	});
}
function broadcastRaw(raw) {
	for (const s of sessions) if (s.entered) raw0(s, raw);
}
var NAME_RE = /^[\u4e00-\u9fa5A-Za-z0-9_]{2,12}$/;
/** 同 IP 每 24 小时最多注册的账号数（内存计数，重启清零） */
var REG_PER_IP = 5;
var regByIp = /* @__PURE__ */ new Map();
var BAD_WORDS = [
	"习近平",
	"共产党",
	"法轮",
	"六四",
	"fuck",
	"shit"
];
var clean = (t) => {
	let x = t.slice(0, 200).replace(/[<>]/g, "");
	for (const w of BAD_WORDS) x = x.split(w).join("*".repeat(w.length));
	return x;
};
function onConnection(ws, ip) {
	const s = {
		ws,
		ip,
		gm: 0,
		entered: false,
		msgTimes: [],
		chatAt: 0,
		lastSyncAt: 0
	};
	sessions.add(s);
	ws.isAlive = true;
	ws.on("pong", () => {
		ws.isAlive = true;
	});
	ws.on("message", (data) => {
		const now = Date.now();
		s.msgTimes.push(now);
		while (s.msgTimes.length && now - s.msgTimes[0] > 1e3) s.msgTimes.shift();
		if (s.msgTimes.length > 90) return;
		let m;
		try {
			m = JSON.parse(String(data));
		} catch {
			return;
		}
		try {
			handle(s, m);
		} catch (e) {
			console.error("[net] handle", m.t, e);
		}
	});
	ws.on("close", () => onClose(s));
	ws.on("error", () => {});
}
function onClose(s) {
	sessions.delete(s);
	if (!s.acct || byAcct.get(s.acct) !== s) return;
	byAcct.delete(s.acct);
	const acct = s.acct, rec = s.rec;
	leaving.set(acct, setTimeout(() => {
		leaving.delete(acct);
		if (byAcct.has(acct)) return;
		if (inBattle(acct)) {
			const again = () => {
				if (byAcct.has(acct)) {
					leaving.delete(acct);
					return;
				}
				if (inBattle(acct)) {
					leaving.set(acct, setTimeout(again, 15e3));
					return;
				}
				leaving.delete(acct);
				despawnHero(acct, rec);
				db.saveRec(acct, rec);
			};
			leaving.set(acct, setTimeout(again, 15e3));
			return;
		}
		despawnHero(acct, rec);
		db.saveRec(acct, rec);
	}, 12e4));
	onPresence(acct, false);
}
function handle(s, m) {
	switch (m.t) {
		case "ping":
			send(s, {
				t: "pong",
				at: m.at,
				srv: Date.now()
			});
			return;
		case "register": {
			const name = String(m.name ?? "").trim(), pass = String(m.pass ?? "");
			if (!NAME_RE.test(name)) return send(s, {
				t: "auth",
				ok: false,
				err: "名号须为 2~12 个汉字、字母或数字"
			});
			if (BAD_WORDS.some((w) => name.includes(w))) return send(s, {
				t: "auth",
				ok: false,
				err: "名号不合适"
			});
			if (pass.length < 4) return send(s, {
				t: "auth",
				ok: false,
				err: "密码至少 4 位"
			});
			if (db.user(name)) return send(s, {
				t: "auth",
				ok: false,
				err: "此名号已被占用"
			});
			const regs = (regByIp.get(s.ip) ?? []).filter((t) => Date.now() - t < 864e5);
			if (regs.length >= REG_PER_IP && s.ip !== "127.0.0.1" && s.ip !== "::1" && s.ip !== "::ffff:127.0.0.1") return send(s, {
				t: "auth",
				ok: false,
				err: `同一网络一天最多注册 ${REG_PER_IP} 个名号`
			});
			regByIp.set(s.ip, [...regs, Date.now()]);
			if (s.authing) return;
			s.authing = true;
			db.register(name, pass, {
				name,
				nation: null
			}).then((token) => {
				s.authing = false;
				db.audit(name, `register from ${s.ip}`);
				if (s.ws.readyState === 1) afterAuth(s, name, token);
			}, () => {
				s.authing = false;
				send(s, {
					t: "auth",
					ok: false,
					err: "此名号已被占用"
				});
			});
			return;
		}
		case "login": {
			const u = db.user(String(m.name ?? "").trim());
			if (!u) return send(s, {
				t: "auth",
				ok: false,
				err: "名号或密码不对"
			});
			if (s.authing) return;
			s.authing = true;
			db.checkPass(u, String(m.pass ?? "")).then((ok) => {
				s.authing = false;
				if (!ok) return send(s, {
					t: "auth",
					ok: false,
					err: "名号或密码不对"
				});
				if (s.ws.readyState === 1) afterAuth(s, u.name, db.newToken(u.name));
			});
			return;
		}
		case "resume": {
			const u = db.userByToken(String(m.token ?? ""));
			if (!u) return send(s, {
				t: "auth",
				ok: false,
				err: "登录已过期，请重新登录"
			});
			return afterAuth(s, u.name, u.token);
		}
	}
	if (!s.acct || !s.rec) return;
	if (m.t === "create") {
		if (s.rec.nation) return;
		if (!NATIONS.includes(m.nation) || !S.alive[m.nation]) return send(s, {
			t: "auth",
			ok: false,
			err: "这个国家已经覆灭，请另选",
			needCreate: true
		});
		if (s.rec.hero) {
			s.rec.nation = m.nation;
			s.rec.playerRel[m.nation] = Math.max(s.rec.playerRel[m.nation] ?? 0, 10);
			db.saveRec(s.acct, s.rec);
			log(`${s.acct}改投${FACTION[m.nation].name}。`, "event");
			return enter(s);
		}
		const bg = BACKGROUNDS.some((b) => b.id === m.bg) ? m.bg : "soldier";
		s.rec = createRec(s.acct, m.nation, bg);
		db.saveRec(s.acct, s.rec);
		db.audit(s.acct, `create ${m.nation} ${bg}`);
		log(`${s.acct}投效${FACTION[m.nation].name}。`, "event");
		return enter(s);
	}
	if (!s.entered) return;
	const rec = s.rec, p = heroOf(s.acct);
	switch (m.t) {
		case "nav":
			if (p && !p.busy) {
				if (!setHeroNav(p, m.kind, m.x, m.y, m.id)) send(s, { t: "navEnd" });
			}
			return;
		case "stop":
			if (p) stopHero(p);
			return;
		case "enter": {
			const st = S.settlements[m.st];
			if (p && st && !p.busy && Math.hypot(p.x - st.x, p.y - st.y) < (st.isPass ? 60 : 30) && st.kind !== "village" && !heroNav.has(p.id)) {
				if (!(st.siege || st.faction !== p.faction && S.wars.includes([st.faction, p.faction].sort().join("|")))) p.inside = st.id;
			}
			return;
		}
		case "leave":
			if (p) p.inside = void 0;
			return;
		case "sync": {
			const data = { ...m.data };
			if ((m.ps ?? 0) < (patchSeq.get(s.acct) ?? 0)) return;
			const warn = applySync(rec, data);
			if (warn) db.audit(s.acct, "suspicious: " + warn);
			return;
		}
		case "req": {
			let r;
			if (m.op === "diplo") r = diplo(s, m.args);
			else if (m.op === "indep") {
				r = declareIndependence(rec, m.args ?? {});
				if (r.ok) db.audit(s.acct, `independence ${JSON.stringify(m.args)}`);
			} else if (m.op === "indepCheck") {
				const why = indepCheck(rec);
				r = {
					ok: !why,
					err: why ?? void 0,
					data: {
						...INDEP,
						fiefs: fiefsOfAcct(rec.name).filter((x) => x.kind !== "village").map((x) => ({
							id: x.id,
							name: x.name
						}))
					}
				};
			} else if (m.op === "emperor") r = proclaimEmperor(rec);
			else if (m.op === "invite") r = invite(rec, String(m.args?.name ?? ""), byAcct.get(String(m.args?.name ?? ""))?.rec);
			else if (m.op === "acceptInvite") r = acceptInvite(rec);
			else if (m.op === "bjoin") {
				const j = joinRT(s.acct, Number(m.args?.bid), m.args?.side === 0 || m.args?.side === 1 ? m.args.side : void 0);
				r = j.ok ? {
					ok: true,
					data: { side: j.side }
				} : {
					ok: false,
					err: j.err
				};
			} else if (m.op === "battles") r = {
				ok: true,
				data: battleList()
			};
			else r = handleReq(rec, m.op, m.args);
			send(s, {
				t: "res",
				rid: m.rid,
				ok: r.ok,
				data: r.data,
				err: r.err
			});
			return;
		}
		case "chat": {
			const now = Date.now();
			if (now - s.chatAt < 800) return;
			s.chatAt = now;
			const raw = String(m.text ?? "").trim();
			if (raw.startsWith("/")) {
				const [c0, ...args] = raw.slice(1).split(/\s+/);
				if (c0 === "天命" || c0.toLowerCase() === "claim") return claimGm(s, args.join(""));
				if (s.gm) return gm(s, c0, args);
				return sysMsg(s, "没有这个指令。");
			}
			if ((rec.mutedUntil ?? 0) > now) return sysMsg(s, `你被禁言了，还剩 ${Math.ceil((rec.mutedUntil - now) / 6e4)} 分钟。`);
			const text = clean(raw).trim();
			if (!text) return;
			if (m.ch === "pm") {
				const to = String(m.to ?? "").trim();
				const ts = byAcct.get(to);
				if (!ts?.entered) return send(s, {
					t: "chat",
					ch: "gm",
					who: "系统",
					text: `${to || "对方"}不在线`,
					at: now
				});
				const pm = {
					t: "chat",
					ch: "pm",
					who: s.acct,
					nation: rec.nation,
					text,
					at: now,
					to
				};
				send(ts, pm);
				if (ts !== s) send(s, pm);
				return;
			}
			const ch = m.ch === "nation" ? "nation" : "all";
			const msg = {
				t: "chat",
				ch,
				who: s.acct,
				nation: rec.nation,
				text,
				at: now
			};
			if (ch === "all") {
				db.chat("all", s.acct, text);
				OUT.broadcast(msg);
			} else OUT.broadcast(msg, (a) => byAcct.get(a)?.rec?.nation === rec.nation);
			return;
		}
		case "gm":
			if (s.gm) gm(s, String(m.cmd ?? ""), (m.args ?? []).map(String));
			return;
		case "bi":
		case "bc":
		case "bleave":
		case "bsync":
			onClientMsg(s.acct, m);
			return;
	}
}
function afterAuth(s, name, token) {
	const u = db.user(name);
	if (u.banned) {
		send(s, {
			t: "auth",
			ok: false,
			err: "此账号已被封禁"
		});
		return;
	}
	const old = byAcct.get(name);
	if (old && old !== s) {
		send(old, {
			t: "kick",
			why: "你的账号在别处登录了"
		});
		old.acct = void 0;
		old.entered = false;
		try {
			old.ws.close();
		} catch {}
	}
	const lt = leaving.get(name);
	if (lt) {
		clearTimeout(lt);
		leaving.delete(name);
	}
	s.acct = name;
	s.gm = u.gm | 0;
	s.rec = old?.rec && old.rec.name === name ? old.rec : JSON.parse(u.rec);
	byAcct.set(name, s);
	const needCreate = !s.rec.nation;
	send(s, {
		t: "auth",
		ok: true,
		token,
		name,
		needCreate,
		gm: s.gm > 0
	});
	if (!needCreate) enter(s);
}
var snapCache = {
	at: 0,
	json: ""
};
function enter(s) {
	const rec = s.rec;
	if (rec.nation && !S.alive[rec.nation]) {
		log(`${rec.name}的故国已亡，流落江湖。`, "event");
		rec.nation = null;
		db.saveRec(rec.name, rec);
		send(s, {
			t: "auth",
			ok: true,
			name: rec.name,
			needCreate: true,
			gm: s.gm > 0
		});
		return;
	}
	if (s.gm < 2 && rec.god) delete rec.god;
	const p = spawnHero(rec);
	s.entered = true;
	const now = Date.now();
	if (now - snapCache.at > 1e3) snapCache = {
		at: now,
		json: JSON.stringify(worldSnap())
	};
	raw0(s, `{"t":"welcome","world":${snapCache.json},` + JSON.stringify({
		rec,
		partyId: p.id,
		parties: visibleParties(s.acct).map(netParty),
		cfg: CFG,
		gm: s.gm > 0,
		chat: db.recentChat(30)
	}).slice(1));
	sendGod(s);
	send(s, {
		t: "online",
		list: onlineList()
	});
	send(s, {
		t: "battles",
		list: battleList()
	});
	if (inBattle(s.acct)) onPresence(s.acct, true);
}
var lastOnline = "";
function onlineList() {
	const list = [];
	for (const s of byAcct.values()) {
		if (!s.entered || !s.rec) continue;
		if (s.gm >= 2 && s.rec.god?.on && s.rec.god.hidden) continue;
		list.push({
			name: s.acct,
			nation: s.rec.nation,
			lvl: s.rec.hero?.level ?? 1
		});
	}
	return list;
}
/** 在线名单：变化时随 3 秒周期合并广播（避免大批玩家同时上线时 O(N²) 刷屏） */
function pushOnline(force = false) {
	const list = onlineList();
	const j = JSON.stringify(list);
	if (!force && j === lastOnline) return;
	lastOnline = j;
	OUT.broadcast({
		t: "online",
		list
	});
}
function saveAll() {
	for (const s of byAcct.values()) if (s.rec && s.entered) {
		const p = heroOf(s.acct);
		if (p) {
			s.rec.x = p.x;
			s.rec.y = p.y;
			s.rec.troops = p.troops;
			s.rec.gold = p.gold;
			s.rec.goods = p.goods;
		}
		db.saveRec(s.acct, s.rec);
	}
	db.set("world", worldJSON());
	db.set("cfg", JSON.stringify({
		cfg: CFG,
		recruit: RECRUIT,
		diplo: DIPLO
	}));
}
function heartbeat() {
	for (const s of sessions) {
		const ws = s.ws;
		if (ws.isAlive === false) {
			try {
				ws.terminate();
			} catch {}
			continue;
		}
		ws.isAlive = false;
		try {
			ws.ping();
		} catch {}
	}
}
function diplo(s, a) {
	const rec = s.rec;
	if (!rec.nation) return {
		ok: false,
		err: "你尚未效忠任何国家"
	};
	const gift = Math.max(0, Math.min(rec.gold, Math.floor(a.gift ?? 0)));
	const r = propose(rec.name, rec.renown, rec.nation, a.to, a.type, gift);
	if (gift > 0) {
		rec.gold -= gift;
		OUT.send(s.acct, {
			t: "patch",
			data: { addGold: -gift },
			why: "gift"
		});
	}
	if (r.ok && a.type !== "war") {
		rec.renown += 30;
		OUT.send(s.acct, {
			t: "patch",
			data: { renown: rec.renown },
			why: "diplo"
		});
	}
	db.audit(rec.name, `diplo ${rec.nation}->${a.to} ${a.type} gift ${gift}: ${r.ok}`);
	return {
		ok: r.ok,
		data: {
			msg: r.msg,
			rank: RANK_NAMES[rankOf(rec.renown)]
		},
		err: r.ok ? void 0 : r.msg
	};
}
/** 效忠的国家已覆灭（如玩家国家流亡期满）：在线成员重新择主，保留角色与家当 */
function checkOrphans() {
	for (const s of sessions) {
		if (!s.entered || !s.rec?.nation || S.alive[s.rec.nation]) continue;
		const dead = FACTION[s.rec.nation]?.name ?? s.rec.nation;
		s.rec.nation = null;
		db.saveRec(s.rec.name, s.rec);
		send(s, {
			t: "log",
			msg: `${dead}国祚已绝。你流落江湖，须另择明主。`,
			cls: "bad"
		});
		send(s, {
			t: "auth",
			ok: true,
			name: s.rec.name,
			needCreate: true,
			gm: s.gm > 0
		});
	}
}
function claimGm(s, key) {
	const ks = ["ip:" + s.ip, "acct:" + s.acct];
	if (claimBlocked(...ks)) {
		db.audit(s.acct, `gm-claim blocked (${s.ip})`);
		return sysMsg(s, "尝试次数太多，请一小时后再试。");
	}
	if (!NETX.key.check(key)) {
		claimFailed(...ks);
		db.audit(s.acct, `gm-claim FAILED from ${s.ip}`);
		return sysMsg(s, "令牌不对。");
	}
	db.setFlag(s.acct, "gm", 2);
	s.gm = 2;
	s.rec.god ??= {
		...GOD_DEFAULT,
		on: false
	};
	db.saveRec(s.acct, s.rec);
	db.audit(s.acct, `gm-claim OK from ${s.ip}`);
	console.log(`[gm] ${s.acct} 认领了天命（${s.ip}）`);
	sendGod(s);
	refreshGod(s.acct);
	sysMsg(s, "天命所归。你已是天命之主——右上角“⚙ 天意”打开上帝面板。此事只有你自己知道。");
}
//#endregion
//#region server/main.ts
if (!isMainThread) runBattleWorker(parentPort);
else boot();
function boot() {
	const HERE = dirname(fileURLToPath(import.meta.url));
	const PORT = Number(process.env.PORT ?? 8080);
	const DATA_DIR = process.env.DATA_DIR ?? (existsSync("/workspace") ? "/workspace/ming-data" : resolve(HERE, "../data"));
	const DIST_DIR = process.env.DIST_DIR ?? resolve(HERE, "../dist");
	console.log(`[boot] data=${DATA_DIR} dist=${DIST_DIR} port=${PORT}`);
	const db = new DB(DATA_DIR);
	const cfgRaw = db.get("cfg");
	if (cfgRaw) try {
		const c = JSON.parse(cfgRaw);
		Object.assign(CFG, c.cfg ?? {});
		Object.assign(RECRUIT, c.recruit ?? {});
		Object.assign(DIPLO, c.diplo ?? {});
	} catch {}
	if (CFG.newbieHours !== void 0) NEWBIE.ms = CFG.newbieHours * 36e5;
	const t0 = Date.now();
	initWorld(db.get("world"));
	console.log(`[boot] world ready in ${Date.now() - t0} ms`);
	db.migrateGm();
	initNet(db, new GmKey(db, DATA_DIR));
	initBattles();
	const MIME = {
		".html": "text/html; charset=utf-8",
		".js": "text/javascript",
		".mjs": "text/javascript",
		".css": "text/css",
		".json": "application/json",
		".png": "image/png",
		".jpg": "image/jpeg",
		".svg": "image/svg+xml",
		".ico": "image/x-icon",
		".webp": "image/webp",
		".woff2": "font/woff2"
	};
	const ZIP_EXT = /* @__PURE__ */ new Set([
		".html",
		".js",
		".mjs",
		".css",
		".json",
		".svg"
	]);
	const gzCache = /* @__PURE__ */ new Map();
	async function serveStatic(req, res) {
		const url = new URL(req.url ?? "/", "http://x");
		if (url.pathname === "/battles") {
			res.writeHead(200, { "content-type": "application/json" });
			res.end(JSON.stringify(battleStats()));
			return;
		}
		if (url.pathname === "/health") {
			res.writeHead(200, { "content-type": "application/json" });
			res.end(JSON.stringify({
				ok: true,
				online: [...sessions].filter((s) => s.entered).length,
				day: Math.floor(S.time / 24),
				parties: S.parties.length
			}));
			return;
		}
		let p = decodeURIComponent(url.pathname);
		if (p.includes("..")) {
			res.writeHead(400);
			res.end();
			return;
		}
		if (p === "/" || p === "") p = "/index.html";
		let file = join(DIST_DIR, p);
		try {
			if (!(await stat(file)).isFile()) file = join(DIST_DIR, "index.html");
		} catch {
			file = join(DIST_DIR, "index.html");
		}
		try {
			const ext = extname(file);
			const headers = {
				"content-type": MIME[ext] ?? "application/octet-stream",
				"cache-control": ext === ".html" ? "no-cache" : "public, max-age=86400",
				vary: "accept-encoding"
			};
			if (ZIP_EXT.has(ext) && /\bgzip\b/.test(String(req.headers["accept-encoding"] ?? ""))) {
				const mt = (await stat(file)).mtimeMs;
				let z = gzCache.get(file);
				if (!z || z.mt !== mt) {
					z = {
						mt,
						buf: gzipSync(await readFile(file), { level: 9 })
					};
					gzCache.set(file, z);
				}
				headers["content-encoding"] = "gzip";
				res.writeHead(200, headers);
				res.end(z.buf);
				return;
			}
			const body = await readFile(file);
			res.writeHead(200, headers);
			res.end(body);
		} catch {
			res.writeHead(404);
			res.end("客户端未构建：请先 npm run build");
		}
	}
	const server = createServer((req, res) => {
		serveStatic(req, res);
	});
	new import_websocket_server.default({
		server,
		path: "/ws",
		perMessageDeflate: {
			threshold: 1400,
			zlibDeflateOptions: {
				level: 1,
				memLevel: 8
			},
			concurrencyLimit: 32
		},
		maxPayload: 524288
	}).on("connection", (ws, req) => {
		onConnection(ws, String(req.headers["x-real-ip"] ?? req.headers["x-forwarded-for"] ?? req.socket.remoteAddress ?? "?"));
	});
	server.listen(PORT, "0.0.0.0", () => console.log(`[boot] listening on 0.0.0.0:${PORT}`));
	let last = Date.now(), lastPos = 0, lastHeroPos = 0, lastParties = 0, lastWorld = 0, lastSave = Date.now(), lastHb = 0, lastBackup = 0;
	let tickCost = 0, maxLag = 0, lastBattles = 0, lastBattlesJson = "";
	setInterval(() => {
		const now = Date.now();
		const dt = Math.min(1, (now - last) / 1e3);
		maxLag = Math.max(maxLag, now - last - 100);
		last = now;
		const a = performance.now();
		tick(dt);
		tickCost = tickCost * .95 + (performance.now() - a) * .05;
		if (now - lastPos >= 400) {
			lastPos = now;
			lastHeroPos = now;
			broadcastRaw(JSON.stringify(posPacket()));
			for (const x of hiddenSelfPos()) OUT.send(x.acct, x.m);
		} else if (now - lastHeroPos >= 200) {
			lastHeroPos = now;
			const pk = posPacket(true);
			if (pk.a.length) broadcastRaw(JSON.stringify(pk));
			for (const x of hiddenSelfPos()) OUT.send(x.acct, x.m);
		}
		if (now - lastParties >= 1e3) {
			lastParties = now;
			const d = partiesDelta();
			if (d.t === "parties" && (d.up.length || d.gone.length)) broadcastRaw(JSON.stringify(d));
		}
		if (now - lastWorld >= 3e3) {
			lastWorld = now;
			kingdomTick();
			checkOrphans();
			const d = worldDelta();
			if (d) broadcastRaw(JSON.stringify(d));
			pushOnline();
		}
		if (now - lastHb >= 2e4) {
			lastHb = now;
			heartbeat();
		}
		if (now - lastBattles >= 2e3) {
			lastBattles = now;
			const j = JSON.stringify({
				t: "battles",
				list: battleList()
			});
			if (j !== lastBattlesJson) {
				lastBattlesJson = j;
				broadcastRaw(j);
			}
		}
		if (now - lastSave >= 6e4) {
			lastSave = now;
			const b = performance.now();
			saveAll();
			console.log(`[save] ${Math.round(performance.now() - b)} ms; tick avg ${tickCost.toFixed(1)} ms; max lag ${maxLag} ms; online ${[...sessions].filter((s) => s.entered).length}`);
			maxLag = 0;
		}
		if (now - lastBackup >= 216e5) {
			lastBackup = now;
			db.backup();
		}
	}, 100);
	function shutdown(sig) {
		console.log(`[exit] ${sig}: saving…`);
		try {
			saveAll();
		} catch (e) {
			console.error(e);
		}
		db.close();
		process.exit(0);
	}
	process.on("SIGTERM", () => shutdown("SIGTERM"));
	process.on("SIGINT", () => shutdown("SIGINT"));
	process.on("uncaughtException", (e) => {
		console.error("[fatal]", e);
	});
}
//#endregion
export {};
