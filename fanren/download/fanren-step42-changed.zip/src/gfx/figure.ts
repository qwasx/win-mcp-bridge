// 第四十二步：人物参数化 —— 男女两套基准，脸 / 头 / 身材为参数，其余共用一套骨骼与动作框架。
// 另含重做的手部：掌 + 五指分段绘制，手势（自然 / 握拳 / 剑指 / 推掌 / 持物 / 结印）与“用力”程度。
import { shade, rgba } from '../core/canvas';

/** 脸部参数（均为倍率/偏移，1 或 0 为基准） */
export interface FaceParams {
  jaw: number;      // 下颌宽 0.85–1.12
  chin: number;     // 下巴长 0.85–1.15
  eye: number;      // 眼睛大小 0.8–1.25
  eyeTilt: number;  // 眼尾上挑 -0.4–0.6
  brow: number;     // 眉浓 0.6–1.5
  browTilt: number; // 眉峰（剑眉 >0，柳叶眉 <0）-0.5–0.6
  nose: number;     // 鼻长 0.85–1.15
  mouth: number;    // 嘴宽 0.8–1.2
}
/** 身材参数 */
export interface BodyParams {
  shoulder: number; // 肩宽
  chest: number;    // 胸厚（男：胸肌 / 女：胸型）
  waist: number;    // 腰围
  hip: number;      // 臀宽
  limb: number;     // 四肢粗细
  leg: number;      // 腿长
  neck: number;     // 脖长
}

export const FACE_BASE: Record<'m' | 'f', FaceParams> = {
  m: { jaw: 1, chin: 1, eye: 1, eyeTilt: 0.1, brow: 1.1, browTilt: 0.25, nose: 1, mouth: 1 },
  f: { jaw: 0.92, chin: 0.95, eye: 1.08, eyeTilt: 0.15, brow: 0.8, browTilt: -0.15, nose: 0.94, mouth: 0.9 },
};
export const BODY_BASE: Record<'m' | 'f', BodyParams> = {
  m: { shoulder: 1, chest: 1, waist: 1, hip: 1, limb: 1, leg: 1, neck: 1 },
  f: { shoulder: 1, chest: 1, waist: 1, hip: 1, limb: 0.86, leg: 1.03, neck: 1.08 },
};

export const FACE_RANGE: Record<keyof FaceParams, [number, number, string]> = {
  jaw: [0.85, 1.12, '下颌'], chin: [0.85, 1.15, '下巴'], eye: [0.8, 1.25, '眼睛'], eyeTilt: [-0.4, 0.6, '眼尾'],
  brow: [0.6, 1.5, '眉浓'], browTilt: [-0.5, 0.6, '眉峰'], nose: [0.85, 1.15, '鼻长'], mouth: [0.8, 1.2, '嘴宽'],
};
export const BODY_RANGE: Record<keyof BodyParams, [number, number, string]> = {
  shoulder: [0.85, 1.18, '肩宽'], chest: [0.85, 1.25, '胸'], waist: [0.8, 1.25, '腰'], hip: [0.85, 1.2, '臀'],
  limb: [0.8, 1.2, '四肢'], leg: [0.92, 1.1, '腿长'], neck: [0.85, 1.2, '脖长'],
};

export function faceOf(look: { sex: 'm' | 'f'; face?: Partial<FaceParams> }): FaceParams {
  return { ...FACE_BASE[look.sex], ...(look.face || {}) };
}
export function bodyOf(look: { sex: 'm' | 'f'; body?: Partial<BodyParams> }): BodyParams {
  return { ...BODY_BASE[look.sex], ...(look.body || {}) };
}

// ---------------------------------------------------------------- 手
export type HandPose = 'relax' | 'fist' | 'sword' | 'palm' | 'grip' | 'mudra';
export interface HandSpec { pose: HandPose; force: number }

/** 动作 → 手势与发力 */
export function handFor(action: string, side: 1 | -1, at: number, t: number, hold: string | undefined, hero: boolean): HandSpec {
  const right = side < 0;
  if (hold && hold !== 'none' && right && action !== 'cast' && action !== 'fly') return { pose: 'grip', force: 0.45 };
  switch (action) {
    case 'run': return { pose: 'fist', force: hero ? 0.75 : 0.5 };
    case 'walk': return { pose: 'relax', force: 0.1 };
    case 'fly': return right ? { pose: 'sword', force: 0.85 } : { pose: 'fist', force: 0.3 };
    case 'sit': return { pose: 'mudra', force: 0.2 };
    case 'cast': {
      const k = Math.min(1, at / 0.22);
      return right ? { pose: 'palm', force: k * (0.85 + 0.15 * Math.sin(at * 9)) } : { pose: 'sword', force: 0.9 * k };
    }
    case 'gather': return right ? { pose: 'grip', force: 0.6 + 0.2 * Math.sin(at * 6) } : { pose: 'relax', force: 0.2 };
    case 'hit': return { pose: 'palm', force: 0.35 };
    case 'dodge': return { pose: 'palm', force: 0.55 };
    default: return { pose: 'relax', force: 0.05 + 0.03 * Math.sin(t) };
  }
}

type Pt = { x: number; y: number };

/**
 * 画一只手。W=腕，H=手掌中心方向点（骨骼末端）。
 * thumbSide: 拇指在屏幕上的法线一侧（+1/-1）；back: 看到的是手背；fem: 女性手更纤长。
 */
export function drawHand(g: CanvasRenderingContext2D, W: Pt, H: Pt, S: number, spec: HandSpec, skin: string, ink: string,
  lw: number, thumbSide: number, back: boolean, fem: boolean, tt: number) {
  const f = Math.max(0, Math.min(1, spec.force));
  // 用力时轻微颤动
  void back;
  const tr = f > 0.6 ? (f - 0.6) * 0.35 * S * Math.sin(tt * 47) : 0;
  let dx = H.x - W.x, dy = H.y - W.y; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
  const nx = -dy * thumbSide, ny = dx * thumbSide;          // 指向拇指一侧
  const k = fem ? 0.86 : 1, fl = fem ? 1.12 : 1;              // 女：窄而指长
  const at = (u: number, w: number): Pt => ({ x: W.x + dx * u * S + nx * w * S + tr, y: W.y + dy * u * S + ny * w * S });
  const skinD = shade(skin, -0.2), skinL = shade(skin, 0.1);
  const fingerTube = (pts: Pt[], r0: number, r1: number) => {
    // 多段手指：带关节的锥形
    g.lineCap = 'round'; g.lineJoin = 'round';
    g.strokeStyle = ink; g.lineWidth = (r0 * 2 + lw * 1.4);
    g.beginPath(); g.moveTo(pts[0].x, pts[0].y); for (let i = 1; i < pts.length; i++) g.lineTo(pts[i].x, pts[i].y); g.stroke();
    for (let i = 1; i < pts.length; i++) {
      const r = r0 + (r1 - r0) * (i / (pts.length - 1));
      g.strokeStyle = skin; g.lineWidth = r * 2;
      g.beginPath(); g.moveTo(pts[i - 1].x, pts[i - 1].y); g.lineTo(pts[i].x, pts[i].y); g.stroke();
    }
  };
  // 手指：从掌根 u0 起，沿方向角弯曲 curl（每节）
  const finger = (base: Pt, ang: number, lens: number[], curl: number, r: number) => {
    const pts: Pt[] = [base]; let a = ang, p = base;
    for (const L of lens) { a += curl * -thumbSide; p = { x: p.x + Math.cos(a) * L * S * fl, y: p.y + Math.sin(a) * L * S * fl }; pts.push(p); }
    fingerTube(pts, r * S * k, r * 0.8 * S * k);
    return pts;
  };
  const dirA = Math.atan2(dy, dx);
  const palmLen = 2.5, wristW = 1.05 * k, knW = 1.35 * k;
  const palm = () => {
    const a = at(0, wristW), b = at(palmLen, knW + 0.1), c = at(palmLen + 0.25, -knW), e = at(0, -wristW * 0.95);
    g.beginPath(); g.moveTo(a.x, a.y);
    g.quadraticCurveTo(at(palmLen * 0.6, knW + 0.35).x, at(palmLen * 0.6, knW + 0.35).y, b.x, b.y);
    g.quadraticCurveTo(at(palmLen + 0.55, 0).x, at(palmLen + 0.55, 0).y, c.x, c.y);
    g.quadraticCurveTo(at(palmLen * 0.5, -knW - 0.25).x, at(palmLen * 0.5, -knW - 0.25).y, e.x, e.y);
    g.closePath();
    const gr = g.createLinearGradient(at(0, knW).x, at(0, knW).y, at(0, -knW).x, at(0, -knW).y);
    gr.addColorStop(0, skinL); gr.addColorStop(0.55, skin); gr.addColorStop(1, skinD);
    g.fillStyle = gr; g.fill(); g.strokeStyle = ink; g.lineWidth = lw * 0.75; g.stroke();
  };
  // 用力：手背筋、指节泛白泛红
  const tendons = () => {
    if (f < 0.35 || S < 1.6) return;
    g.strokeStyle = rgba(shade(skin, -0.35), 0.25 + 0.35 * f); g.lineWidth = Math.max(0.3, 0.16 * S);
    for (const w of [0.65, 0.15, -0.35, -0.8]) {
      const a = at(0.5, w * 0.7), b = at(palmLen + 0.1, w * k);
      g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke();
    }
  };
  const knuckles = (u: number) => {
    for (let i = 0; i < 4; i++) {
      const w = knW * (0.75 - i * 0.5);
      const c = at(u, w);
      g.fillStyle = rgba(f > 0.5 ? '#fff4ea' : skinL, 0.35 + 0.4 * f);
      g.beginPath(); g.arc(c.x, c.y, 0.42 * S * k, 0, Math.PI * 2); g.fill();
      if (f > 0.5) { g.fillStyle = `rgba(200,90,80,${0.18 * f})`; g.beginPath(); g.arc(c.x + dx * 0.2 * S, c.y + dy * 0.2 * S, 0.35 * S * k, 0, Math.PI * 2); g.fill(); }
    }
  };
  const fr = 0.42; // 指半径
  const thumbBase = at(0.7, wristW + 0.15);
  const pose = spec.pose;
  if (pose === 'fist' || pose === 'grip') {
    // 拳：掌短、四指折叠成一排“指节块”，拇指横压在食中指上
    const hole = pose === 'grip';
    palm();
    const rowU = palmLen + 0.25;
    for (let i = 0; i < 4; i++) {
      const w = knW * (0.78 - i * 0.52);
      const p0 = at(rowU, w), p1 = at(rowU + 0.85 - f * 0.15, w * 1.02), p2 = at(rowU + 0.5 - f * 0.2, w * 0.98 + 0.0), p3 = at(rowU - 0.2, w * 0.95);
      fingerTube([p0, p1, p2, p3], fr * S * k * (1 + 0.08 * f), fr * 0.95 * S * k);
    }
    if (hole) { const c = at(rowU + 0.2, 0); g.fillStyle = rgba(shade(skin, -0.55), 0.55); g.beginPath(); g.ellipse(c.x, c.y, 0.5 * S, 0.35 * S, dirA, 0, Math.PI * 2); g.fill(); }
    knuckles(rowU + 0.7 - f * 0.12);
    // 拇指压住
    const t1 = at(1.6, wristW + 0.55), t2 = at(rowU + 0.15, knW * 0.35), t3 = at(rowU + 0.25, -knW * (hole ? 0.05 : 0.3 + 0.2 * f));
    fingerTube([thumbBase, t1, t2, t3], 0.5 * S * k, 0.42 * S * k);
    tendons();
  } else if (pose === 'sword') {
    // 剑指：食、中二指并拢伸直，无名、小指屈回，拇指扣住
    palm();
    const stiff = 0.04 - f * 0.08; // 用力时指尖微反翘
    for (let i = 2; i < 4; i++) {
      const w = knW * (0.78 - i * 0.52);
      fingerTube([at(palmLen, w), at(palmLen + 0.85, w), at(palmLen + 0.45, w * 0.9), at(palmLen - 0.1, w * 0.85)], fr * S * k, fr * 0.9 * S * k);
    }
    for (let i = 0; i < 2; i++) {
      const w = knW * (0.62 - i * 0.62);
      finger(at(palmLen + 0.1, w), dirA, [1.35, 1.0, 0.85], stiff, fr * (1 + 0.06 * f));
    }
    const t1 = at(1.7, wristW + 0.5), t2 = at(palmLen + 0.35, -knW * 0.35);
    fingerTube([thumbBase, t1, t2], 0.5 * S * k, 0.42 * S * k);
    tendons();
    if (f > 0.6 && S > 1.6) { // 指尖凝聚一点灵光
      const tip = at(palmLen + 3.4 * fl, 0.2);
      const gr = g.createRadialGradient(tip.x, tip.y, 0, tip.x, tip.y, 2.4 * S);
      gr.addColorStop(0, `rgba(200,255,235,${0.55 * (f - 0.6) * 2.5})`); gr.addColorStop(1, 'rgba(200,255,235,0)');
      g.fillStyle = gr; g.beginPath(); g.arc(tip.x, tip.y, 2.4 * S, 0, Math.PI * 2); g.fill();
    }
  } else if (pose === 'palm') {
    // 推掌：五指张开，用力越大张得越开、指尖反翘
    palm();
    const spread = 0.12 + 0.22 * f, back2 = -0.02 - 0.1 * f;
    for (let i = 0; i < 4; i++) {
      const w = knW * (0.78 - i * 0.52);
      const L = [[1.15, 0.8, 0.65], [1.3, 0.9, 0.7], [1.2, 0.85, 0.65], [0.95, 0.65, 0.55]][i];
      finger(at(palmLen + 0.1, w), dirA + (1.5 - i) * spread * thumbSide, L, back2, fr * (i === 3 ? 0.85 : 1));
    }
    finger(at(0.9, wristW + 0.2), dirA + (0.75 + 0.35 * f) * thumbSide, [1.1, 0.95], -0.05, 0.5);
    tendons();
  } else if (pose === 'mudra') {
    // 结印：拇指与食指相扣成环，余指舒展
    palm();
    for (let i = 1; i < 4; i++) {
      const w = knW * (0.78 - i * 0.52);
      finger(at(palmLen + 0.1, w), dirA, [1.1, 0.8, 0.6], 0.18, fr);
    }
    const i0 = at(palmLen + 0.1, knW * 0.78);
    finger(i0, dirA, [1.0, 0.7, 0.6], 0.75, fr);
    const ring = at(palmLen + 0.8, knW + 0.5);
    fingerTube([thumbBase, at(1.8, wristW + 0.8), ring], 0.5 * S * k, 0.42 * S * k);
  } else {
    // 自然：手指微屈，层次分明
    palm();
    for (let i = 0; i < 4; i++) {
      const w = knW * (0.78 - i * 0.52);
      const L = [[1.05, 0.75, 0.6], [1.2, 0.85, 0.65], [1.1, 0.8, 0.6], [0.85, 0.6, 0.5]][i];
      finger(at(palmLen + 0.1, w), dirA, L, 0.28 + i * 0.05 + f * 0.2, fr * (i === 3 ? 0.85 : 1));
    }
    finger(at(0.8, wristW + 0.15), dirA + 0.55 * thumbSide, [1.0, 0.85], 0.2, 0.5);
  }
  // 腕部收口线（袖口压住）
  if (S > 1.4) {
    g.strokeStyle = rgba(shade(skin, -0.4), 0.35); g.lineWidth = Math.max(0.3, 0.14 * S);
    const a = at(0.15, wristW * 0.9), b = at(0.15, -wristW * 0.9);
    g.beginPath(); g.moveTo(a.x, a.y); g.quadraticCurveTo(at(0.4, 0).x, at(0.4, 0).y, b.x, b.y); g.stroke();
  }
}
