// 第四十二步：衣橱 / 捏脸 —— 性别、面容（AI 立绘预设）、头身参数、衣装；实时预览各动作（含手势）。
import { useEffect, useRef, useState } from 'react';
import { CharState, drawCharacter, HANLI_LOOK, type Look, type Action } from '../gfx/character';
import { FACE_RANGE, BODY_RANGE, faceOf, bodyOf, type FaceParams, type BodyParams } from '../gfx/figure';
import { outfitsFor, wear, OUTFIT_BY_ID } from '../data/outfits';
import { FACES, FACE_BY_ID } from '../data/faces';

const KEY = 'fanren.heroLook';
export function savedHeroLook(): Look | null {
  try { const s = localStorage.getItem(KEY); return s ? { ...HANLI_LOOK, ...JSON.parse(s) } : null; } catch { return null; }
}
const FEMALE_BASE: Partial<Look> = { sex: 'f', skin: '#f4ddc4', headTex: undefined, height: 0.96, build: 1, ribbon: '#b05068', earring: '#9fd0b0' };

function Preview({ look, action, yaw }: { look: Look; action: Action; yaw: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const st = useRef<CharState>();
  useEffect(() => {
    const cv = ref.current!; const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = 260 * dpr; cv.height = 380 * dpr;
    const g = cv.getContext('2d')!;
    const S = 3.2 * dpr;
    const s = st.current ?? (st.current = new CharState());
    s.x = cv.width / 2; s.y = cv.height * 0.95;
    s.targetYaw = yaw; s.speed = action === 'run' ? 260 : action === 'walk' ? 80 : 0; s.setAction(action);
    let raf = 0, last = performance.now();
    const loop = (t: number) => {
      const dt = Math.min(0.05, (t - last) / 1000); last = t;
      if (action === 'cast' && s.actionT > 1.6) { s.action = 'idle'; s.setAction('cast'); }
      s.update(dt);
      g.clearRect(0, 0, cv.width, cv.height);
      g.fillStyle = 'rgba(40,30,20,0.12)'; g.beginPath(); g.ellipse(s.x, s.y, 22 * S, 6 * S, 0, 0, Math.PI * 2); g.fill();
      g.save(); drawCharacter(g, look, s, S, dt, { preview: true, mount: undefined }); g.restore();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [look, action, yaw]);
  return <canvas ref={ref} style={{ width: 260, height: 380 }} />;
}

const ACTS: [Action, string][] = [['idle', '待机'], ['walk', '行走'], ['run', '奔跑(握拳)'], ['cast', '施法(推掌)'], ['fly', '御剑(剑指)'], ['sit', '打坐(结印)'], ['gather', '采集(抓握)']];

export function Wardrobe({ look, onApply, onClose }: { look: Look; onApply: (l: Look) => void; onClose: () => void }) {
  const [lk, setLk] = useState<Look>(look);
  const [act, setAct] = useState<Action>('idle');
  const [yaw, setYaw] = useState(0.5);
  const [tab, setTab] = useState<'face' | 'body' | 'cloth'>('cloth');
  const F = faceOf(lk), B = bodyOf(lk);

  const setSex = (sex: 'm' | 'f') => {
    if (sex === lk.sex) return;
    const base: Look = sex === 'm' ? { ...HANLI_LOOK, face: undefined, body: undefined } : { ...HANLI_LOOK, ...FEMALE_BASE, hero: true } as Look;
    const fp = FACES.find((f) => f.sex === sex)!;
    let n: Look = { ...base, ...fp.set, portrait: fp.id, face: { ...(fp.set.face || {}) } };
    if (sex === 'f') n.headTex = undefined;
    const of = outfitsFor(sex); n = wear(n, of.find((o) => o.sex === sex)?.id || of[0].id);
    setLk(n);
  };
  const pickFace = (id: string) => {
    const fp = FACE_BY_ID.get(id)!;
    // 换面容：男主默认手绘头只配“沉毅”；其余用参数化代码头
    setLk({ ...lk, ...fp.set, portrait: id, face: { ...(fp.set.face || {}) }, headTex: lk.sex === 'm' && id === 'm1' ? 'hanli' : undefined });
  };
  const setFace = (k: keyof FaceParams, val: number) => setLk({ ...lk, headTex: undefined, face: { ...F, [k]: val } });
  const setBody = (k: keyof BodyParams, val: number) => setLk({ ...lk, body: { ...B, [k]: val } });
  const portrait = FACE_BY_ID.get(lk.portrait || '');

  return <div className="wardrobe-mask" onClick={onClose}>
    <div className="wardrobe" onClick={(e) => e.stopPropagation()}>
      <div className="wd-head"><b>衣橱 · 容貌</b><button className="wd-x" onClick={onClose}>×</button></div>
      <div className="wd-body">
        <div className="wd-left">
          {portrait && <img className="wd-portrait" src={portrait.img} alt={portrait.name} />}
          <Preview look={lk} action={act} yaw={yaw} />
          <input type="range" min={-3.14} max={3.14} step={0.01} value={yaw} onChange={(e) => setYaw(+e.target.value)} title="转身" />
          <div className="wd-acts">{ACTS.map(([a, n]) => <button key={a} className={act === a ? 'on' : ''} onClick={() => setAct(a)}>{n}</button>)}</div>
        </div>
        <div className="wd-right">
          <div className="wd-row">
            <button className={lk.sex === 'm' ? 'on' : ''} onClick={() => setSex('m')}>男</button>
            <button className={lk.sex === 'f' ? 'on' : ''} onClick={() => setSex('f')}>女</button>
          </div>
          <div className="wd-tabs">
            {([['cloth', '衣装'], ['face', '面容'], ['body', '头身']] as const).map(([t, n]) => <button key={t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{n}</button>)}
          </div>
          {tab === 'cloth' && <div className="wd-grid">
            {outfitsFor(lk.sex).map((o) => <button key={o.id} className={'wd-card' + (lk.outfit === o.id ? ' on' : '')} onClick={() => setLk(wear(lk, o.id))}>
              <span className="wd-sw" style={{ background: `linear-gradient(135deg, ${o.set.robe} 60%, ${o.set.trim} 60%)` }} />
              <b>{o.name}</b><small>{o.desc}</small>
            </button>)}
          </div>}
          {tab === 'face' && <>
            <div className="wd-faces">{FACES.filter((f) => f.sex === lk.sex).map((f) => <button key={f.id} className={lk.portrait === f.id ? 'on' : ''} onClick={() => pickFace(f.id)}><img src={f.img} alt="" /><span>{f.name}</span></button>)}</div>
            {(Object.keys(FACE_RANGE) as (keyof FaceParams)[]).map((k) => <label key={k} className="wd-sl"><span>{FACE_RANGE[k][2]}</span>
              <input type="range" min={FACE_RANGE[k][0]} max={FACE_RANGE[k][1]} step={0.01} value={F[k]} onChange={(e) => setFace(k, +e.target.value)} /></label>)}
          </>}
          {tab === 'body' && <>
            <label className="wd-sl"><span>头</span><input type="range" min={0.9} max={1.1} step={0.01} value={lk.headScale ?? 1} onChange={(e) => setLk({ ...lk, headScale: +e.target.value })} /></label>
            <label className="wd-sl"><span>身高</span><input type="range" min={0.9} max={1.08} step={0.01} value={lk.height} onChange={(e) => setLk({ ...lk, height: +e.target.value })} /></label>
            {(Object.keys(BODY_RANGE) as (keyof BodyParams)[]).map((k) => <label key={k} className="wd-sl"><span>{BODY_RANGE[k][2]}</span>
              <input type="range" min={BODY_RANGE[k][0]} max={BODY_RANGE[k][1]} step={0.01} value={B[k]} onChange={(e) => setBody(k, +e.target.value)} /></label>)}
          </>}
          <div className="wd-row wd-foot">
            <span>{OUTFIT_BY_ID.get(lk.outfit || '')?.name}</span>
            <button onClick={() => setLk(look)}>还原</button>
            <button className="on" onClick={() => { try { localStorage.setItem(KEY, JSON.stringify(lk)); } catch { /* */ } onApply(lk); }}>换上</button>
          </div>
        </div>
      </div>
    </div>
  </div>;
}
