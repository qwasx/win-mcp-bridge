// 第四十二步：换衣系统 —— 一套衣装 = 对 Look 中服饰字段的覆盖；身体/脸/发型不受影响。
import type { Look } from '../gfx/character';

export type OutfitSlot = 'robe' | 'inner' | 'trim' | 'belt' | 'pants' | 'boots' | 'robeLen' | 'sleeve' | 'shawl' | 'sash' | 'ribbon' | 'hat';
export interface Outfit { id: string; name: string; sex: 'm' | 'f' | 'u'; desc: string; set: Partial<Pick<Look, OutfitSlot>> }

export const OUTFITS: Outfit[] = [
  { id: 'qingshan', name: '青衫', sex: 'u', desc: '七玄门弟子常服，素净耐脏。',
    set: { robe: '#3f6a4c', inner: '#ece6d6', trim: '#2b4636', belt: '#1f2420', pants: '#8a7a62', boots: '#2a2622', robeLen: 'long', sleeve: 'wide', sash: '#1f2420', ribbon: '#2a3a30', shawl: undefined } },
  { id: 'huangfeng', name: '黄枫谷道袍', sex: 'u', desc: '黄枫谷外门制式道袍，镶枫叶黄边。',
    set: { robe: '#c9a24a', inner: '#f3ecd8', trim: '#7a4a1a', belt: '#4a2e14', pants: '#5a4630', boots: '#2a2018', robeLen: 'long', sleeve: 'wide', sash: '#7a4a1a', ribbon: '#7a4a1a' } },
  { id: 'xuanyi', name: '玄衣劲装', sex: 'u', desc: '窄袖短打，便于斗法奔袭。',
    set: { robe: '#24262c', inner: '#6a6e78', trim: '#8a2a24', belt: '#8a2a24', pants: '#1c1d22', boots: '#121214', robeLen: 'short', sleeve: 'narrow', sash: '#8a2a24', ribbon: '#8a2a24', shawl: undefined } },
  { id: 'baiyi', name: '白衣书生', sex: 'm', desc: '月白长衫，墨蓝镶边，一派斯文。',
    set: { robe: '#e8e6e0', inner: '#ffffff', trim: '#2c3e5a', belt: '#2c3e5a', pants: '#cfcbc0', boots: '#2a2a30', robeLen: 'long', sleeve: 'wide', sash: '#2c3e5a', ribbon: '#2c3e5a' } },
  { id: 'zhanpao', name: '赤金战袍', sex: 'm', desc: '朱红外袍配金边，结丹修士出行之服。',
    set: { robe: '#8a2a24', inner: '#f0dcc0', trim: '#d8b050', belt: '#3a1a12', pants: '#3a2a22', boots: '#1e1410', robeLen: 'long', sleeve: 'wide', sash: '#d8b050', ribbon: '#d8b050' } },
  { id: 'nongfu', name: '粗布短褐', sex: 'm', desc: '山村少年的旧衣裳。',
    set: { robe: '#8a7a5a', inner: '#d8ccb0', trim: '#5a4a32', belt: '#3a3024', pants: '#6a5a44', boots: '#3a2e22', robeLen: 'short', sleeve: 'narrow', sash: undefined, ribbon: '#5a4a32' } },
  { id: 'liuxian', name: '流仙裙', sex: 'f', desc: '浅粉襦裙，披帛随风。',
    set: { robe: '#e8b8c4', inner: '#fff4f4', trim: '#b05068', belt: '#b05068', pants: '#f0d8de', boots: '#c87a8a', robeLen: 'long', sleeve: 'wide', shawl: '#f6e6ee', sash: '#b05068', ribbon: '#b05068' } },
  { id: 'bingxue', name: '冰绡衣', sex: 'f', desc: '月白冰蚕丝，镶天青色边，清冷出尘。',
    set: { robe: '#e6eef4', inner: '#ffffff', trim: '#6a9ab8', belt: '#6a9ab8', pants: '#dce6ee', boots: '#8aaac0', robeLen: 'long', sleeve: 'wide', shawl: '#cfe4f0', sash: '#6a9ab8', ribbon: '#6a9ab8' } },
  { id: 'ziyun', name: '紫云宫装', sex: 'f', desc: '紫绫宫装，金线压边，雍容华贵。',
    set: { robe: '#6a4a8a', inner: '#f4e8f4', trim: '#d8b050', belt: '#3a2450', pants: '#4a3462', boots: '#2a1a3a', robeLen: 'long', sleeve: 'wide', shawl: '#c8a8e0', sash: '#d8b050', ribbon: '#d8b050' } },
  { id: 'hongzhuang', name: '红妆劲服', sex: 'f', desc: '朱红窄袖，英气飒爽的女剑修。',
    set: { robe: '#b8323a', inner: '#f6e4d8', trim: '#2a1a1a', belt: '#2a1a1a', pants: '#3a2224', boots: '#1e1214', robeLen: 'short', sleeve: 'narrow', shawl: undefined, sash: '#2a1a1a', ribbon: '#2a1a1a' } },
];
export const OUTFIT_BY_ID = new Map(OUTFITS.map((o) => [o.id, o]));

export function outfitsFor(sex: 'm' | 'f') { return OUTFITS.filter((o) => o.sex === 'u' || o.sex === sex); }

/** 换上某套衣装（返回新 Look，不改原对象） */
export function wear(look: Look, id: string): Look {
  const o = OUTFIT_BY_ID.get(id); if (!o) return look;
  const out: Look = { ...look, outfit: id };
  for (const [k, val] of Object.entries(o.set)) (out as any)[k] = val;
  if (look.sex === 'm') out.shawl = undefined;
  return out;
}
