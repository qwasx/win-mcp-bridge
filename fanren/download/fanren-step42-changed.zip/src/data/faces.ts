// 第四十二步：面容预设 —— AI 工笔立绘 + 与之对应的代码脸型参数 / 发型
import m1 from '../assets/faces/m1.jpg';
import m2 from '../assets/faces/m2.jpg';
import f1 from '../assets/faces/f1.jpg';
import f2 from '../assets/faces/f2.jpg';
import type { Look } from '../gfx/character';

export interface FacePreset { id: string; sex: 'm' | 'f'; name: string; img: string; set: Partial<Look> }
export const FACES: FacePreset[] = [
  { id: 'm1', sex: 'm', name: '沉毅', img: m1, set: { hairStyle: 'bun', face: { jaw: 1.02, eye: 0.95, eyeTilt: 0.15, brow: 1.25, browTilt: 0.4 } } },
  { id: 'm2', sex: 'm', name: '温雅', img: m2, set: { hairStyle: 'halfup', face: { jaw: 0.95, chin: 0.97, eye: 1.05, eyeTilt: 0, brow: 0.95, browTilt: 0.1, mouth: 0.95 } } },
  { id: 'f1', sex: 'f', name: '温婉', img: f1, set: { hairStyle: 'long', bangs: true, pin: 'jade', huadian: '#d0303a', lash: true, lip: '#c84a56', face: { eye: 1.15, eyeTilt: 0.05, browTilt: -0.3 } } },
  { id: 'f2', sex: 'f', name: '清冷', img: f2, set: { hairStyle: 'updo', bangs: false, pin: 'gold', huadian: undefined, lash: true, lip: '#b84050', face: { jaw: 0.9, eye: 1.0, eyeTilt: 0.5, brow: 0.75, browTilt: -0.1, mouth: 0.85 } } },
];
export const FACE_BY_ID = new Map(FACES.map((f) => [f.id, f]));
